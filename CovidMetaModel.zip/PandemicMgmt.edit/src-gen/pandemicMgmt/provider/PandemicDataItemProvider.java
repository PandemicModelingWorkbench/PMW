/**
 */
package pandemicMgmt.provider;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

import pandemicMgmt.PandemicData;
import pandemicMgmt.PandemicMgmtPackage;

/**
 * This is the item provider adapter for a {@link pandemicMgmt.PandemicData} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class PandemicDataItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PandemicDataItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addLocationPropertyDescriptor(object);
			addCurrentTestsCountPropertyDescriptor(object);
			addPreviousTestsCountPropertyDescriptor(object);
			addCurrentPositivePropertyDescriptor(object);
			addCurrentPositiveOver60PropertyDescriptor(object);
			addCurrentCaseCountPropertyDescriptor(object);
			addPreviousCaseCountPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Location feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addLocationPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PandemicData_location_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_PandemicData_location_feature",
								"_UI_PandemicData_type"),
						PandemicMgmtPackage.Literals.PANDEMIC_DATA__LOCATION, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Current Tests Count feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCurrentTestsCountPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_PandemicData_currentTestsCount_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_PandemicData_currentTestsCount_feature",
						"_UI_PandemicData_type"),
				PandemicMgmtPackage.Literals.PANDEMIC_DATA__CURRENT_TESTS_COUNT, true, false, false,
				ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Previous Tests Count feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPreviousTestsCountPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_PandemicData_previousTestsCount_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_PandemicData_previousTestsCount_feature",
						"_UI_PandemicData_type"),
				PandemicMgmtPackage.Literals.PANDEMIC_DATA__PREVIOUS_TESTS_COUNT, true, false, false,
				ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Current Positive feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCurrentPositivePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PandemicData_currentPositive_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_PandemicData_currentPositive_feature",
								"_UI_PandemicData_type"),
						PandemicMgmtPackage.Literals.PANDEMIC_DATA__CURRENT_POSITIVE, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Current Positive Over60 feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCurrentPositiveOver60PropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_PandemicData_currentPositiveOver60_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_PandemicData_currentPositiveOver60_feature",
						"_UI_PandemicData_type"),
				PandemicMgmtPackage.Literals.PANDEMIC_DATA__CURRENT_POSITIVE_OVER60, true, false, false,
				ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Current Case Count feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCurrentCaseCountPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_PandemicData_currentCaseCount_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_PandemicData_currentCaseCount_feature",
						"_UI_PandemicData_type"),
				PandemicMgmtPackage.Literals.PANDEMIC_DATA__CURRENT_CASE_COUNT, true, false, false,
				ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Previous Case Count feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPreviousCaseCountPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_PandemicData_previousCaseCount_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_PandemicData_previousCaseCount_feature",
						"_UI_PandemicData_type"),
				PandemicMgmtPackage.Literals.PANDEMIC_DATA__PREVIOUS_CASE_COUNT, true, false, false,
				ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns PandemicData.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/PandemicData"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		PandemicData pandemicData = (PandemicData) object;
		return getString("_UI_PandemicData_type") + " " + pandemicData.getCurrentTestsCount();
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(PandemicData.class)) {
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_TESTS_COUNT:
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_TESTS_COUNT:
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE:
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE_OVER60:
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_CASE_COUNT:
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_CASE_COUNT:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return PandemicMgmtEditPlugin.INSTANCE;
	}

}
