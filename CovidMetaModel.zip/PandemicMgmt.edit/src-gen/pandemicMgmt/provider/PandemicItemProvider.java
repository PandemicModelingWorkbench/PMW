/**
 */
package pandemicMgmt.provider;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

import pandemicMgmt.Pandemic;
import pandemicMgmt.PandemicMgmtFactory;
import pandemicMgmt.PandemicMgmtPackage;

/**
 * This is the item provider adapter for a {@link pandemicMgmt.Pandemic} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class PandemicItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PandemicItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addNamePropertyDescriptor(object);
			addControlpolicyPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Pandemic_name_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Pandemic_name_feature",
								"_UI_Pandemic_type"),
						PandemicMgmtPackage.Literals.PANDEMIC__NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Controlpolicy feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addControlpolicyPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Pandemic_controlpolicy_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Pandemic_controlpolicy_feature",
								"_UI_Pandemic_type"),
						PandemicMgmtPackage.Literals.PANDEMIC__CONTROLPOLICY, true, false, true, null, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION);
			childrenFeatures.add(PandemicMgmtPackage.Literals.PANDEMIC__PANDEMICDATA);
			childrenFeatures.add(PandemicMgmtPackage.Literals.PANDEMIC__RESOURCES);
			childrenFeatures.add(PandemicMgmtPackage.Literals.PANDEMIC__CONTROLPOLICY);
			childrenFeatures.add(PandemicMgmtPackage.Literals.PANDEMIC__PERSON);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Pandemic.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Pandemic"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Pandemic) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Pandemic_type")
				: getString("_UI_Pandemic_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Pandemic.class)) {
		case PandemicMgmtPackage.PANDEMIC__NAME:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case PandemicMgmtPackage.PANDEMIC__LOCATION:
		case PandemicMgmtPackage.PANDEMIC__PANDEMICDATA:
		case PandemicMgmtPackage.PANDEMIC__RESOURCES:
		case PandemicMgmtPackage.PANDEMIC__CONTROLPOLICY:
		case PandemicMgmtPackage.PANDEMIC__PERSON:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION,
				PandemicMgmtFactory.eINSTANCE.createCountry()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION,
				PandemicMgmtFactory.eINSTANCE.createTown()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION,
				PandemicMgmtFactory.eINSTANCE.createHouse()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION,
				PandemicMgmtFactory.eINSTANCE.createCity()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION,
				PandemicMgmtFactory.eINSTANCE.createState()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION,
				PandemicMgmtFactory.eINSTANCE.createHStreet()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__LOCATION,
				PandemicMgmtFactory.eINSTANCE.createVStreet()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__PANDEMICDATA,
				PandemicMgmtFactory.eINSTANCE.createPandemicData()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__RESOURCES,
				PandemicMgmtFactory.eINSTANCE.createQuarentineCentre()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__RESOURCES,
				PandemicMgmtFactory.eINSTANCE.createPrimaryHealthUnit()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__RESOURCES,
				PandemicMgmtFactory.eINSTANCE.createSecondaryHealthUnit()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__RESOURCES,
				PandemicMgmtFactory.eINSTANCE.createTertiaryHealthUnit()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__RESOURCES,
				PandemicMgmtFactory.eINSTANCE.createStaff()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__RESOURCES,
				PandemicMgmtFactory.eINSTANCE.createEquipment()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__CONTROLPOLICY,
				PandemicMgmtFactory.eINSTANCE.createControlPolicy()));

		newChildDescriptors.add(createChildParameter(PandemicMgmtPackage.Literals.PANDEMIC__PERSON,
				PandemicMgmtFactory.eINSTANCE.createPerson()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return PandemicMgmtEditPlugin.INSTANCE;
	}

}
