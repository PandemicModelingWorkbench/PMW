/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>City</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.City#getCityCode <em>City Code</em>}</li>
 *   <li>{@link pandemicMgmt.City#getState <em>State</em>}</li>
 *   <li>{@link pandemicMgmt.City#getTown <em>Town</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getCity()
 * @model
 * @generated
 */
public interface City extends Location {
	/**
	 * Returns the value of the '<em><b>City Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>City Code</em>' attribute.
	 * @see #setCityCode(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getCity_CityCode()
	 * @model
	 * @generated
	 */
	String getCityCode();

	/**
	 * Sets the value of the '{@link pandemicMgmt.City#getCityCode <em>City Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>City Code</em>' attribute.
	 * @see #getCityCode()
	 * @generated
	 */
	void setCityCode(String value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.State#getCity <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' reference.
	 * @see #setState(State)
	 * @see pandemicMgmt.PandemicMgmtPackage#getCity_State()
	 * @see pandemicMgmt.State#getCity
	 * @model opposite="city"
	 * @generated
	 */
	State getState();

	/**
	 * Sets the value of the '{@link pandemicMgmt.City#getState <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' reference.
	 * @see #getState()
	 * @generated
	 */
	void setState(State value);

	/**
	 * Returns the value of the '<em><b>Town</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.Town}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Town#getCity <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Town</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getCity_Town()
	 * @see pandemicMgmt.Town#getCity
	 * @model opposite="city"
	 * @generated
	 */
	EList<Town> getTown();

} // City
