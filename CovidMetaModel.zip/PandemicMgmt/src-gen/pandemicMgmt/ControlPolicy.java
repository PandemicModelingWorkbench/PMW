/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Control Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.ControlPolicy#getLocation <em>Location</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getCaseRate <em>Case Rate</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getBedsperPopulation <em>Bedsper Population</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getPositivityRate <em>Positivity Rate</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getCaseDetectionRate <em>Case Detection Rate</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getVentsPerPopulation <em>Vents Per Population</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getTestingRate <em>Testing Rate</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getDoctorsPerPatient <em>Doctors Per Patient</em>}</li>
 *   <li>{@link pandemicMgmt.ControlPolicy#getSetTier <em>Set Tier</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy()
 * @model
 * @generated
 */
public interface ControlPolicy extends EObject {
	/**
	 * Returns the value of the '<em><b>Location</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.Location}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Location#getControlpolicy <em>Controlpolicy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_Location()
	 * @see pandemicMgmt.Location#getControlpolicy
	 * @model opposite="controlpolicy"
	 * @generated
	 */
	EList<Location> getLocation();

	/**
	 * Returns the value of the '<em><b>Case Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Case Rate</em>' attribute.
	 * @see #setCaseRate(float)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_CaseRate()
	 * @model required="true"
	 * @generated
	 */
	float getCaseRate();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getCaseRate <em>Case Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Case Rate</em>' attribute.
	 * @see #getCaseRate()
	 * @generated
	 */
	void setCaseRate(float value);

	/**
	 * Returns the value of the '<em><b>Bedsper Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bedsper Population</em>' attribute.
	 * @see #setBedsperPopulation(float)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_BedsperPopulation()
	 * @model required="true"
	 * @generated
	 */
	float getBedsperPopulation();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getBedsperPopulation <em>Bedsper Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bedsper Population</em>' attribute.
	 * @see #getBedsperPopulation()
	 * @generated
	 */
	void setBedsperPopulation(float value);

	/**
	 * Returns the value of the '<em><b>Positivity Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Positivity Rate</em>' attribute.
	 * @see #setPositivityRate(float)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_PositivityRate()
	 * @model required="true"
	 * @generated
	 */
	float getPositivityRate();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getPositivityRate <em>Positivity Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Positivity Rate</em>' attribute.
	 * @see #getPositivityRate()
	 * @generated
	 */
	void setPositivityRate(float value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Case Detection Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Case Detection Rate</em>' attribute.
	 * @see #setCaseDetectionRate(float)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_CaseDetectionRate()
	 * @model required="true"
	 * @generated
	 */
	float getCaseDetectionRate();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getCaseDetectionRate <em>Case Detection Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Case Detection Rate</em>' attribute.
	 * @see #getCaseDetectionRate()
	 * @generated
	 */
	void setCaseDetectionRate(float value);

	/**
	 * Returns the value of the '<em><b>Vents Per Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vents Per Population</em>' attribute.
	 * @see #setVentsPerPopulation(float)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_VentsPerPopulation()
	 * @model required="true" transient="true"
	 * @generated
	 */
	float getVentsPerPopulation();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getVentsPerPopulation <em>Vents Per Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vents Per Population</em>' attribute.
	 * @see #getVentsPerPopulation()
	 * @generated
	 */
	void setVentsPerPopulation(float value);

	/**
	 * Returns the value of the '<em><b>Testing Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Testing Rate</em>' attribute.
	 * @see #setTestingRate(float)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_TestingRate()
	 * @model required="true"
	 * @generated
	 */
	float getTestingRate();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getTestingRate <em>Testing Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Testing Rate</em>' attribute.
	 * @see #getTestingRate()
	 * @generated
	 */
	void setTestingRate(float value);

	/**
	 * Returns the value of the '<em><b>Doctors Per Patient</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctors Per Patient</em>' attribute.
	 * @see #setDoctorsPerPatient(float)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_DoctorsPerPatient()
	 * @model default="0.0" required="true"
	 * @generated
	 */
	float getDoctorsPerPatient();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getDoctorsPerPatient <em>Doctors Per Patient</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Doctors Per Patient</em>' attribute.
	 * @see #getDoctorsPerPatient()
	 * @generated
	 */
	void setDoctorsPerPatient(float value);

	/**
	 * Returns the value of the '<em><b>Set Tier</b></em>' attribute.
	 * The literals are from the enumeration {@link pandemicMgmt.LLevel}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Set Tier</em>' attribute.
	 * @see pandemicMgmt.LLevel
	 * @see #setSetTier(LLevel)
	 * @see pandemicMgmt.PandemicMgmtPackage#getControlPolicy_SetTier()
	 * @model
	 * @generated
	 */
	LLevel getSetTier();

	/**
	 * Sets the value of the '{@link pandemicMgmt.ControlPolicy#getSetTier <em>Set Tier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Set Tier</em>' attribute.
	 * @see pandemicMgmt.LLevel
	 * @see #getSetTier()
	 * @generated
	 */
	void setSetTier(LLevel value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void SetControlParameters();

} // ControlPolicy
