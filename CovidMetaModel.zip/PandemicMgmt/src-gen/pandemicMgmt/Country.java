/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Country</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Country#getCountryCode <em>Country Code</em>}</li>
 *   <li>{@link pandemicMgmt.Country#getState <em>State</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getCountry()
 * @model
 * @generated
 */
public interface Country extends Location {
	/**
	 * Returns the value of the '<em><b>Country Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Country Code</em>' attribute.
	 * @see #setCountryCode(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getCountry_CountryCode()
	 * @model
	 * @generated
	 */
	String getCountryCode();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Country#getCountryCode <em>Country Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Country Code</em>' attribute.
	 * @see #getCountryCode()
	 * @generated
	 */
	void setCountryCode(String value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.State}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.State#getCountry <em>Country</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getCountry_State()
	 * @see pandemicMgmt.State#getCountry
	 * @model opposite="country"
	 * @generated
	 */
	EList<State> getState();

} // Country
