/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equipment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Equipment#getVentilators <em>Ventilators</em>}</li>
 *   <li>{@link pandemicMgmt.Equipment#getPPEs <em>PP Es</em>}</li>
 *   <li>{@link pandemicMgmt.Equipment#getVaccines <em>Vaccines</em>}</li>
 *   <li>{@link pandemicMgmt.Equipment#getHealthcentre <em>Healthcentre</em>}</li>
 *   <li>{@link pandemicMgmt.Equipment#getTestKits <em>Test Kits</em>}</li>
 *   <li>{@link pandemicMgmt.Equipment#getAmbulances <em>Ambulances</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getEquipment()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='ventilatorsCheck'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot ventilatorsCheck='\n\t\tself.location.controlpolicy.ventsPerPopulation &gt;= self.ventilators'"
 * @generated
 */
public interface Equipment extends Resources {
	/**
	 * Returns the value of the '<em><b>Ventilators</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ventilators</em>' attribute.
	 * @see #setVentilators(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getEquipment_Ventilators()
	 * @model required="true"
	 * @generated
	 */
	int getVentilators();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Equipment#getVentilators <em>Ventilators</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ventilators</em>' attribute.
	 * @see #getVentilators()
	 * @generated
	 */
	void setVentilators(int value);

	/**
	 * Returns the value of the '<em><b>PP Es</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>PP Es</em>' attribute.
	 * @see #setPPEs(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getEquipment_PPEs()
	 * @model required="true"
	 * @generated
	 */
	int getPPEs();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Equipment#getPPEs <em>PP Es</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>PP Es</em>' attribute.
	 * @see #getPPEs()
	 * @generated
	 */
	void setPPEs(int value);

	/**
	 * Returns the value of the '<em><b>Vaccines</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vaccines</em>' attribute.
	 * @see #setVaccines(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getEquipment_Vaccines()
	 * @model required="true"
	 * @generated
	 */
	int getVaccines();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Equipment#getVaccines <em>Vaccines</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vaccines</em>' attribute.
	 * @see #getVaccines()
	 * @generated
	 */
	void setVaccines(int value);

	/**
	 * Returns the value of the '<em><b>Healthcentre</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.HealthCentre#getEquipment <em>Equipment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Healthcentre</em>' reference.
	 * @see #setHealthcentre(HealthCentre)
	 * @see pandemicMgmt.PandemicMgmtPackage#getEquipment_Healthcentre()
	 * @see pandemicMgmt.HealthCentre#getEquipment
	 * @model opposite="equipment"
	 * @generated
	 */
	HealthCentre getHealthcentre();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Equipment#getHealthcentre <em>Healthcentre</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Healthcentre</em>' reference.
	 * @see #getHealthcentre()
	 * @generated
	 */
	void setHealthcentre(HealthCentre value);

	/**
	 * Returns the value of the '<em><b>Test Kits</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Test Kits</em>' attribute.
	 * @see #setTestKits(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getEquipment_TestKits()
	 * @model required="true"
	 * @generated
	 */
	int getTestKits();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Equipment#getTestKits <em>Test Kits</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Test Kits</em>' attribute.
	 * @see #getTestKits()
	 * @generated
	 */
	void setTestKits(int value);

	/**
	 * Returns the value of the '<em><b>Ambulances</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ambulances</em>' attribute.
	 * @see #setAmbulances(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getEquipment_Ambulances()
	 * @model required="true"
	 * @generated
	 */
	int getAmbulances();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Equipment#getAmbulances <em>Ambulances</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ambulances</em>' attribute.
	 * @see #getAmbulances()
	 * @generated
	 */
	void setAmbulances(int value);

} // Equipment
