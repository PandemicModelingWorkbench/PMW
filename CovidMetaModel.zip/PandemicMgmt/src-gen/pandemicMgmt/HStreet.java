/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>HStreet</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getHStreet()
 * @model
 * @generated
 */
public interface HStreet extends Street {
} // HStreet
