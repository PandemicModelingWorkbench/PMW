/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Health Centre</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.HealthCentre#getStaff <em>Staff</em>}</li>
 *   <li>{@link pandemicMgmt.HealthCentre#getEquipment <em>Equipment</em>}</li>
 *   <li>{@link pandemicMgmt.HealthCentre#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.HealthCentre#getBeds <em>Beds</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getHealthCentre()
 * @model abstract="true"
 * @generated
 */
public interface HealthCentre extends Resources {
	/**
	 * Returns the value of the '<em><b>Staff</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Staff#getHealthcentre <em>Healthcentre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Staff</em>' reference.
	 * @see #setStaff(Staff)
	 * @see pandemicMgmt.PandemicMgmtPackage#getHealthCentre_Staff()
	 * @see pandemicMgmt.Staff#getHealthcentre
	 * @model opposite="healthcentre"
	 * @generated
	 */
	Staff getStaff();

	/**
	 * Sets the value of the '{@link pandemicMgmt.HealthCentre#getStaff <em>Staff</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Staff</em>' reference.
	 * @see #getStaff()
	 * @generated
	 */
	void setStaff(Staff value);

	/**
	 * Returns the value of the '<em><b>Equipment</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Equipment#getHealthcentre <em>Healthcentre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Equipment</em>' reference.
	 * @see #setEquipment(Equipment)
	 * @see pandemicMgmt.PandemicMgmtPackage#getHealthCentre_Equipment()
	 * @see pandemicMgmt.Equipment#getHealthcentre
	 * @model opposite="healthcentre"
	 * @generated
	 */
	Equipment getEquipment();

	/**
	 * Sets the value of the '{@link pandemicMgmt.HealthCentre#getEquipment <em>Equipment</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Equipment</em>' reference.
	 * @see #getEquipment()
	 * @generated
	 */
	void setEquipment(Equipment value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getHealthCentre_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link pandemicMgmt.HealthCentre#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Beds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Beds</em>' attribute.
	 * @see #setBeds(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getHealthCentre_Beds()
	 * @model required="true"
	 * @generated
	 */
	int getBeds();

	/**
	 * Sets the value of the '{@link pandemicMgmt.HealthCentre#getBeds <em>Beds</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Beds</em>' attribute.
	 * @see #getBeds()
	 * @generated
	 */
	void setBeds(int value);

} // HealthCentre
