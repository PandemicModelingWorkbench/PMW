/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>House</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.House#getHouseID <em>House ID</em>}</li>
 *   <li>{@link pandemicMgmt.House#getPerson <em>Person</em>}</li>
 *   <li>{@link pandemicMgmt.House#getStreet <em>Street</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getHouse()
 * @model
 * @generated
 */
public interface House extends Location {
	/**
	 * Returns the value of the '<em><b>House ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>House ID</em>' attribute.
	 * @see #setHouseID(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getHouse_HouseID()
	 * @model
	 * @generated
	 */
	String getHouseID();

	/**
	 * Sets the value of the '{@link pandemicMgmt.House#getHouseID <em>House ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>House ID</em>' attribute.
	 * @see #getHouseID()
	 * @generated
	 */
	void setHouseID(String value);

	/**
	 * Returns the value of the '<em><b>Person</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.Person}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Person#getHouse <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Person</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getHouse_Person()
	 * @see pandemicMgmt.Person#getHouse
	 * @model opposite="house"
	 * @generated
	 */
	EList<Person> getPerson();

	/**
	 * Returns the value of the '<em><b>Street</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Street#getHouse <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Street</em>' reference.
	 * @see #setStreet(Street)
	 * @see pandemicMgmt.PandemicMgmtPackage#getHouse_Street()
	 * @see pandemicMgmt.Street#getHouse
	 * @model opposite="house"
	 * @generated
	 */
	Street getStreet();

	/**
	 * Sets the value of the '{@link pandemicMgmt.House#getStreet <em>Street</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Street</em>' reference.
	 * @see #getStreet()
	 * @generated
	 */
	void setStreet(Street value);

} // House
