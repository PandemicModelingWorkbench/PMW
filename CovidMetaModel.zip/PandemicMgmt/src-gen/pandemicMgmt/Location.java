/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Location</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Location#getPandemicdata <em>Pandemicdata</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getCurrentTier <em>Current Tier</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getControlpolicy <em>Controlpolicy</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getResources <em>Resources</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getPopulation <em>Population</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getPopulationOver60 <em>Population Over60</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getHealthy <em>Healthy</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getInfected <em>Infected</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getRecovered <em>Recovered</em>}</li>
 *   <li>{@link pandemicMgmt.Location#getLocation <em>Location</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getLocation()
 * @model abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='policyTierCheck caseRateCheck testingRateCheck positivityRateCheck'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot policyTierCheck='\n\t\tself.currentTier = self.controlpolicy.setTier' caseRateCheck='\n\t\t(self.pandemicdata.previousCaseCount)/(self.pandemicdata.currentCaseCount) &lt;= self.controlpolicy.caseRate' testingRateCheck='\n\t\t(self.pandemicdata.previousTestsCount)/(self.pandemicdata.currentTestsCount) &lt;= self.controlpolicy.caseDetectionRate' positivityRateCheck='\n\t\tself.pandemicdata.currentPositive &lt;= self.controlpolicy.positivityRate'"
 * @generated
 */
public interface Location extends EObject {
	/**
	 * Returns the value of the '<em><b>Pandemicdata</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.PandemicData#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pandemicdata</em>' reference.
	 * @see #setPandemicdata(PandemicData)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Pandemicdata()
	 * @see pandemicMgmt.PandemicData#getLocation
	 * @model opposite="location"
	 * @generated
	 */
	PandemicData getPandemicdata();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getPandemicdata <em>Pandemicdata</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pandemicdata</em>' reference.
	 * @see #getPandemicdata()
	 * @generated
	 */
	void setPandemicdata(PandemicData value);

	/**
	 * Returns the value of the '<em><b>Current Tier</b></em>' attribute.
	 * The literals are from the enumeration {@link pandemicMgmt.LLevel}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Tier</em>' attribute.
	 * @see pandemicMgmt.LLevel
	 * @see #setCurrentTier(LLevel)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_CurrentTier()
	 * @model
	 * @generated
	 */
	LLevel getCurrentTier();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getCurrentTier <em>Current Tier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Tier</em>' attribute.
	 * @see pandemicMgmt.LLevel
	 * @see #getCurrentTier()
	 * @generated
	 */
	void setCurrentTier(LLevel value);

	/**
	 * Returns the value of the '<em><b>Controlpolicy</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.ControlPolicy#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlpolicy</em>' reference.
	 * @see #setControlpolicy(ControlPolicy)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Controlpolicy()
	 * @see pandemicMgmt.ControlPolicy#getLocation
	 * @model opposite="location"
	 * @generated
	 */
	ControlPolicy getControlpolicy();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getControlpolicy <em>Controlpolicy</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Controlpolicy</em>' reference.
	 * @see #getControlpolicy()
	 * @generated
	 */
	void setControlpolicy(ControlPolicy value);

	/**
	 * Returns the value of the '<em><b>Resources</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.Resources}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Resources#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Resources</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Resources()
	 * @see pandemicMgmt.Resources#getLocation
	 * @model opposite="location"
	 * @generated
	 */
	EList<Resources> getResources();

	/**
	 * Returns the value of the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Population</em>' attribute.
	 * @see #setPopulation(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Population()
	 * @model required="true"
	 * @generated
	 */
	int getPopulation();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getPopulation <em>Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Population</em>' attribute.
	 * @see #getPopulation()
	 * @generated
	 */
	void setPopulation(int value);

	/**
	 * Returns the value of the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Population Over60</em>' attribute.
	 * @see #setPopulationOver60(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_PopulationOver60()
	 * @model required="true"
	 * @generated
	 */
	int getPopulationOver60();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getPopulationOver60 <em>Population Over60</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Population Over60</em>' attribute.
	 * @see #getPopulationOver60()
	 * @generated
	 */
	void setPopulationOver60(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Healthy</em>' attribute.
	 * @see #setHealthy(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Healthy()
	 * @model required="true"
	 * @generated
	 */
	int getHealthy();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getHealthy <em>Healthy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Healthy</em>' attribute.
	 * @see #getHealthy()
	 * @generated
	 */
	void setHealthy(int value);

	/**
	 * Returns the value of the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Infected</em>' attribute.
	 * @see #setInfected(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Infected()
	 * @model required="true"
	 * @generated
	 */
	int getInfected();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getInfected <em>Infected</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Infected</em>' attribute.
	 * @see #getInfected()
	 * @generated
	 */
	void setInfected(int value);

	/**
	 * Returns the value of the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Recovered</em>' attribute.
	 * @see #setRecovered(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Recovered()
	 * @model required="true"
	 * @generated
	 */
	int getRecovered();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Location#getRecovered <em>Recovered</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Recovered</em>' attribute.
	 * @see #getRecovered()
	 * @generated
	 */
	void setRecovered(int value);

	/**
	 * Returns the value of the '<em><b>Location</b></em>' containment reference list.
	 * The list contents are of type {@link pandemicMgmt.Location}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' containment reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getLocation_Location()
	 * @model containment="true"
	 * @generated
	 */
	EList<Location> getLocation();

} // Location
