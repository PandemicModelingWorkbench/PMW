/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pandemic</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Pandemic#getLocation <em>Location</em>}</li>
 *   <li>{@link pandemicMgmt.Pandemic#getPandemicdata <em>Pandemicdata</em>}</li>
 *   <li>{@link pandemicMgmt.Pandemic#getResources <em>Resources</em>}</li>
 *   <li>{@link pandemicMgmt.Pandemic#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.Pandemic#getControlpolicy <em>Controlpolicy</em>}</li>
 *   <li>{@link pandemicMgmt.Pandemic#getPerson <em>Person</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getPandemic()
 * @model
 * @generated
 */
public interface Pandemic extends EObject {
	/**
	 * Returns the value of the '<em><b>Location</b></em>' containment reference list.
	 * The list contents are of type {@link pandemicMgmt.Location}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' containment reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemic_Location()
	 * @model containment="true"
	 * @generated
	 */
	EList<Location> getLocation();

	/**
	 * Returns the value of the '<em><b>Pandemicdata</b></em>' containment reference list.
	 * The list contents are of type {@link pandemicMgmt.PandemicData}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pandemicdata</em>' containment reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemic_Pandemicdata()
	 * @model containment="true"
	 * @generated
	 */
	EList<PandemicData> getPandemicdata();

	/**
	 * Returns the value of the '<em><b>Resources</b></em>' containment reference list.
	 * The list contents are of type {@link pandemicMgmt.Resources}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Resources</em>' containment reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemic_Resources()
	 * @model containment="true"
	 * @generated
	 */
	EList<Resources> getResources();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemic_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Pandemic#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Controlpolicy</b></em>' containment reference list.
	 * The list contents are of type {@link pandemicMgmt.ControlPolicy}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlpolicy</em>' containment reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemic_Controlpolicy()
	 * @model containment="true"
	 * @generated
	 */
	EList<ControlPolicy> getControlpolicy();

	/**
	 * Returns the value of the '<em><b>Person</b></em>' containment reference list.
	 * The list contents are of type {@link pandemicMgmt.Person}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Person</em>' containment reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemic_Person()
	 * @model containment="true"
	 * @generated
	 */
	EList<Person> getPerson();

} // Pandemic
