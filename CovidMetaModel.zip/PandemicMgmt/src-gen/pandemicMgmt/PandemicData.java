/**
 */
package pandemicMgmt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pandemic Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.PandemicData#getLocation <em>Location</em>}</li>
 *   <li>{@link pandemicMgmt.PandemicData#getCurrentTestsCount <em>Current Tests Count</em>}</li>
 *   <li>{@link pandemicMgmt.PandemicData#getPreviousTestsCount <em>Previous Tests Count</em>}</li>
 *   <li>{@link pandemicMgmt.PandemicData#getCurrentPositive <em>Current Positive</em>}</li>
 *   <li>{@link pandemicMgmt.PandemicData#getCurrentPositiveOver60 <em>Current Positive Over60</em>}</li>
 *   <li>{@link pandemicMgmt.PandemicData#getCurrentCaseCount <em>Current Case Count</em>}</li>
 *   <li>{@link pandemicMgmt.PandemicData#getPreviousCaseCount <em>Previous Case Count</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData()
 * @model
 * @generated
 */
public interface PandemicData extends EObject {
	/**
	 * Returns the value of the '<em><b>Location</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Location#getPandemicdata <em>Pandemicdata</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' reference.
	 * @see #setLocation(Location)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData_Location()
	 * @see pandemicMgmt.Location#getPandemicdata
	 * @model opposite="pandemicdata"
	 * @generated
	 */
	Location getLocation();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicData#getLocation <em>Location</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' reference.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(Location value);

	/**
	 * Returns the value of the '<em><b>Current Tests Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Tests Count</em>' attribute.
	 * @see #setCurrentTestsCount(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData_CurrentTestsCount()
	 * @model required="true"
	 * @generated
	 */
	int getCurrentTestsCount();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicData#getCurrentTestsCount <em>Current Tests Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Tests Count</em>' attribute.
	 * @see #getCurrentTestsCount()
	 * @generated
	 */
	void setCurrentTestsCount(int value);

	/**
	 * Returns the value of the '<em><b>Previous Tests Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Previous Tests Count</em>' attribute.
	 * @see #setPreviousTestsCount(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData_PreviousTestsCount()
	 * @model required="true"
	 * @generated
	 */
	int getPreviousTestsCount();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicData#getPreviousTestsCount <em>Previous Tests Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Previous Tests Count</em>' attribute.
	 * @see #getPreviousTestsCount()
	 * @generated
	 */
	void setPreviousTestsCount(int value);

	/**
	 * Returns the value of the '<em><b>Current Positive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Positive</em>' attribute.
	 * @see #setCurrentPositive(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData_CurrentPositive()
	 * @model required="true"
	 * @generated
	 */
	int getCurrentPositive();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicData#getCurrentPositive <em>Current Positive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Positive</em>' attribute.
	 * @see #getCurrentPositive()
	 * @generated
	 */
	void setCurrentPositive(int value);

	/**
	 * Returns the value of the '<em><b>Current Positive Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Positive Over60</em>' attribute.
	 * @see #setCurrentPositiveOver60(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData_CurrentPositiveOver60()
	 * @model required="true"
	 * @generated
	 */
	int getCurrentPositiveOver60();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicData#getCurrentPositiveOver60 <em>Current Positive Over60</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Positive Over60</em>' attribute.
	 * @see #getCurrentPositiveOver60()
	 * @generated
	 */
	void setCurrentPositiveOver60(int value);

	/**
	 * Returns the value of the '<em><b>Current Case Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Case Count</em>' attribute.
	 * @see #setCurrentCaseCount(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData_CurrentCaseCount()
	 * @model required="true"
	 * @generated
	 */
	int getCurrentCaseCount();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicData#getCurrentCaseCount <em>Current Case Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Case Count</em>' attribute.
	 * @see #getCurrentCaseCount()
	 * @generated
	 */
	void setCurrentCaseCount(int value);

	/**
	 * Returns the value of the '<em><b>Previous Case Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Previous Case Count</em>' attribute.
	 * @see #setPreviousCaseCount(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicData_PreviousCaseCount()
	 * @model required="true"
	 * @generated
	 */
	int getPreviousCaseCount();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicData#getPreviousCaseCount <em>Previous Case Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Previous Case Count</em>' attribute.
	 * @see #getPreviousCaseCount()
	 * @generated
	 */
	void setPreviousCaseCount(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Float" required="true"
	 * @generated
	 */
	float RNaught();

} // PandemicData
