/**
 */
package pandemicMgmt;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see pandemicMgmt.PandemicMgmtPackage
 * @generated
 */
public interface PandemicMgmtFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PandemicMgmtFactory eINSTANCE = pandemicMgmt.impl.PandemicMgmtFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Pandemic Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pandemic Model</em>'.
	 * @generated
	 */
	PandemicModel createPandemicModel();

	/**
	 * Returns a new object of class '<em>Country</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Country</em>'.
	 * @generated
	 */
	Country createCountry();

	/**
	 * Returns a new object of class '<em>Pandemic Data</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pandemic Data</em>'.
	 * @generated
	 */
	PandemicData createPandemicData();

	/**
	 * Returns a new object of class '<em>Town</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Town</em>'.
	 * @generated
	 */
	Town createTown();

	/**
	 * Returns a new object of class '<em>House</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>House</em>'.
	 * @generated
	 */
	House createHouse();

	/**
	 * Returns a new object of class '<em>Person</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Person</em>'.
	 * @generated
	 */
	Person createPerson();

	/**
	 * Returns a new object of class '<em>Control Policy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Control Policy</em>'.
	 * @generated
	 */
	ControlPolicy createControlPolicy();

	/**
	 * Returns a new object of class '<em>Quarentine Centre</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Quarentine Centre</em>'.
	 * @generated
	 */
	QuarentineCentre createQuarentineCentre();

	/**
	 * Returns a new object of class '<em>Primary Health Unit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Primary Health Unit</em>'.
	 * @generated
	 */
	PrimaryHealthUnit createPrimaryHealthUnit();

	/**
	 * Returns a new object of class '<em>Secondary Health Unit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Secondary Health Unit</em>'.
	 * @generated
	 */
	SecondaryHealthUnit createSecondaryHealthUnit();

	/**
	 * Returns a new object of class '<em>Tertiary Health Unit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tertiary Health Unit</em>'.
	 * @generated
	 */
	TertiaryHealthUnit createTertiaryHealthUnit();

	/**
	 * Returns a new object of class '<em>Staff</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Staff</em>'.
	 * @generated
	 */
	Staff createStaff();

	/**
	 * Returns a new object of class '<em>Equipment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Equipment</em>'.
	 * @generated
	 */
	Equipment createEquipment();

	/**
	 * Returns a new object of class '<em>City</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>City</em>'.
	 * @generated
	 */
	City createCity();

	/**
	 * Returns a new object of class '<em>State</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>State</em>'.
	 * @generated
	 */
	State createState();

	/**
	 * Returns a new object of class '<em>HStreet</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>HStreet</em>'.
	 * @generated
	 */
	HStreet createHStreet();

	/**
	 * Returns a new object of class '<em>VStreet</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VStreet</em>'.
	 * @generated
	 */
	VStreet createVStreet();

	/**
	 * Returns a new object of class '<em>Pandemic</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pandemic</em>'.
	 * @generated
	 */
	Pandemic createPandemic();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	PandemicMgmtPackage getPandemicMgmtPackage();

} //PandemicMgmtFactory
