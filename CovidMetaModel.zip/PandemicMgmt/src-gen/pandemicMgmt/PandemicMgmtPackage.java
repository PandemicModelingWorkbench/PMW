/**
 */
package pandemicMgmt;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see pandemicMgmt.PandemicMgmtFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import ecore='http://www.eclipse.org/emf/2002/Ecore' ecore.xml.type='http://www.eclipse.org/emf/2003/XMLType'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface PandemicMgmtPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "pandemicMgmt";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/pandemicMgmt";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "pandemicMgmt";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PandemicMgmtPackage eINSTANCE = pandemicMgmt.impl.PandemicMgmtPackageImpl.init();

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.PandemicModelImpl <em>Pandemic Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.PandemicModelImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPandemicModel()
	 * @generated
	 */
	int PANDEMIC_MODEL = 21;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.LocationImpl <em>Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.LocationImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getLocation()
	 * @generated
	 */
	int LOCATION = 1;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.CountryImpl <em>Country</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.CountryImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getCountry()
	 * @generated
	 */
	int COUNTRY = 2;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.PandemicDataImpl <em>Pandemic Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.PandemicDataImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPandemicData()
	 * @generated
	 */
	int PANDEMIC_DATA = 3;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.ResourcesImpl <em>Resources</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.ResourcesImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getResources()
	 * @generated
	 */
	int RESOURCES = 4;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.TownImpl <em>Town</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.TownImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getTown()
	 * @generated
	 */
	int TOWN = 5;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.StreetImpl <em>Street</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.StreetImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getStreet()
	 * @generated
	 */
	int STREET = 6;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.HouseImpl <em>House</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.HouseImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getHouse()
	 * @generated
	 */
	int HOUSE = 7;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.PersonImpl <em>Person</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.PersonImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPerson()
	 * @generated
	 */
	int PERSON = 8;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.ControlPolicyImpl <em>Control Policy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.ControlPolicyImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getControlPolicy()
	 * @generated
	 */
	int CONTROL_POLICY = 9;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.HealthCentreImpl <em>Health Centre</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.HealthCentreImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getHealthCentre()
	 * @generated
	 */
	int HEALTH_CENTRE = 10;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.QuarentineCentreImpl <em>Quarentine Centre</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.QuarentineCentreImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getQuarentineCentre()
	 * @generated
	 */
	int QUARENTINE_CENTRE = 11;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.PrimaryHealthUnitImpl <em>Primary Health Unit</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.PrimaryHealthUnitImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPrimaryHealthUnit()
	 * @generated
	 */
	int PRIMARY_HEALTH_UNIT = 12;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.SecondaryHealthUnitImpl <em>Secondary Health Unit</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.SecondaryHealthUnitImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getSecondaryHealthUnit()
	 * @generated
	 */
	int SECONDARY_HEALTH_UNIT = 13;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.TertiaryHealthUnitImpl <em>Tertiary Health Unit</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.TertiaryHealthUnitImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getTertiaryHealthUnit()
	 * @generated
	 */
	int TERTIARY_HEALTH_UNIT = 14;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.StaffImpl <em>Staff</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.StaffImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getStaff()
	 * @generated
	 */
	int STAFF = 15;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.EquipmentImpl <em>Equipment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.EquipmentImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getEquipment()
	 * @generated
	 */
	int EQUIPMENT = 16;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.CityImpl <em>City</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.CityImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getCity()
	 * @generated
	 */
	int CITY = 17;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.StateImpl <em>State</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.StateImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getState()
	 * @generated
	 */
	int STATE = 18;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.HStreetImpl <em>HStreet</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.HStreetImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getHStreet()
	 * @generated
	 */
	int HSTREET = 19;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.VStreetImpl <em>VStreet</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.VStreetImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getVStreet()
	 * @generated
	 */
	int VSTREET = 20;

	/**
	 * The meta object id for the '{@link pandemicMgmt.impl.PandemicImpl <em>Pandemic</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.impl.PandemicImpl
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPandemic()
	 * @generated
	 */
	int PANDEMIC = 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC__LOCATION = 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC__PANDEMICDATA = 1;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC__RESOURCES = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC__NAME = 3;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC__CONTROLPOLICY = 4;

	/**
	 * The feature id for the '<em><b>Person</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC__PERSON = 5;

	/**
	 * The number of structural features of the '<em>Pandemic</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Pandemic</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__PANDEMICDATA = 0;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__CURRENT_TIER = 1;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__CONTROLPOLICY = 2;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__RESOURCES = 3;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__POPULATION = 4;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__POPULATION_OVER60 = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__NAME = 6;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__HEALTHY = 7;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__INFECTED = 8;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__RECOVERED = 9;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__LOCATION = 10;

	/**
	 * The number of structural features of the '<em>Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION_FEATURE_COUNT = 11;

	/**
	 * The number of operations of the '<em>Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__PANDEMICDATA = LOCATION__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__CURRENT_TIER = LOCATION__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__CONTROLPOLICY = LOCATION__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__RESOURCES = LOCATION__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__POPULATION = LOCATION__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__POPULATION_OVER60 = LOCATION__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__NAME = LOCATION__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__HEALTHY = LOCATION__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__INFECTED = LOCATION__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__RECOVERED = LOCATION__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__LOCATION = LOCATION__LOCATION;

	/**
	 * The feature id for the '<em><b>Country Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__COUNTRY_CODE = LOCATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY__STATE = LOCATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Country</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY_FEATURE_COUNT = LOCATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Country</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUNTRY_OPERATION_COUNT = LOCATION_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA__LOCATION = 0;

	/**
	 * The feature id for the '<em><b>Current Tests Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA__CURRENT_TESTS_COUNT = 1;

	/**
	 * The feature id for the '<em><b>Previous Tests Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA__PREVIOUS_TESTS_COUNT = 2;

	/**
	 * The feature id for the '<em><b>Current Positive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA__CURRENT_POSITIVE = 3;

	/**
	 * The feature id for the '<em><b>Current Positive Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA__CURRENT_POSITIVE_OVER60 = 4;

	/**
	 * The feature id for the '<em><b>Current Case Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA__CURRENT_CASE_COUNT = 5;

	/**
	 * The feature id for the '<em><b>Previous Case Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA__PREVIOUS_CASE_COUNT = 6;

	/**
	 * The number of structural features of the '<em>Pandemic Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA_FEATURE_COUNT = 7;

	/**
	 * The operation id for the '<em>RNaught</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA___RNAUGHT = 0;

	/**
	 * The number of operations of the '<em>Pandemic Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_DATA_OPERATION_COUNT = 1;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCES__LOCATION = 0;

	/**
	 * The number of structural features of the '<em>Resources</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCES_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Resources</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCES_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__PANDEMICDATA = LOCATION__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__CURRENT_TIER = LOCATION__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__CONTROLPOLICY = LOCATION__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__RESOURCES = LOCATION__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__POPULATION = LOCATION__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__POPULATION_OVER60 = LOCATION__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__NAME = LOCATION__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__HEALTHY = LOCATION__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__INFECTED = LOCATION__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__RECOVERED = LOCATION__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__LOCATION = LOCATION__LOCATION;

	/**
	 * The feature id for the '<em><b>Town ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__TOWN_ID = LOCATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>City</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__CITY = LOCATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Street</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN__STREET = LOCATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Town</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN_FEATURE_COUNT = LOCATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Town</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOWN_OPERATION_COUNT = LOCATION_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__PANDEMICDATA = LOCATION__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__CURRENT_TIER = LOCATION__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__CONTROLPOLICY = LOCATION__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__RESOURCES = LOCATION__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__POPULATION = LOCATION__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__POPULATION_OVER60 = LOCATION__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__NAME = LOCATION__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__HEALTHY = LOCATION__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__INFECTED = LOCATION__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__RECOVERED = LOCATION__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__LOCATION = LOCATION__LOCATION;

	/**
	 * The feature id for the '<em><b>Street ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__STREET_ID = LOCATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Town</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__TOWN = LOCATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>House</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET__HOUSE = LOCATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Street</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET_FEATURE_COUNT = LOCATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Street</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET_OPERATION_COUNT = LOCATION_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__PANDEMICDATA = LOCATION__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__CURRENT_TIER = LOCATION__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__CONTROLPOLICY = LOCATION__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__RESOURCES = LOCATION__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__POPULATION = LOCATION__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__POPULATION_OVER60 = LOCATION__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__NAME = LOCATION__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__HEALTHY = LOCATION__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__INFECTED = LOCATION__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__RECOVERED = LOCATION__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__LOCATION = LOCATION__LOCATION;

	/**
	 * The feature id for the '<em><b>House ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__HOUSE_ID = LOCATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Person</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__PERSON = LOCATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Street</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__STREET = LOCATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>House</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE_FEATURE_COUNT = LOCATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>House</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE_OPERATION_COUNT = LOCATION_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__ID = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__NAME = 1;

	/**
	 * The feature id for the '<em><b>Gender</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__GENDER = 2;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__AGE = 3;

	/**
	 * The feature id for the '<em><b>House</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__HOUSE = 4;

	/**
	 * The number of structural features of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__LOCATION = 0;

	/**
	 * The feature id for the '<em><b>Case Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__CASE_RATE = 1;

	/**
	 * The feature id for the '<em><b>Bedsper Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__BEDSPER_POPULATION = 2;

	/**
	 * The feature id for the '<em><b>Positivity Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__POSITIVITY_RATE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__NAME = 4;

	/**
	 * The feature id for the '<em><b>Case Detection Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__CASE_DETECTION_RATE = 5;

	/**
	 * The feature id for the '<em><b>Vents Per Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__VENTS_PER_POPULATION = 6;

	/**
	 * The feature id for the '<em><b>Testing Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__TESTING_RATE = 7;

	/**
	 * The feature id for the '<em><b>Doctors Per Patient</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__DOCTORS_PER_PATIENT = 8;

	/**
	 * The feature id for the '<em><b>Set Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY__SET_TIER = 9;

	/**
	 * The number of structural features of the '<em>Control Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY_FEATURE_COUNT = 10;

	/**
	 * The operation id for the '<em>Set Control Parameters</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY___SET_CONTROL_PARAMETERS = 0;

	/**
	 * The number of operations of the '<em>Control Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_POLICY_OPERATION_COUNT = 1;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_CENTRE__LOCATION = RESOURCES__LOCATION;

	/**
	 * The feature id for the '<em><b>Staff</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_CENTRE__STAFF = RESOURCES_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Equipment</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_CENTRE__EQUIPMENT = RESOURCES_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_CENTRE__NAME = RESOURCES_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Beds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_CENTRE__BEDS = RESOURCES_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Health Centre</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_CENTRE_FEATURE_COUNT = RESOURCES_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Health Centre</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_CENTRE_OPERATION_COUNT = RESOURCES_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUARENTINE_CENTRE__LOCATION = HEALTH_CENTRE__LOCATION;

	/**
	 * The feature id for the '<em><b>Staff</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUARENTINE_CENTRE__STAFF = HEALTH_CENTRE__STAFF;

	/**
	 * The feature id for the '<em><b>Equipment</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUARENTINE_CENTRE__EQUIPMENT = HEALTH_CENTRE__EQUIPMENT;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUARENTINE_CENTRE__NAME = HEALTH_CENTRE__NAME;

	/**
	 * The feature id for the '<em><b>Beds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUARENTINE_CENTRE__BEDS = HEALTH_CENTRE__BEDS;

	/**
	 * The number of structural features of the '<em>Quarentine Centre</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUARENTINE_CENTRE_FEATURE_COUNT = HEALTH_CENTRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Quarentine Centre</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUARENTINE_CENTRE_OPERATION_COUNT = HEALTH_CENTRE_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMARY_HEALTH_UNIT__LOCATION = HEALTH_CENTRE__LOCATION;

	/**
	 * The feature id for the '<em><b>Staff</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMARY_HEALTH_UNIT__STAFF = HEALTH_CENTRE__STAFF;

	/**
	 * The feature id for the '<em><b>Equipment</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMARY_HEALTH_UNIT__EQUIPMENT = HEALTH_CENTRE__EQUIPMENT;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMARY_HEALTH_UNIT__NAME = HEALTH_CENTRE__NAME;

	/**
	 * The feature id for the '<em><b>Beds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMARY_HEALTH_UNIT__BEDS = HEALTH_CENTRE__BEDS;

	/**
	 * The number of structural features of the '<em>Primary Health Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMARY_HEALTH_UNIT_FEATURE_COUNT = HEALTH_CENTRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Primary Health Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMARY_HEALTH_UNIT_OPERATION_COUNT = HEALTH_CENTRE_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECONDARY_HEALTH_UNIT__LOCATION = HEALTH_CENTRE__LOCATION;

	/**
	 * The feature id for the '<em><b>Staff</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECONDARY_HEALTH_UNIT__STAFF = HEALTH_CENTRE__STAFF;

	/**
	 * The feature id for the '<em><b>Equipment</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECONDARY_HEALTH_UNIT__EQUIPMENT = HEALTH_CENTRE__EQUIPMENT;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECONDARY_HEALTH_UNIT__NAME = HEALTH_CENTRE__NAME;

	/**
	 * The feature id for the '<em><b>Beds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECONDARY_HEALTH_UNIT__BEDS = HEALTH_CENTRE__BEDS;

	/**
	 * The number of structural features of the '<em>Secondary Health Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECONDARY_HEALTH_UNIT_FEATURE_COUNT = HEALTH_CENTRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Secondary Health Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECONDARY_HEALTH_UNIT_OPERATION_COUNT = HEALTH_CENTRE_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERTIARY_HEALTH_UNIT__LOCATION = HEALTH_CENTRE__LOCATION;

	/**
	 * The feature id for the '<em><b>Staff</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERTIARY_HEALTH_UNIT__STAFF = HEALTH_CENTRE__STAFF;

	/**
	 * The feature id for the '<em><b>Equipment</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERTIARY_HEALTH_UNIT__EQUIPMENT = HEALTH_CENTRE__EQUIPMENT;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERTIARY_HEALTH_UNIT__NAME = HEALTH_CENTRE__NAME;

	/**
	 * The feature id for the '<em><b>Beds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERTIARY_HEALTH_UNIT__BEDS = HEALTH_CENTRE__BEDS;

	/**
	 * The number of structural features of the '<em>Tertiary Health Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERTIARY_HEALTH_UNIT_FEATURE_COUNT = HEALTH_CENTRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Tertiary Health Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERTIARY_HEALTH_UNIT_OPERATION_COUNT = HEALTH_CENTRE_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF__LOCATION = RESOURCES__LOCATION;

	/**
	 * The feature id for the '<em><b>Healthcentre</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF__HEALTHCENTRE = RESOURCES_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Doctors</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF__DOCTORS = RESOURCES_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Nurses</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF__NURSES = RESOURCES_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Paramedics</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF__PARAMEDICS = RESOURCES_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Staff</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF_FEATURE_COUNT = RESOURCES_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Staff</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF_OPERATION_COUNT = RESOURCES_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__LOCATION = RESOURCES__LOCATION;

	/**
	 * The feature id for the '<em><b>Ventilators</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__VENTILATORS = RESOURCES_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>PP Es</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__PP_ES = RESOURCES_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Vaccines</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__VACCINES = RESOURCES_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Healthcentre</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__HEALTHCENTRE = RESOURCES_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Test Kits</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__TEST_KITS = RESOURCES_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Ambulances</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__AMBULANCES = RESOURCES_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Equipment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_FEATURE_COUNT = RESOURCES_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Equipment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_OPERATION_COUNT = RESOURCES_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__PANDEMICDATA = LOCATION__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__CURRENT_TIER = LOCATION__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__CONTROLPOLICY = LOCATION__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__RESOURCES = LOCATION__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__POPULATION = LOCATION__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__POPULATION_OVER60 = LOCATION__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__NAME = LOCATION__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__HEALTHY = LOCATION__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__INFECTED = LOCATION__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__RECOVERED = LOCATION__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__LOCATION = LOCATION__LOCATION;

	/**
	 * The feature id for the '<em><b>City Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__CITY_CODE = LOCATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__STATE = LOCATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Town</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY__TOWN = LOCATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>City</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_FEATURE_COUNT = LOCATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>City</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_OPERATION_COUNT = LOCATION_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__PANDEMICDATA = LOCATION__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__CURRENT_TIER = LOCATION__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__CONTROLPOLICY = LOCATION__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__RESOURCES = LOCATION__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__POPULATION = LOCATION__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__POPULATION_OVER60 = LOCATION__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__NAME = LOCATION__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__HEALTHY = LOCATION__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__INFECTED = LOCATION__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__RECOVERED = LOCATION__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__LOCATION = LOCATION__LOCATION;

	/**
	 * The feature id for the '<em><b>State Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__STATE_CODE = LOCATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Country</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__COUNTRY = LOCATION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>City</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__CITY = LOCATION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_FEATURE_COUNT = LOCATION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_OPERATION_COUNT = LOCATION_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__PANDEMICDATA = STREET__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__CURRENT_TIER = STREET__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__CONTROLPOLICY = STREET__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__RESOURCES = STREET__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__POPULATION = STREET__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__POPULATION_OVER60 = STREET__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__NAME = STREET__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__HEALTHY = STREET__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__INFECTED = STREET__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__RECOVERED = STREET__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__LOCATION = STREET__LOCATION;

	/**
	 * The feature id for the '<em><b>Street ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__STREET_ID = STREET__STREET_ID;

	/**
	 * The feature id for the '<em><b>Town</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__TOWN = STREET__TOWN;

	/**
	 * The feature id for the '<em><b>House</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET__HOUSE = STREET__HOUSE;

	/**
	 * The number of structural features of the '<em>HStreet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET_FEATURE_COUNT = STREET_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>HStreet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HSTREET_OPERATION_COUNT = STREET_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pandemicdata</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__PANDEMICDATA = STREET__PANDEMICDATA;

	/**
	 * The feature id for the '<em><b>Current Tier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__CURRENT_TIER = STREET__CURRENT_TIER;

	/**
	 * The feature id for the '<em><b>Controlpolicy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__CONTROLPOLICY = STREET__CONTROLPOLICY;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__RESOURCES = STREET__RESOURCES;

	/**
	 * The feature id for the '<em><b>Population</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__POPULATION = STREET__POPULATION;

	/**
	 * The feature id for the '<em><b>Population Over60</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__POPULATION_OVER60 = STREET__POPULATION_OVER60;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__NAME = STREET__NAME;

	/**
	 * The feature id for the '<em><b>Healthy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__HEALTHY = STREET__HEALTHY;

	/**
	 * The feature id for the '<em><b>Infected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__INFECTED = STREET__INFECTED;

	/**
	 * The feature id for the '<em><b>Recovered</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__RECOVERED = STREET__RECOVERED;

	/**
	 * The feature id for the '<em><b>Location</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__LOCATION = STREET__LOCATION;

	/**
	 * The feature id for the '<em><b>Street ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__STREET_ID = STREET__STREET_ID;

	/**
	 * The feature id for the '<em><b>Town</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__TOWN = STREET__TOWN;

	/**
	 * The feature id for the '<em><b>House</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET__HOUSE = STREET__HOUSE;

	/**
	 * The number of structural features of the '<em>VStreet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET_FEATURE_COUNT = STREET_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>VStreet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VSTREET_OPERATION_COUNT = STREET_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pandemic</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_MODEL__PANDEMIC = 0;

	/**
	 * The feature id for the '<em><b>Model ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_MODEL__MODEL_ID = 1;

	/**
	 * The number of structural features of the '<em>Pandemic Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_MODEL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Pandemic Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PANDEMIC_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link pandemicMgmt.LLevel <em>LLevel</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.LLevel
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getLLevel()
	 * @generated
	 */
	int LLEVEL = 22;

	/**
	 * The meta object id for the '{@link pandemicMgmt.Gender <em>Gender</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see pandemicMgmt.Gender
	 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getGender()
	 * @generated
	 */
	int GENDER = 23;

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.PandemicModel <em>Pandemic Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pandemic Model</em>'.
	 * @see pandemicMgmt.PandemicModel
	 * @generated
	 */
	EClass getPandemicModel();

	/**
	 * Returns the meta object for the containment reference list '{@link pandemicMgmt.PandemicModel#getPandemic <em>Pandemic</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pandemic</em>'.
	 * @see pandemicMgmt.PandemicModel#getPandemic()
	 * @see #getPandemicModel()
	 * @generated
	 */
	EReference getPandemicModel_Pandemic();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.PandemicModel#getModelID <em>Model ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Model ID</em>'.
	 * @see pandemicMgmt.PandemicModel#getModelID()
	 * @see #getPandemicModel()
	 * @generated
	 */
	EAttribute getPandemicModel_ModelID();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Location <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Location</em>'.
	 * @see pandemicMgmt.Location
	 * @generated
	 */
	EClass getLocation();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Location#getPandemicdata <em>Pandemicdata</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Pandemicdata</em>'.
	 * @see pandemicMgmt.Location#getPandemicdata()
	 * @see #getLocation()
	 * @generated
	 */
	EReference getLocation_Pandemicdata();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Location#getCurrentTier <em>Current Tier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Tier</em>'.
	 * @see pandemicMgmt.Location#getCurrentTier()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_CurrentTier();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Location#getControlpolicy <em>Controlpolicy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Controlpolicy</em>'.
	 * @see pandemicMgmt.Location#getControlpolicy()
	 * @see #getLocation()
	 * @generated
	 */
	EReference getLocation_Controlpolicy();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.Location#getResources <em>Resources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Resources</em>'.
	 * @see pandemicMgmt.Location#getResources()
	 * @see #getLocation()
	 * @generated
	 */
	EReference getLocation_Resources();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Location#getPopulation <em>Population</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Population</em>'.
	 * @see pandemicMgmt.Location#getPopulation()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_Population();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Location#getPopulationOver60 <em>Population Over60</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Population Over60</em>'.
	 * @see pandemicMgmt.Location#getPopulationOver60()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_PopulationOver60();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Location#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see pandemicMgmt.Location#getName()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_Name();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Location#getHealthy <em>Healthy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Healthy</em>'.
	 * @see pandemicMgmt.Location#getHealthy()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_Healthy();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Location#getInfected <em>Infected</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Infected</em>'.
	 * @see pandemicMgmt.Location#getInfected()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_Infected();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Location#getRecovered <em>Recovered</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Recovered</em>'.
	 * @see pandemicMgmt.Location#getRecovered()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_Recovered();

	/**
	 * Returns the meta object for the containment reference list '{@link pandemicMgmt.Location#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Location</em>'.
	 * @see pandemicMgmt.Location#getLocation()
	 * @see #getLocation()
	 * @generated
	 */
	EReference getLocation_Location();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Country <em>Country</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Country</em>'.
	 * @see pandemicMgmt.Country
	 * @generated
	 */
	EClass getCountry();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Country#getCountryCode <em>Country Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Country Code</em>'.
	 * @see pandemicMgmt.Country#getCountryCode()
	 * @see #getCountry()
	 * @generated
	 */
	EAttribute getCountry_CountryCode();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.Country#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>State</em>'.
	 * @see pandemicMgmt.Country#getState()
	 * @see #getCountry()
	 * @generated
	 */
	EReference getCountry_State();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.PandemicData <em>Pandemic Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pandemic Data</em>'.
	 * @see pandemicMgmt.PandemicData
	 * @generated
	 */
	EClass getPandemicData();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.PandemicData#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Location</em>'.
	 * @see pandemicMgmt.PandemicData#getLocation()
	 * @see #getPandemicData()
	 * @generated
	 */
	EReference getPandemicData_Location();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.PandemicData#getCurrentTestsCount <em>Current Tests Count</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Tests Count</em>'.
	 * @see pandemicMgmt.PandemicData#getCurrentTestsCount()
	 * @see #getPandemicData()
	 * @generated
	 */
	EAttribute getPandemicData_CurrentTestsCount();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.PandemicData#getPreviousTestsCount <em>Previous Tests Count</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Previous Tests Count</em>'.
	 * @see pandemicMgmt.PandemicData#getPreviousTestsCount()
	 * @see #getPandemicData()
	 * @generated
	 */
	EAttribute getPandemicData_PreviousTestsCount();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.PandemicData#getCurrentPositive <em>Current Positive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Positive</em>'.
	 * @see pandemicMgmt.PandemicData#getCurrentPositive()
	 * @see #getPandemicData()
	 * @generated
	 */
	EAttribute getPandemicData_CurrentPositive();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.PandemicData#getCurrentPositiveOver60 <em>Current Positive Over60</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Positive Over60</em>'.
	 * @see pandemicMgmt.PandemicData#getCurrentPositiveOver60()
	 * @see #getPandemicData()
	 * @generated
	 */
	EAttribute getPandemicData_CurrentPositiveOver60();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.PandemicData#getCurrentCaseCount <em>Current Case Count</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Case Count</em>'.
	 * @see pandemicMgmt.PandemicData#getCurrentCaseCount()
	 * @see #getPandemicData()
	 * @generated
	 */
	EAttribute getPandemicData_CurrentCaseCount();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.PandemicData#getPreviousCaseCount <em>Previous Case Count</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Previous Case Count</em>'.
	 * @see pandemicMgmt.PandemicData#getPreviousCaseCount()
	 * @see #getPandemicData()
	 * @generated
	 */
	EAttribute getPandemicData_PreviousCaseCount();

	/**
	 * Returns the meta object for the '{@link pandemicMgmt.PandemicData#RNaught() <em>RNaught</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>RNaught</em>' operation.
	 * @see pandemicMgmt.PandemicData#RNaught()
	 * @generated
	 */
	EOperation getPandemicData__RNaught();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Resources <em>Resources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Resources</em>'.
	 * @see pandemicMgmt.Resources
	 * @generated
	 */
	EClass getResources();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Resources#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Location</em>'.
	 * @see pandemicMgmt.Resources#getLocation()
	 * @see #getResources()
	 * @generated
	 */
	EReference getResources_Location();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Town <em>Town</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Town</em>'.
	 * @see pandemicMgmt.Town
	 * @generated
	 */
	EClass getTown();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Town#getTownID <em>Town ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Town ID</em>'.
	 * @see pandemicMgmt.Town#getTownID()
	 * @see #getTown()
	 * @generated
	 */
	EAttribute getTown_TownID();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Town#getCity <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>City</em>'.
	 * @see pandemicMgmt.Town#getCity()
	 * @see #getTown()
	 * @generated
	 */
	EReference getTown_City();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.Town#getStreet <em>Street</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Street</em>'.
	 * @see pandemicMgmt.Town#getStreet()
	 * @see #getTown()
	 * @generated
	 */
	EReference getTown_Street();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Street <em>Street</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Street</em>'.
	 * @see pandemicMgmt.Street
	 * @generated
	 */
	EClass getStreet();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Street#getStreetID <em>Street ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Street ID</em>'.
	 * @see pandemicMgmt.Street#getStreetID()
	 * @see #getStreet()
	 * @generated
	 */
	EAttribute getStreet_StreetID();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Street#getTown <em>Town</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Town</em>'.
	 * @see pandemicMgmt.Street#getTown()
	 * @see #getStreet()
	 * @generated
	 */
	EReference getStreet_Town();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.Street#getHouse <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>House</em>'.
	 * @see pandemicMgmt.Street#getHouse()
	 * @see #getStreet()
	 * @generated
	 */
	EReference getStreet_House();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.House <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>House</em>'.
	 * @see pandemicMgmt.House
	 * @generated
	 */
	EClass getHouse();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.House#getHouseID <em>House ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>House ID</em>'.
	 * @see pandemicMgmt.House#getHouseID()
	 * @see #getHouse()
	 * @generated
	 */
	EAttribute getHouse_HouseID();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.House#getPerson <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Person</em>'.
	 * @see pandemicMgmt.House#getPerson()
	 * @see #getHouse()
	 * @generated
	 */
	EReference getHouse_Person();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.House#getStreet <em>Street</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Street</em>'.
	 * @see pandemicMgmt.House#getStreet()
	 * @see #getHouse()
	 * @generated
	 */
	EReference getHouse_Street();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Person <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Person</em>'.
	 * @see pandemicMgmt.Person
	 * @generated
	 */
	EClass getPerson();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Person#getID <em>ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>ID</em>'.
	 * @see pandemicMgmt.Person#getID()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_ID();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Person#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see pandemicMgmt.Person#getName()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Name();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Person#getGender <em>Gender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Gender</em>'.
	 * @see pandemicMgmt.Person#getGender()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Gender();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Person#getAge <em>Age</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Age</em>'.
	 * @see pandemicMgmt.Person#getAge()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Age();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Person#getHouse <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>House</em>'.
	 * @see pandemicMgmt.Person#getHouse()
	 * @see #getPerson()
	 * @generated
	 */
	EReference getPerson_House();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.ControlPolicy <em>Control Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Control Policy</em>'.
	 * @see pandemicMgmt.ControlPolicy
	 * @generated
	 */
	EClass getControlPolicy();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.ControlPolicy#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Location</em>'.
	 * @see pandemicMgmt.ControlPolicy#getLocation()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EReference getControlPolicy_Location();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getCaseRate <em>Case Rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Case Rate</em>'.
	 * @see pandemicMgmt.ControlPolicy#getCaseRate()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_CaseRate();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getBedsperPopulation <em>Bedsper Population</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bedsper Population</em>'.
	 * @see pandemicMgmt.ControlPolicy#getBedsperPopulation()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_BedsperPopulation();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getPositivityRate <em>Positivity Rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Positivity Rate</em>'.
	 * @see pandemicMgmt.ControlPolicy#getPositivityRate()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_PositivityRate();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see pandemicMgmt.ControlPolicy#getName()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_Name();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getCaseDetectionRate <em>Case Detection Rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Case Detection Rate</em>'.
	 * @see pandemicMgmt.ControlPolicy#getCaseDetectionRate()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_CaseDetectionRate();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getVentsPerPopulation <em>Vents Per Population</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vents Per Population</em>'.
	 * @see pandemicMgmt.ControlPolicy#getVentsPerPopulation()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_VentsPerPopulation();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getTestingRate <em>Testing Rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Testing Rate</em>'.
	 * @see pandemicMgmt.ControlPolicy#getTestingRate()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_TestingRate();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getDoctorsPerPatient <em>Doctors Per Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Doctors Per Patient</em>'.
	 * @see pandemicMgmt.ControlPolicy#getDoctorsPerPatient()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_DoctorsPerPatient();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.ControlPolicy#getSetTier <em>Set Tier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Set Tier</em>'.
	 * @see pandemicMgmt.ControlPolicy#getSetTier()
	 * @see #getControlPolicy()
	 * @generated
	 */
	EAttribute getControlPolicy_SetTier();

	/**
	 * Returns the meta object for the '{@link pandemicMgmt.ControlPolicy#SetControlParameters() <em>Set Control Parameters</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Control Parameters</em>' operation.
	 * @see pandemicMgmt.ControlPolicy#SetControlParameters()
	 * @generated
	 */
	EOperation getControlPolicy__SetControlParameters();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.HealthCentre <em>Health Centre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Health Centre</em>'.
	 * @see pandemicMgmt.HealthCentre
	 * @generated
	 */
	EClass getHealthCentre();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.HealthCentre#getStaff <em>Staff</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Staff</em>'.
	 * @see pandemicMgmt.HealthCentre#getStaff()
	 * @see #getHealthCentre()
	 * @generated
	 */
	EReference getHealthCentre_Staff();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.HealthCentre#getEquipment <em>Equipment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Equipment</em>'.
	 * @see pandemicMgmt.HealthCentre#getEquipment()
	 * @see #getHealthCentre()
	 * @generated
	 */
	EReference getHealthCentre_Equipment();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.HealthCentre#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see pandemicMgmt.HealthCentre#getName()
	 * @see #getHealthCentre()
	 * @generated
	 */
	EAttribute getHealthCentre_Name();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.HealthCentre#getBeds <em>Beds</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Beds</em>'.
	 * @see pandemicMgmt.HealthCentre#getBeds()
	 * @see #getHealthCentre()
	 * @generated
	 */
	EAttribute getHealthCentre_Beds();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.QuarentineCentre <em>Quarentine Centre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Quarentine Centre</em>'.
	 * @see pandemicMgmt.QuarentineCentre
	 * @generated
	 */
	EClass getQuarentineCentre();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.PrimaryHealthUnit <em>Primary Health Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Primary Health Unit</em>'.
	 * @see pandemicMgmt.PrimaryHealthUnit
	 * @generated
	 */
	EClass getPrimaryHealthUnit();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.SecondaryHealthUnit <em>Secondary Health Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Secondary Health Unit</em>'.
	 * @see pandemicMgmt.SecondaryHealthUnit
	 * @generated
	 */
	EClass getSecondaryHealthUnit();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.TertiaryHealthUnit <em>Tertiary Health Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tertiary Health Unit</em>'.
	 * @see pandemicMgmt.TertiaryHealthUnit
	 * @generated
	 */
	EClass getTertiaryHealthUnit();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Staff <em>Staff</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Staff</em>'.
	 * @see pandemicMgmt.Staff
	 * @generated
	 */
	EClass getStaff();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Staff#getHealthcentre <em>Healthcentre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Healthcentre</em>'.
	 * @see pandemicMgmt.Staff#getHealthcentre()
	 * @see #getStaff()
	 * @generated
	 */
	EReference getStaff_Healthcentre();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Staff#getDoctors <em>Doctors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Doctors</em>'.
	 * @see pandemicMgmt.Staff#getDoctors()
	 * @see #getStaff()
	 * @generated
	 */
	EAttribute getStaff_Doctors();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Staff#getNurses <em>Nurses</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nurses</em>'.
	 * @see pandemicMgmt.Staff#getNurses()
	 * @see #getStaff()
	 * @generated
	 */
	EAttribute getStaff_Nurses();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Staff#getParamedics <em>Paramedics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Paramedics</em>'.
	 * @see pandemicMgmt.Staff#getParamedics()
	 * @see #getStaff()
	 * @generated
	 */
	EAttribute getStaff_Paramedics();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Equipment <em>Equipment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Equipment</em>'.
	 * @see pandemicMgmt.Equipment
	 * @generated
	 */
	EClass getEquipment();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Equipment#getVentilators <em>Ventilators</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ventilators</em>'.
	 * @see pandemicMgmt.Equipment#getVentilators()
	 * @see #getEquipment()
	 * @generated
	 */
	EAttribute getEquipment_Ventilators();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Equipment#getPPEs <em>PP Es</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>PP Es</em>'.
	 * @see pandemicMgmt.Equipment#getPPEs()
	 * @see #getEquipment()
	 * @generated
	 */
	EAttribute getEquipment_PPEs();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Equipment#getVaccines <em>Vaccines</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vaccines</em>'.
	 * @see pandemicMgmt.Equipment#getVaccines()
	 * @see #getEquipment()
	 * @generated
	 */
	EAttribute getEquipment_Vaccines();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.Equipment#getHealthcentre <em>Healthcentre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Healthcentre</em>'.
	 * @see pandemicMgmt.Equipment#getHealthcentre()
	 * @see #getEquipment()
	 * @generated
	 */
	EReference getEquipment_Healthcentre();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Equipment#getTestKits <em>Test Kits</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Test Kits</em>'.
	 * @see pandemicMgmt.Equipment#getTestKits()
	 * @see #getEquipment()
	 * @generated
	 */
	EAttribute getEquipment_TestKits();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Equipment#getAmbulances <em>Ambulances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ambulances</em>'.
	 * @see pandemicMgmt.Equipment#getAmbulances()
	 * @see #getEquipment()
	 * @generated
	 */
	EAttribute getEquipment_Ambulances();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.City <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>City</em>'.
	 * @see pandemicMgmt.City
	 * @generated
	 */
	EClass getCity();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.City#getCityCode <em>City Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>City Code</em>'.
	 * @see pandemicMgmt.City#getCityCode()
	 * @see #getCity()
	 * @generated
	 */
	EAttribute getCity_CityCode();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.City#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>State</em>'.
	 * @see pandemicMgmt.City#getState()
	 * @see #getCity()
	 * @generated
	 */
	EReference getCity_State();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.City#getTown <em>Town</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Town</em>'.
	 * @see pandemicMgmt.City#getTown()
	 * @see #getCity()
	 * @generated
	 */
	EReference getCity_Town();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.State <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State</em>'.
	 * @see pandemicMgmt.State
	 * @generated
	 */
	EClass getState();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.State#getStateCode <em>State Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>State Code</em>'.
	 * @see pandemicMgmt.State#getStateCode()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_StateCode();

	/**
	 * Returns the meta object for the reference '{@link pandemicMgmt.State#getCountry <em>Country</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Country</em>'.
	 * @see pandemicMgmt.State#getCountry()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Country();

	/**
	 * Returns the meta object for the reference list '{@link pandemicMgmt.State#getCity <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>City</em>'.
	 * @see pandemicMgmt.State#getCity()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_City();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.HStreet <em>HStreet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>HStreet</em>'.
	 * @see pandemicMgmt.HStreet
	 * @generated
	 */
	EClass getHStreet();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.VStreet <em>VStreet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>VStreet</em>'.
	 * @see pandemicMgmt.VStreet
	 * @generated
	 */
	EClass getVStreet();

	/**
	 * Returns the meta object for class '{@link pandemicMgmt.Pandemic <em>Pandemic</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pandemic</em>'.
	 * @see pandemicMgmt.Pandemic
	 * @generated
	 */
	EClass getPandemic();

	/**
	 * Returns the meta object for the containment reference list '{@link pandemicMgmt.Pandemic#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Location</em>'.
	 * @see pandemicMgmt.Pandemic#getLocation()
	 * @see #getPandemic()
	 * @generated
	 */
	EReference getPandemic_Location();

	/**
	 * Returns the meta object for the containment reference list '{@link pandemicMgmt.Pandemic#getPandemicdata <em>Pandemicdata</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pandemicdata</em>'.
	 * @see pandemicMgmt.Pandemic#getPandemicdata()
	 * @see #getPandemic()
	 * @generated
	 */
	EReference getPandemic_Pandemicdata();

	/**
	 * Returns the meta object for the containment reference list '{@link pandemicMgmt.Pandemic#getResources <em>Resources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Resources</em>'.
	 * @see pandemicMgmt.Pandemic#getResources()
	 * @see #getPandemic()
	 * @generated
	 */
	EReference getPandemic_Resources();

	/**
	 * Returns the meta object for the attribute '{@link pandemicMgmt.Pandemic#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see pandemicMgmt.Pandemic#getName()
	 * @see #getPandemic()
	 * @generated
	 */
	EAttribute getPandemic_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link pandemicMgmt.Pandemic#getControlpolicy <em>Controlpolicy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Controlpolicy</em>'.
	 * @see pandemicMgmt.Pandemic#getControlpolicy()
	 * @see #getPandemic()
	 * @generated
	 */
	EReference getPandemic_Controlpolicy();

	/**
	 * Returns the meta object for the containment reference list '{@link pandemicMgmt.Pandemic#getPerson <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Person</em>'.
	 * @see pandemicMgmt.Pandemic#getPerson()
	 * @see #getPandemic()
	 * @generated
	 */
	EReference getPandemic_Person();

	/**
	 * Returns the meta object for enum '{@link pandemicMgmt.LLevel <em>LLevel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>LLevel</em>'.
	 * @see pandemicMgmt.LLevel
	 * @generated
	 */
	EEnum getLLevel();

	/**
	 * Returns the meta object for enum '{@link pandemicMgmt.Gender <em>Gender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Gender</em>'.
	 * @see pandemicMgmt.Gender
	 * @generated
	 */
	EEnum getGender();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PandemicMgmtFactory getPandemicMgmtFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.PandemicModelImpl <em>Pandemic Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.PandemicModelImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPandemicModel()
		 * @generated
		 */
		EClass PANDEMIC_MODEL = eINSTANCE.getPandemicModel();

		/**
		 * The meta object literal for the '<em><b>Pandemic</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PANDEMIC_MODEL__PANDEMIC = eINSTANCE.getPandemicModel_Pandemic();

		/**
		 * The meta object literal for the '<em><b>Model ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC_MODEL__MODEL_ID = eINSTANCE.getPandemicModel_ModelID();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.LocationImpl <em>Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.LocationImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getLocation()
		 * @generated
		 */
		EClass LOCATION = eINSTANCE.getLocation();

		/**
		 * The meta object literal for the '<em><b>Pandemicdata</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCATION__PANDEMICDATA = eINSTANCE.getLocation_Pandemicdata();

		/**
		 * The meta object literal for the '<em><b>Current Tier</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__CURRENT_TIER = eINSTANCE.getLocation_CurrentTier();

		/**
		 * The meta object literal for the '<em><b>Controlpolicy</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCATION__CONTROLPOLICY = eINSTANCE.getLocation_Controlpolicy();

		/**
		 * The meta object literal for the '<em><b>Resources</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCATION__RESOURCES = eINSTANCE.getLocation_Resources();

		/**
		 * The meta object literal for the '<em><b>Population</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__POPULATION = eINSTANCE.getLocation_Population();

		/**
		 * The meta object literal for the '<em><b>Population Over60</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__POPULATION_OVER60 = eINSTANCE.getLocation_PopulationOver60();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__NAME = eINSTANCE.getLocation_Name();

		/**
		 * The meta object literal for the '<em><b>Healthy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__HEALTHY = eINSTANCE.getLocation_Healthy();

		/**
		 * The meta object literal for the '<em><b>Infected</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__INFECTED = eINSTANCE.getLocation_Infected();

		/**
		 * The meta object literal for the '<em><b>Recovered</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__RECOVERED = eINSTANCE.getLocation_Recovered();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCATION__LOCATION = eINSTANCE.getLocation_Location();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.CountryImpl <em>Country</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.CountryImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getCountry()
		 * @generated
		 */
		EClass COUNTRY = eINSTANCE.getCountry();

		/**
		 * The meta object literal for the '<em><b>Country Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COUNTRY__COUNTRY_CODE = eINSTANCE.getCountry_CountryCode();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COUNTRY__STATE = eINSTANCE.getCountry_State();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.PandemicDataImpl <em>Pandemic Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.PandemicDataImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPandemicData()
		 * @generated
		 */
		EClass PANDEMIC_DATA = eINSTANCE.getPandemicData();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PANDEMIC_DATA__LOCATION = eINSTANCE.getPandemicData_Location();

		/**
		 * The meta object literal for the '<em><b>Current Tests Count</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC_DATA__CURRENT_TESTS_COUNT = eINSTANCE.getPandemicData_CurrentTestsCount();

		/**
		 * The meta object literal for the '<em><b>Previous Tests Count</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC_DATA__PREVIOUS_TESTS_COUNT = eINSTANCE.getPandemicData_PreviousTestsCount();

		/**
		 * The meta object literal for the '<em><b>Current Positive</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC_DATA__CURRENT_POSITIVE = eINSTANCE.getPandemicData_CurrentPositive();

		/**
		 * The meta object literal for the '<em><b>Current Positive Over60</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC_DATA__CURRENT_POSITIVE_OVER60 = eINSTANCE.getPandemicData_CurrentPositiveOver60();

		/**
		 * The meta object literal for the '<em><b>Current Case Count</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC_DATA__CURRENT_CASE_COUNT = eINSTANCE.getPandemicData_CurrentCaseCount();

		/**
		 * The meta object literal for the '<em><b>Previous Case Count</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC_DATA__PREVIOUS_CASE_COUNT = eINSTANCE.getPandemicData_PreviousCaseCount();

		/**
		 * The meta object literal for the '<em><b>RNaught</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PANDEMIC_DATA___RNAUGHT = eINSTANCE.getPandemicData__RNaught();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.ResourcesImpl <em>Resources</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.ResourcesImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getResources()
		 * @generated
		 */
		EClass RESOURCES = eINSTANCE.getResources();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESOURCES__LOCATION = eINSTANCE.getResources_Location();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.TownImpl <em>Town</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.TownImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getTown()
		 * @generated
		 */
		EClass TOWN = eINSTANCE.getTown();

		/**
		 * The meta object literal for the '<em><b>Town ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TOWN__TOWN_ID = eINSTANCE.getTown_TownID();

		/**
		 * The meta object literal for the '<em><b>City</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOWN__CITY = eINSTANCE.getTown_City();

		/**
		 * The meta object literal for the '<em><b>Street</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOWN__STREET = eINSTANCE.getTown_Street();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.StreetImpl <em>Street</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.StreetImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getStreet()
		 * @generated
		 */
		EClass STREET = eINSTANCE.getStreet();

		/**
		 * The meta object literal for the '<em><b>Street ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STREET__STREET_ID = eINSTANCE.getStreet_StreetID();

		/**
		 * The meta object literal for the '<em><b>Town</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STREET__TOWN = eINSTANCE.getStreet_Town();

		/**
		 * The meta object literal for the '<em><b>House</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STREET__HOUSE = eINSTANCE.getStreet_House();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.HouseImpl <em>House</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.HouseImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getHouse()
		 * @generated
		 */
		EClass HOUSE = eINSTANCE.getHouse();

		/**
		 * The meta object literal for the '<em><b>House ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSE__HOUSE_ID = eINSTANCE.getHouse_HouseID();

		/**
		 * The meta object literal for the '<em><b>Person</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOUSE__PERSON = eINSTANCE.getHouse_Person();

		/**
		 * The meta object literal for the '<em><b>Street</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOUSE__STREET = eINSTANCE.getHouse_Street();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.PersonImpl <em>Person</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.PersonImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPerson()
		 * @generated
		 */
		EClass PERSON = eINSTANCE.getPerson();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__ID = eINSTANCE.getPerson_ID();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__NAME = eINSTANCE.getPerson_Name();

		/**
		 * The meta object literal for the '<em><b>Gender</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__GENDER = eINSTANCE.getPerson_Gender();

		/**
		 * The meta object literal for the '<em><b>Age</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__AGE = eINSTANCE.getPerson_Age();

		/**
		 * The meta object literal for the '<em><b>House</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERSON__HOUSE = eINSTANCE.getPerson_House();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.ControlPolicyImpl <em>Control Policy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.ControlPolicyImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getControlPolicy()
		 * @generated
		 */
		EClass CONTROL_POLICY = eINSTANCE.getControlPolicy();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTROL_POLICY__LOCATION = eINSTANCE.getControlPolicy_Location();

		/**
		 * The meta object literal for the '<em><b>Case Rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__CASE_RATE = eINSTANCE.getControlPolicy_CaseRate();

		/**
		 * The meta object literal for the '<em><b>Bedsper Population</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__BEDSPER_POPULATION = eINSTANCE.getControlPolicy_BedsperPopulation();

		/**
		 * The meta object literal for the '<em><b>Positivity Rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__POSITIVITY_RATE = eINSTANCE.getControlPolicy_PositivityRate();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__NAME = eINSTANCE.getControlPolicy_Name();

		/**
		 * The meta object literal for the '<em><b>Case Detection Rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__CASE_DETECTION_RATE = eINSTANCE.getControlPolicy_CaseDetectionRate();

		/**
		 * The meta object literal for the '<em><b>Vents Per Population</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__VENTS_PER_POPULATION = eINSTANCE.getControlPolicy_VentsPerPopulation();

		/**
		 * The meta object literal for the '<em><b>Testing Rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__TESTING_RATE = eINSTANCE.getControlPolicy_TestingRate();

		/**
		 * The meta object literal for the '<em><b>Doctors Per Patient</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__DOCTORS_PER_PATIENT = eINSTANCE.getControlPolicy_DoctorsPerPatient();

		/**
		 * The meta object literal for the '<em><b>Set Tier</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_POLICY__SET_TIER = eINSTANCE.getControlPolicy_SetTier();

		/**
		 * The meta object literal for the '<em><b>Set Control Parameters</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CONTROL_POLICY___SET_CONTROL_PARAMETERS = eINSTANCE.getControlPolicy__SetControlParameters();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.HealthCentreImpl <em>Health Centre</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.HealthCentreImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getHealthCentre()
		 * @generated
		 */
		EClass HEALTH_CENTRE = eINSTANCE.getHealthCentre();

		/**
		 * The meta object literal for the '<em><b>Staff</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HEALTH_CENTRE__STAFF = eINSTANCE.getHealthCentre_Staff();

		/**
		 * The meta object literal for the '<em><b>Equipment</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HEALTH_CENTRE__EQUIPMENT = eINSTANCE.getHealthCentre_Equipment();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HEALTH_CENTRE__NAME = eINSTANCE.getHealthCentre_Name();

		/**
		 * The meta object literal for the '<em><b>Beds</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HEALTH_CENTRE__BEDS = eINSTANCE.getHealthCentre_Beds();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.QuarentineCentreImpl <em>Quarentine Centre</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.QuarentineCentreImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getQuarentineCentre()
		 * @generated
		 */
		EClass QUARENTINE_CENTRE = eINSTANCE.getQuarentineCentre();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.PrimaryHealthUnitImpl <em>Primary Health Unit</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.PrimaryHealthUnitImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPrimaryHealthUnit()
		 * @generated
		 */
		EClass PRIMARY_HEALTH_UNIT = eINSTANCE.getPrimaryHealthUnit();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.SecondaryHealthUnitImpl <em>Secondary Health Unit</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.SecondaryHealthUnitImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getSecondaryHealthUnit()
		 * @generated
		 */
		EClass SECONDARY_HEALTH_UNIT = eINSTANCE.getSecondaryHealthUnit();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.TertiaryHealthUnitImpl <em>Tertiary Health Unit</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.TertiaryHealthUnitImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getTertiaryHealthUnit()
		 * @generated
		 */
		EClass TERTIARY_HEALTH_UNIT = eINSTANCE.getTertiaryHealthUnit();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.StaffImpl <em>Staff</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.StaffImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getStaff()
		 * @generated
		 */
		EClass STAFF = eINSTANCE.getStaff();

		/**
		 * The meta object literal for the '<em><b>Healthcentre</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STAFF__HEALTHCENTRE = eINSTANCE.getStaff_Healthcentre();

		/**
		 * The meta object literal for the '<em><b>Doctors</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STAFF__DOCTORS = eINSTANCE.getStaff_Doctors();

		/**
		 * The meta object literal for the '<em><b>Nurses</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STAFF__NURSES = eINSTANCE.getStaff_Nurses();

		/**
		 * The meta object literal for the '<em><b>Paramedics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STAFF__PARAMEDICS = eINSTANCE.getStaff_Paramedics();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.EquipmentImpl <em>Equipment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.EquipmentImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getEquipment()
		 * @generated
		 */
		EClass EQUIPMENT = eINSTANCE.getEquipment();

		/**
		 * The meta object literal for the '<em><b>Ventilators</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPMENT__VENTILATORS = eINSTANCE.getEquipment_Ventilators();

		/**
		 * The meta object literal for the '<em><b>PP Es</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPMENT__PP_ES = eINSTANCE.getEquipment_PPEs();

		/**
		 * The meta object literal for the '<em><b>Vaccines</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPMENT__VACCINES = eINSTANCE.getEquipment_Vaccines();

		/**
		 * The meta object literal for the '<em><b>Healthcentre</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EQUIPMENT__HEALTHCENTRE = eINSTANCE.getEquipment_Healthcentre();

		/**
		 * The meta object literal for the '<em><b>Test Kits</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPMENT__TEST_KITS = eINSTANCE.getEquipment_TestKits();

		/**
		 * The meta object literal for the '<em><b>Ambulances</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPMENT__AMBULANCES = eINSTANCE.getEquipment_Ambulances();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.CityImpl <em>City</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.CityImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getCity()
		 * @generated
		 */
		EClass CITY = eINSTANCE.getCity();

		/**
		 * The meta object literal for the '<em><b>City Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CITY__CITY_CODE = eINSTANCE.getCity_CityCode();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY__STATE = eINSTANCE.getCity_State();

		/**
		 * The meta object literal for the '<em><b>Town</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY__TOWN = eINSTANCE.getCity_Town();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.StateImpl <em>State</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.StateImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getState()
		 * @generated
		 */
		EClass STATE = eINSTANCE.getState();

		/**
		 * The meta object literal for the '<em><b>State Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__STATE_CODE = eINSTANCE.getState_StateCode();

		/**
		 * The meta object literal for the '<em><b>Country</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__COUNTRY = eINSTANCE.getState_Country();

		/**
		 * The meta object literal for the '<em><b>City</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__CITY = eINSTANCE.getState_City();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.HStreetImpl <em>HStreet</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.HStreetImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getHStreet()
		 * @generated
		 */
		EClass HSTREET = eINSTANCE.getHStreet();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.VStreetImpl <em>VStreet</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.VStreetImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getVStreet()
		 * @generated
		 */
		EClass VSTREET = eINSTANCE.getVStreet();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.impl.PandemicImpl <em>Pandemic</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.impl.PandemicImpl
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getPandemic()
		 * @generated
		 */
		EClass PANDEMIC = eINSTANCE.getPandemic();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PANDEMIC__LOCATION = eINSTANCE.getPandemic_Location();

		/**
		 * The meta object literal for the '<em><b>Pandemicdata</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PANDEMIC__PANDEMICDATA = eINSTANCE.getPandemic_Pandemicdata();

		/**
		 * The meta object literal for the '<em><b>Resources</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PANDEMIC__RESOURCES = eINSTANCE.getPandemic_Resources();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PANDEMIC__NAME = eINSTANCE.getPandemic_Name();

		/**
		 * The meta object literal for the '<em><b>Controlpolicy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PANDEMIC__CONTROLPOLICY = eINSTANCE.getPandemic_Controlpolicy();

		/**
		 * The meta object literal for the '<em><b>Person</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PANDEMIC__PERSON = eINSTANCE.getPandemic_Person();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.LLevel <em>LLevel</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.LLevel
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getLLevel()
		 * @generated
		 */
		EEnum LLEVEL = eINSTANCE.getLLevel();

		/**
		 * The meta object literal for the '{@link pandemicMgmt.Gender <em>Gender</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see pandemicMgmt.Gender
		 * @see pandemicMgmt.impl.PandemicMgmtPackageImpl#getGender()
		 * @generated
		 */
		EEnum GENDER = eINSTANCE.getGender();

	}

} //PandemicMgmtPackage
