/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pandemic Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.PandemicModel#getPandemic <em>Pandemic</em>}</li>
 *   <li>{@link pandemicMgmt.PandemicModel#getModelID <em>Model ID</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicModel()
 * @model
 * @generated
 */
public interface PandemicModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Pandemic</b></em>' containment reference list.
	 * The list contents are of type {@link pandemicMgmt.Pandemic}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pandemic</em>' containment reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicModel_Pandemic()
	 * @model containment="true"
	 * @generated
	 */
	EList<Pandemic> getPandemic();

	/**
	 * Returns the value of the '<em><b>Model ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model ID</em>' attribute.
	 * @see #setModelID(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPandemicModel_ModelID()
	 * @model
	 * @generated
	 */
	String getModelID();

	/**
	 * Sets the value of the '{@link pandemicMgmt.PandemicModel#getModelID <em>Model ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model ID</em>' attribute.
	 * @see #getModelID()
	 * @generated
	 */
	void setModelID(String value);

} // PandemicModel
