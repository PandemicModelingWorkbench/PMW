/**
 */
package pandemicMgmt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Person</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Person#getID <em>ID</em>}</li>
 *   <li>{@link pandemicMgmt.Person#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.Person#getGender <em>Gender</em>}</li>
 *   <li>{@link pandemicMgmt.Person#getAge <em>Age</em>}</li>
 *   <li>{@link pandemicMgmt.Person#getHouse <em>House</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getPerson()
 * @model
 * @generated
 */
public interface Person extends EObject {
	/**
	 * Returns the value of the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ID</em>' attribute.
	 * @see #setID(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPerson_ID()
	 * @model id="true" dataType="org.eclipse.emf.ecore.xml.type.Int" required="true"
	 * @generated
	 */
	int getID();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Person#getID <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ID</em>' attribute.
	 * @see #getID()
	 * @generated
	 */
	void setID(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPerson_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Person#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Gender</b></em>' attribute.
	 * The literals are from the enumeration {@link pandemicMgmt.Gender}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gender</em>' attribute.
	 * @see pandemicMgmt.Gender
	 * @see #setGender(Gender)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPerson_Gender()
	 * @model
	 * @generated
	 */
	Gender getGender();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Person#getGender <em>Gender</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Gender</em>' attribute.
	 * @see pandemicMgmt.Gender
	 * @see #getGender()
	 * @generated
	 */
	void setGender(Gender value);

	/**
	 * Returns the value of the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Age</em>' attribute.
	 * @see #setAge(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPerson_Age()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Int" required="true"
	 * @generated
	 */
	int getAge();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Person#getAge <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Age</em>' attribute.
	 * @see #getAge()
	 * @generated
	 */
	void setAge(int value);

	/**
	 * Returns the value of the '<em><b>House</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.House#getPerson <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>House</em>' reference.
	 * @see #setHouse(House)
	 * @see pandemicMgmt.PandemicMgmtPackage#getPerson_House()
	 * @see pandemicMgmt.House#getPerson
	 * @model opposite="person" required="true"
	 * @generated
	 */
	House getHouse();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Person#getHouse <em>House</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>House</em>' reference.
	 * @see #getHouse()
	 * @generated
	 */
	void setHouse(House value);

} // Person
