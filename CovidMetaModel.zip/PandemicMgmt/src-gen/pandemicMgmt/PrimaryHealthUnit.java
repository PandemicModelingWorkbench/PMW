/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primary Health Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getPrimaryHealthUnit()
 * @model
 * @generated
 */
public interface PrimaryHealthUnit extends HealthCentre {
} // PrimaryHealthUnit
