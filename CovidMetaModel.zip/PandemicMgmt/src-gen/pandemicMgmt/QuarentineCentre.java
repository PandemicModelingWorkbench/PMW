/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quarentine Centre</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getQuarentineCentre()
 * @model
 * @generated
 */
public interface QuarentineCentre extends HealthCentre {
} // QuarentineCentre
