/**
 */
package pandemicMgmt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Resources</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Resources#getLocation <em>Location</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getResources()
 * @model abstract="true"
 * @generated
 */
public interface Resources extends EObject {
	/**
	 * Returns the value of the '<em><b>Location</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Location#getResources <em>Resources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' reference.
	 * @see #setLocation(Location)
	 * @see pandemicMgmt.PandemicMgmtPackage#getResources_Location()
	 * @see pandemicMgmt.Location#getResources
	 * @model opposite="resources"
	 * @generated
	 */
	Location getLocation();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Resources#getLocation <em>Location</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' reference.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(Location value);

} // Resources
