/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Secondary Health Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getSecondaryHealthUnit()
 * @model
 * @generated
 */
public interface SecondaryHealthUnit extends HealthCentre {
} // SecondaryHealthUnit
