/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Staff</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Staff#getHealthcentre <em>Healthcentre</em>}</li>
 *   <li>{@link pandemicMgmt.Staff#getDoctors <em>Doctors</em>}</li>
 *   <li>{@link pandemicMgmt.Staff#getNurses <em>Nurses</em>}</li>
 *   <li>{@link pandemicMgmt.Staff#getParamedics <em>Paramedics</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getStaff()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='doctorCheck'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot doctorCheck='\n\t\t\tself.location.controlpolicy.doctorsPerPatient &gt;= self.doctors'"
 * @generated
 */
public interface Staff extends Resources {
	/**
	 * Returns the value of the '<em><b>Healthcentre</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.HealthCentre#getStaff <em>Staff</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Healthcentre</em>' reference.
	 * @see #setHealthcentre(HealthCentre)
	 * @see pandemicMgmt.PandemicMgmtPackage#getStaff_Healthcentre()
	 * @see pandemicMgmt.HealthCentre#getStaff
	 * @model opposite="staff"
	 * @generated
	 */
	HealthCentre getHealthcentre();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Staff#getHealthcentre <em>Healthcentre</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Healthcentre</em>' reference.
	 * @see #getHealthcentre()
	 * @generated
	 */
	void setHealthcentre(HealthCentre value);

	/**
	 * Returns the value of the '<em><b>Doctors</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctors</em>' attribute.
	 * @see #setDoctors(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getStaff_Doctors()
	 * @model required="true"
	 * @generated
	 */
	int getDoctors();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Staff#getDoctors <em>Doctors</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Doctors</em>' attribute.
	 * @see #getDoctors()
	 * @generated
	 */
	void setDoctors(int value);

	/**
	 * Returns the value of the '<em><b>Nurses</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nurses</em>' attribute.
	 * @see #setNurses(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getStaff_Nurses()
	 * @model required="true"
	 * @generated
	 */
	int getNurses();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Staff#getNurses <em>Nurses</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nurses</em>' attribute.
	 * @see #getNurses()
	 * @generated
	 */
	void setNurses(int value);

	/**
	 * Returns the value of the '<em><b>Paramedics</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Paramedics</em>' attribute.
	 * @see #setParamedics(int)
	 * @see pandemicMgmt.PandemicMgmtPackage#getStaff_Paramedics()
	 * @model required="true"
	 * @generated
	 */
	int getParamedics();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Staff#getParamedics <em>Paramedics</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Paramedics</em>' attribute.
	 * @see #getParamedics()
	 * @generated
	 */
	void setParamedics(int value);

} // Staff
