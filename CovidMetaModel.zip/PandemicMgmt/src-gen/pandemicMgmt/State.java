/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.State#getStateCode <em>State Code</em>}</li>
 *   <li>{@link pandemicMgmt.State#getCountry <em>Country</em>}</li>
 *   <li>{@link pandemicMgmt.State#getCity <em>City</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getState()
 * @model
 * @generated
 */
public interface State extends Location {
	/**
	 * Returns the value of the '<em><b>State Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State Code</em>' attribute.
	 * @see #setStateCode(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getState_StateCode()
	 * @model
	 * @generated
	 */
	String getStateCode();

	/**
	 * Sets the value of the '{@link pandemicMgmt.State#getStateCode <em>State Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State Code</em>' attribute.
	 * @see #getStateCode()
	 * @generated
	 */
	void setStateCode(String value);

	/**
	 * Returns the value of the '<em><b>Country</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Country#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Country</em>' reference.
	 * @see #setCountry(Country)
	 * @see pandemicMgmt.PandemicMgmtPackage#getState_Country()
	 * @see pandemicMgmt.Country#getState
	 * @model opposite="state"
	 * @generated
	 */
	Country getCountry();

	/**
	 * Sets the value of the '{@link pandemicMgmt.State#getCountry <em>Country</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Country</em>' reference.
	 * @see #getCountry()
	 * @generated
	 */
	void setCountry(Country value);

	/**
	 * Returns the value of the '<em><b>City</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.City}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.City#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>City</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getState_City()
	 * @see pandemicMgmt.City#getState
	 * @model opposite="state"
	 * @generated
	 */
	EList<City> getCity();

} // State
