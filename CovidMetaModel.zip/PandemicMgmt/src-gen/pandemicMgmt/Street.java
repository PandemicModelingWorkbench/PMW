/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Street</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Street#getStreetID <em>Street ID</em>}</li>
 *   <li>{@link pandemicMgmt.Street#getTown <em>Town</em>}</li>
 *   <li>{@link pandemicMgmt.Street#getHouse <em>House</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getStreet()
 * @model abstract="true"
 * @generated
 */
public interface Street extends Location {
	/**
	 * Returns the value of the '<em><b>Street ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Street ID</em>' attribute.
	 * @see #setStreetID(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getStreet_StreetID()
	 * @model
	 * @generated
	 */
	String getStreetID();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Street#getStreetID <em>Street ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Street ID</em>' attribute.
	 * @see #getStreetID()
	 * @generated
	 */
	void setStreetID(String value);

	/**
	 * Returns the value of the '<em><b>Town</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Town#getStreet <em>Street</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Town</em>' reference.
	 * @see #setTown(Town)
	 * @see pandemicMgmt.PandemicMgmtPackage#getStreet_Town()
	 * @see pandemicMgmt.Town#getStreet
	 * @model opposite="street"
	 * @generated
	 */
	Town getTown();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Street#getTown <em>Town</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Town</em>' reference.
	 * @see #getTown()
	 * @generated
	 */
	void setTown(Town value);

	/**
	 * Returns the value of the '<em><b>House</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.House}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.House#getStreet <em>Street</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>House</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getStreet_House()
	 * @see pandemicMgmt.House#getStreet
	 * @model opposite="street"
	 * @generated
	 */
	EList<House> getHouse();

} // Street
