/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tertiary Health Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getTertiaryHealthUnit()
 * @model
 * @generated
 */
public interface TertiaryHealthUnit extends HealthCentre {
} // TertiaryHealthUnit
