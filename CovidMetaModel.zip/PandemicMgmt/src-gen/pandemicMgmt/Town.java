/**
 */
package pandemicMgmt;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Town</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.Town#getTownID <em>Town ID</em>}</li>
 *   <li>{@link pandemicMgmt.Town#getCity <em>City</em>}</li>
 *   <li>{@link pandemicMgmt.Town#getStreet <em>Street</em>}</li>
 * </ul>
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getTown()
 * @model
 * @generated
 */
public interface Town extends Location {
	/**
	 * Returns the value of the '<em><b>Town ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Town ID</em>' attribute.
	 * @see #setTownID(String)
	 * @see pandemicMgmt.PandemicMgmtPackage#getTown_TownID()
	 * @model
	 * @generated
	 */
	String getTownID();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Town#getTownID <em>Town ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Town ID</em>' attribute.
	 * @see #getTownID()
	 * @generated
	 */
	void setTownID(String value);

	/**
	 * Returns the value of the '<em><b>City</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.City#getTown <em>Town</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>City</em>' reference.
	 * @see #setCity(City)
	 * @see pandemicMgmt.PandemicMgmtPackage#getTown_City()
	 * @see pandemicMgmt.City#getTown
	 * @model opposite="town"
	 * @generated
	 */
	City getCity();

	/**
	 * Sets the value of the '{@link pandemicMgmt.Town#getCity <em>City</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>City</em>' reference.
	 * @see #getCity()
	 * @generated
	 */
	void setCity(City value);

	/**
	 * Returns the value of the '<em><b>Street</b></em>' reference list.
	 * The list contents are of type {@link pandemicMgmt.Street}.
	 * It is bidirectional and its opposite is '{@link pandemicMgmt.Street#getTown <em>Town</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Street</em>' reference list.
	 * @see pandemicMgmt.PandemicMgmtPackage#getTown_Street()
	 * @see pandemicMgmt.Street#getTown
	 * @model opposite="town"
	 * @generated
	 */
	EList<Street> getStreet();

} // Town
