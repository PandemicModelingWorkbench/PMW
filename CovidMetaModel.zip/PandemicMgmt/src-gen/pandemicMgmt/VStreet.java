/**
 */
package pandemicMgmt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VStreet</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pandemicMgmt.PandemicMgmtPackage#getVStreet()
 * @model
 * @generated
 */
public interface VStreet extends Street {
} // VStreet
