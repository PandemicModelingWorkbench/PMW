/**
 */
package pandemicMgmt.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import pandemicMgmt.City;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.State;
import pandemicMgmt.Town;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>City</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.CityImpl#getCityCode <em>City Code</em>}</li>
 *   <li>{@link pandemicMgmt.impl.CityImpl#getState <em>State</em>}</li>
 *   <li>{@link pandemicMgmt.impl.CityImpl#getTown <em>Town</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CityImpl extends LocationImpl implements City {
	/**
	 * The default value of the '{@link #getCityCode() <em>City Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCityCode()
	 * @generated
	 * @ordered
	 */
	protected static final String CITY_CODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCityCode() <em>City Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCityCode()
	 * @generated
	 * @ordered
	 */
	protected String cityCode = CITY_CODE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getState() <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected State state;

	/**
	 * The cached value of the '{@link #getTown() <em>Town</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTown()
	 * @generated
	 * @ordered
	 */
	protected EList<Town> town;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.CITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCityCode() {
		return cityCode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCityCode(String newCityCode) {
		String oldCityCode = cityCode;
		cityCode = newCityCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.CITY__CITY_CODE, oldCityCode,
					cityCode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public State getState() {
		if (state != null && state.eIsProxy()) {
			InternalEObject oldState = (InternalEObject) state;
			state = (State) eResolveProxy(oldState);
			if (state != oldState) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PandemicMgmtPackage.CITY__STATE, oldState,
							state));
			}
		}
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State basicGetState() {
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetState(State newState, NotificationChain msgs) {
		State oldState = state;
		state = newState;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.CITY__STATE, oldState, newState);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setState(State newState) {
		if (newState != state) {
			NotificationChain msgs = null;
			if (state != null)
				msgs = ((InternalEObject) state).eInverseRemove(this, PandemicMgmtPackage.STATE__CITY, State.class,
						msgs);
			if (newState != null)
				msgs = ((InternalEObject) newState).eInverseAdd(this, PandemicMgmtPackage.STATE__CITY, State.class,
						msgs);
			msgs = basicSetState(newState, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.CITY__STATE, newState, newState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Town> getTown() {
		if (town == null) {
			town = new EObjectWithInverseResolvingEList<Town>(Town.class, this, PandemicMgmtPackage.CITY__TOWN,
					PandemicMgmtPackage.TOWN__CITY);
		}
		return town;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.CITY__STATE:
			if (state != null)
				msgs = ((InternalEObject) state).eInverseRemove(this, PandemicMgmtPackage.STATE__CITY, State.class,
						msgs);
			return basicSetState((State) otherEnd, msgs);
		case PandemicMgmtPackage.CITY__TOWN:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getTown()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.CITY__STATE:
			return basicSetState(null, msgs);
		case PandemicMgmtPackage.CITY__TOWN:
			return ((InternalEList<?>) getTown()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.CITY__CITY_CODE:
			return getCityCode();
		case PandemicMgmtPackage.CITY__STATE:
			if (resolve)
				return getState();
			return basicGetState();
		case PandemicMgmtPackage.CITY__TOWN:
			return getTown();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.CITY__CITY_CODE:
			setCityCode((String) newValue);
			return;
		case PandemicMgmtPackage.CITY__STATE:
			setState((State) newValue);
			return;
		case PandemicMgmtPackage.CITY__TOWN:
			getTown().clear();
			getTown().addAll((Collection<? extends Town>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.CITY__CITY_CODE:
			setCityCode(CITY_CODE_EDEFAULT);
			return;
		case PandemicMgmtPackage.CITY__STATE:
			setState((State) null);
			return;
		case PandemicMgmtPackage.CITY__TOWN:
			getTown().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.CITY__CITY_CODE:
			return CITY_CODE_EDEFAULT == null ? cityCode != null : !CITY_CODE_EDEFAULT.equals(cityCode);
		case PandemicMgmtPackage.CITY__STATE:
			return state != null;
		case PandemicMgmtPackage.CITY__TOWN:
			return town != null && !town.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (cityCode: ");
		result.append(cityCode);
		result.append(')');
		return result.toString();
	}

} //CityImpl
