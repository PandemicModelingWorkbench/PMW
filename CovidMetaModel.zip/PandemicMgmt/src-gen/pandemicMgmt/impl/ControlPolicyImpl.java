/**
 */
package pandemicMgmt.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import pandemicMgmt.ControlPolicy;
import pandemicMgmt.LLevel;
import pandemicMgmt.Location;
import pandemicMgmt.PandemicMgmtPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Control Policy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getCaseRate <em>Case Rate</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getBedsperPopulation <em>Bedsper Population</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getPositivityRate <em>Positivity Rate</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getCaseDetectionRate <em>Case Detection Rate</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getVentsPerPopulation <em>Vents Per Population</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getTestingRate <em>Testing Rate</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getDoctorsPerPatient <em>Doctors Per Patient</em>}</li>
 *   <li>{@link pandemicMgmt.impl.ControlPolicyImpl#getSetTier <em>Set Tier</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ControlPolicyImpl extends MinimalEObjectImpl.Container implements ControlPolicy {
	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected EList<Location> location;

	/**
	 * The default value of the '{@link #getCaseRate() <em>Case Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCaseRate()
	 * @generated
	 * @ordered
	 */
	protected static final float CASE_RATE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getCaseRate() <em>Case Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCaseRate()
	 * @generated
	 * @ordered
	 */
	protected float caseRate = CASE_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getBedsperPopulation() <em>Bedsper Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBedsperPopulation()
	 * @generated
	 * @ordered
	 */
	protected static final float BEDSPER_POPULATION_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getBedsperPopulation() <em>Bedsper Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBedsperPopulation()
	 * @generated
	 * @ordered
	 */
	protected float bedsperPopulation = BEDSPER_POPULATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getPositivityRate() <em>Positivity Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPositivityRate()
	 * @generated
	 * @ordered
	 */
	protected static final float POSITIVITY_RATE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getPositivityRate() <em>Positivity Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPositivityRate()
	 * @generated
	 * @ordered
	 */
	protected float positivityRate = POSITIVITY_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getCaseDetectionRate() <em>Case Detection Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCaseDetectionRate()
	 * @generated
	 * @ordered
	 */
	protected static final float CASE_DETECTION_RATE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getCaseDetectionRate() <em>Case Detection Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCaseDetectionRate()
	 * @generated
	 * @ordered
	 */
	protected float caseDetectionRate = CASE_DETECTION_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getVentsPerPopulation() <em>Vents Per Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVentsPerPopulation()
	 * @generated
	 * @ordered
	 */
	protected static final float VENTS_PER_POPULATION_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getVentsPerPopulation() <em>Vents Per Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVentsPerPopulation()
	 * @generated
	 * @ordered
	 */
	protected float ventsPerPopulation = VENTS_PER_POPULATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getTestingRate() <em>Testing Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestingRate()
	 * @generated
	 * @ordered
	 */
	protected static final float TESTING_RATE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTestingRate() <em>Testing Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestingRate()
	 * @generated
	 * @ordered
	 */
	protected float testingRate = TESTING_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoctorsPerPatient() <em>Doctors Per Patient</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctorsPerPatient()
	 * @generated
	 * @ordered
	 */
	protected static final float DOCTORS_PER_PATIENT_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getDoctorsPerPatient() <em>Doctors Per Patient</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctorsPerPatient()
	 * @generated
	 * @ordered
	 */
	protected float doctorsPerPatient = DOCTORS_PER_PATIENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getSetTier() <em>Set Tier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSetTier()
	 * @generated
	 * @ordered
	 */
	protected static final LLevel SET_TIER_EDEFAULT = LLevel.TIER1;

	/**
	 * The cached value of the '{@link #getSetTier() <em>Set Tier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSetTier()
	 * @generated
	 * @ordered
	 */
	protected LLevel setTier = SET_TIER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ControlPolicyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.CONTROL_POLICY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Location> getLocation() {
		if (location == null) {
			location = new EObjectWithInverseResolvingEList<Location>(Location.class, this,
					PandemicMgmtPackage.CONTROL_POLICY__LOCATION, PandemicMgmtPackage.LOCATION__CONTROLPOLICY);
		}
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getCaseRate() {
		return caseRate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCaseRate(float newCaseRate) {
		float oldCaseRate = caseRate;
		caseRate = newCaseRate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.CONTROL_POLICY__CASE_RATE,
					oldCaseRate, caseRate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getBedsperPopulation() {
		return bedsperPopulation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBedsperPopulation(float newBedsperPopulation) {
		float oldBedsperPopulation = bedsperPopulation;
		bedsperPopulation = newBedsperPopulation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.CONTROL_POLICY__BEDSPER_POPULATION, oldBedsperPopulation, bedsperPopulation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getPositivityRate() {
		return positivityRate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPositivityRate(float newPositivityRate) {
		float oldPositivityRate = positivityRate;
		positivityRate = newPositivityRate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.CONTROL_POLICY__POSITIVITY_RATE,
					oldPositivityRate, positivityRate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.CONTROL_POLICY__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getCaseDetectionRate() {
		return caseDetectionRate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCaseDetectionRate(float newCaseDetectionRate) {
		float oldCaseDetectionRate = caseDetectionRate;
		caseDetectionRate = newCaseDetectionRate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.CONTROL_POLICY__CASE_DETECTION_RATE, oldCaseDetectionRate, caseDetectionRate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getVentsPerPopulation() {
		return ventsPerPopulation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVentsPerPopulation(float newVentsPerPopulation) {
		float oldVentsPerPopulation = ventsPerPopulation;
		ventsPerPopulation = newVentsPerPopulation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.CONTROL_POLICY__VENTS_PER_POPULATION, oldVentsPerPopulation,
					ventsPerPopulation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getTestingRate() {
		return testingRate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTestingRate(float newTestingRate) {
		float oldTestingRate = testingRate;
		testingRate = newTestingRate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.CONTROL_POLICY__TESTING_RATE,
					oldTestingRate, testingRate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getDoctorsPerPatient() {
		return doctorsPerPatient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDoctorsPerPatient(float newDoctorsPerPatient) {
		float oldDoctorsPerPatient = doctorsPerPatient;
		doctorsPerPatient = newDoctorsPerPatient;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.CONTROL_POLICY__DOCTORS_PER_PATIENT, oldDoctorsPerPatient, doctorsPerPatient));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LLevel getSetTier() {
		return setTier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSetTier(LLevel newSetTier) {
		LLevel oldSetTier = setTier;
		setTier = newSetTier == null ? SET_TIER_EDEFAULT : newSetTier;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.CONTROL_POLICY__SET_TIER,
					oldSetTier, setTier));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void SetControlParameters() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.CONTROL_POLICY__LOCATION:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getLocation()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.CONTROL_POLICY__LOCATION:
			return ((InternalEList<?>) getLocation()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.CONTROL_POLICY__LOCATION:
			return getLocation();
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_RATE:
			return getCaseRate();
		case PandemicMgmtPackage.CONTROL_POLICY__BEDSPER_POPULATION:
			return getBedsperPopulation();
		case PandemicMgmtPackage.CONTROL_POLICY__POSITIVITY_RATE:
			return getPositivityRate();
		case PandemicMgmtPackage.CONTROL_POLICY__NAME:
			return getName();
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_DETECTION_RATE:
			return getCaseDetectionRate();
		case PandemicMgmtPackage.CONTROL_POLICY__VENTS_PER_POPULATION:
			return getVentsPerPopulation();
		case PandemicMgmtPackage.CONTROL_POLICY__TESTING_RATE:
			return getTestingRate();
		case PandemicMgmtPackage.CONTROL_POLICY__DOCTORS_PER_PATIENT:
			return getDoctorsPerPatient();
		case PandemicMgmtPackage.CONTROL_POLICY__SET_TIER:
			return getSetTier();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.CONTROL_POLICY__LOCATION:
			getLocation().clear();
			getLocation().addAll((Collection<? extends Location>) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_RATE:
			setCaseRate((Float) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__BEDSPER_POPULATION:
			setBedsperPopulation((Float) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__POSITIVITY_RATE:
			setPositivityRate((Float) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__NAME:
			setName((String) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_DETECTION_RATE:
			setCaseDetectionRate((Float) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__VENTS_PER_POPULATION:
			setVentsPerPopulation((Float) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__TESTING_RATE:
			setTestingRate((Float) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__DOCTORS_PER_PATIENT:
			setDoctorsPerPatient((Float) newValue);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__SET_TIER:
			setSetTier((LLevel) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.CONTROL_POLICY__LOCATION:
			getLocation().clear();
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_RATE:
			setCaseRate(CASE_RATE_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__BEDSPER_POPULATION:
			setBedsperPopulation(BEDSPER_POPULATION_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__POSITIVITY_RATE:
			setPositivityRate(POSITIVITY_RATE_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_DETECTION_RATE:
			setCaseDetectionRate(CASE_DETECTION_RATE_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__VENTS_PER_POPULATION:
			setVentsPerPopulation(VENTS_PER_POPULATION_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__TESTING_RATE:
			setTestingRate(TESTING_RATE_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__DOCTORS_PER_PATIENT:
			setDoctorsPerPatient(DOCTORS_PER_PATIENT_EDEFAULT);
			return;
		case PandemicMgmtPackage.CONTROL_POLICY__SET_TIER:
			setSetTier(SET_TIER_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.CONTROL_POLICY__LOCATION:
			return location != null && !location.isEmpty();
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_RATE:
			return caseRate != CASE_RATE_EDEFAULT;
		case PandemicMgmtPackage.CONTROL_POLICY__BEDSPER_POPULATION:
			return bedsperPopulation != BEDSPER_POPULATION_EDEFAULT;
		case PandemicMgmtPackage.CONTROL_POLICY__POSITIVITY_RATE:
			return positivityRate != POSITIVITY_RATE_EDEFAULT;
		case PandemicMgmtPackage.CONTROL_POLICY__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PandemicMgmtPackage.CONTROL_POLICY__CASE_DETECTION_RATE:
			return caseDetectionRate != CASE_DETECTION_RATE_EDEFAULT;
		case PandemicMgmtPackage.CONTROL_POLICY__VENTS_PER_POPULATION:
			return ventsPerPopulation != VENTS_PER_POPULATION_EDEFAULT;
		case PandemicMgmtPackage.CONTROL_POLICY__TESTING_RATE:
			return testingRate != TESTING_RATE_EDEFAULT;
		case PandemicMgmtPackage.CONTROL_POLICY__DOCTORS_PER_PATIENT:
			return doctorsPerPatient != DOCTORS_PER_PATIENT_EDEFAULT;
		case PandemicMgmtPackage.CONTROL_POLICY__SET_TIER:
			return setTier != SET_TIER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PandemicMgmtPackage.CONTROL_POLICY___SET_CONTROL_PARAMETERS:
			SetControlParameters();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (caseRate: ");
		result.append(caseRate);
		result.append(", bedsperPopulation: ");
		result.append(bedsperPopulation);
		result.append(", positivityRate: ");
		result.append(positivityRate);
		result.append(", name: ");
		result.append(name);
		result.append(", caseDetectionRate: ");
		result.append(caseDetectionRate);
		result.append(", ventsPerPopulation: ");
		result.append(ventsPerPopulation);
		result.append(", testingRate: ");
		result.append(testingRate);
		result.append(", doctorsPerPatient: ");
		result.append(doctorsPerPatient);
		result.append(", setTier: ");
		result.append(setTier);
		result.append(')');
		return result.toString();
	}

} //ControlPolicyImpl
