/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import pandemicMgmt.Equipment;
import pandemicMgmt.HealthCentre;
import pandemicMgmt.PandemicMgmtPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Equipment</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.EquipmentImpl#getVentilators <em>Ventilators</em>}</li>
 *   <li>{@link pandemicMgmt.impl.EquipmentImpl#getPPEs <em>PP Es</em>}</li>
 *   <li>{@link pandemicMgmt.impl.EquipmentImpl#getVaccines <em>Vaccines</em>}</li>
 *   <li>{@link pandemicMgmt.impl.EquipmentImpl#getHealthcentre <em>Healthcentre</em>}</li>
 *   <li>{@link pandemicMgmt.impl.EquipmentImpl#getTestKits <em>Test Kits</em>}</li>
 *   <li>{@link pandemicMgmt.impl.EquipmentImpl#getAmbulances <em>Ambulances</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EquipmentImpl extends ResourcesImpl implements Equipment {
	/**
	 * The default value of the '{@link #getVentilators() <em>Ventilators</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVentilators()
	 * @generated
	 * @ordered
	 */
	protected static final int VENTILATORS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getVentilators() <em>Ventilators</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVentilators()
	 * @generated
	 * @ordered
	 */
	protected int ventilators = VENTILATORS_EDEFAULT;

	/**
	 * The default value of the '{@link #getPPEs() <em>PP Es</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPPEs()
	 * @generated
	 * @ordered
	 */
	protected static final int PP_ES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPPEs() <em>PP Es</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPPEs()
	 * @generated
	 * @ordered
	 */
	protected int ppEs = PP_ES_EDEFAULT;

	/**
	 * The default value of the '{@link #getVaccines() <em>Vaccines</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVaccines()
	 * @generated
	 * @ordered
	 */
	protected static final int VACCINES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getVaccines() <em>Vaccines</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVaccines()
	 * @generated
	 * @ordered
	 */
	protected int vaccines = VACCINES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHealthcentre() <em>Healthcentre</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHealthcentre()
	 * @generated
	 * @ordered
	 */
	protected HealthCentre healthcentre;

	/**
	 * The default value of the '{@link #getTestKits() <em>Test Kits</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestKits()
	 * @generated
	 * @ordered
	 */
	protected static final int TEST_KITS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTestKits() <em>Test Kits</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTestKits()
	 * @generated
	 * @ordered
	 */
	protected int testKits = TEST_KITS_EDEFAULT;

	/**
	 * The default value of the '{@link #getAmbulances() <em>Ambulances</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAmbulances()
	 * @generated
	 * @ordered
	 */
	protected static final int AMBULANCES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getAmbulances() <em>Ambulances</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAmbulances()
	 * @generated
	 * @ordered
	 */
	protected int ambulances = AMBULANCES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EquipmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.EQUIPMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getVentilators() {
		return ventilators;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVentilators(int newVentilators) {
		int oldVentilators = ventilators;
		ventilators = newVentilators;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.EQUIPMENT__VENTILATORS,
					oldVentilators, ventilators));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getPPEs() {
		return ppEs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPPEs(int newPPEs) {
		int oldPPEs = ppEs;
		ppEs = newPPEs;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.EQUIPMENT__PP_ES, oldPPEs, ppEs));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getVaccines() {
		return vaccines;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVaccines(int newVaccines) {
		int oldVaccines = vaccines;
		vaccines = newVaccines;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.EQUIPMENT__VACCINES, oldVaccines,
					vaccines));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HealthCentre getHealthcentre() {
		if (healthcentre != null && healthcentre.eIsProxy()) {
			InternalEObject oldHealthcentre = (InternalEObject) healthcentre;
			healthcentre = (HealthCentre) eResolveProxy(oldHealthcentre);
			if (healthcentre != oldHealthcentre) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE, oldHealthcentre, healthcentre));
			}
		}
		return healthcentre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HealthCentre basicGetHealthcentre() {
		return healthcentre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHealthcentre(HealthCentre newHealthcentre, NotificationChain msgs) {
		HealthCentre oldHealthcentre = healthcentre;
		healthcentre = newHealthcentre;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE, oldHealthcentre, newHealthcentre);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHealthcentre(HealthCentre newHealthcentre) {
		if (newHealthcentre != healthcentre) {
			NotificationChain msgs = null;
			if (healthcentre != null)
				msgs = ((InternalEObject) healthcentre).eInverseRemove(this,
						PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT, HealthCentre.class, msgs);
			if (newHealthcentre != null)
				msgs = ((InternalEObject) newHealthcentre).eInverseAdd(this,
						PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT, HealthCentre.class, msgs);
			msgs = basicSetHealthcentre(newHealthcentre, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE,
					newHealthcentre, newHealthcentre));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getTestKits() {
		return testKits;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTestKits(int newTestKits) {
		int oldTestKits = testKits;
		testKits = newTestKits;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.EQUIPMENT__TEST_KITS, oldTestKits,
					testKits));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getAmbulances() {
		return ambulances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAmbulances(int newAmbulances) {
		int oldAmbulances = ambulances;
		ambulances = newAmbulances;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.EQUIPMENT__AMBULANCES,
					oldAmbulances, ambulances));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE:
			if (healthcentre != null)
				msgs = ((InternalEObject) healthcentre).eInverseRemove(this,
						PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT, HealthCentre.class, msgs);
			return basicSetHealthcentre((HealthCentre) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE:
			return basicSetHealthcentre(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.EQUIPMENT__VENTILATORS:
			return getVentilators();
		case PandemicMgmtPackage.EQUIPMENT__PP_ES:
			return getPPEs();
		case PandemicMgmtPackage.EQUIPMENT__VACCINES:
			return getVaccines();
		case PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE:
			if (resolve)
				return getHealthcentre();
			return basicGetHealthcentre();
		case PandemicMgmtPackage.EQUIPMENT__TEST_KITS:
			return getTestKits();
		case PandemicMgmtPackage.EQUIPMENT__AMBULANCES:
			return getAmbulances();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.EQUIPMENT__VENTILATORS:
			setVentilators((Integer) newValue);
			return;
		case PandemicMgmtPackage.EQUIPMENT__PP_ES:
			setPPEs((Integer) newValue);
			return;
		case PandemicMgmtPackage.EQUIPMENT__VACCINES:
			setVaccines((Integer) newValue);
			return;
		case PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE:
			setHealthcentre((HealthCentre) newValue);
			return;
		case PandemicMgmtPackage.EQUIPMENT__TEST_KITS:
			setTestKits((Integer) newValue);
			return;
		case PandemicMgmtPackage.EQUIPMENT__AMBULANCES:
			setAmbulances((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.EQUIPMENT__VENTILATORS:
			setVentilators(VENTILATORS_EDEFAULT);
			return;
		case PandemicMgmtPackage.EQUIPMENT__PP_ES:
			setPPEs(PP_ES_EDEFAULT);
			return;
		case PandemicMgmtPackage.EQUIPMENT__VACCINES:
			setVaccines(VACCINES_EDEFAULT);
			return;
		case PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE:
			setHealthcentre((HealthCentre) null);
			return;
		case PandemicMgmtPackage.EQUIPMENT__TEST_KITS:
			setTestKits(TEST_KITS_EDEFAULT);
			return;
		case PandemicMgmtPackage.EQUIPMENT__AMBULANCES:
			setAmbulances(AMBULANCES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.EQUIPMENT__VENTILATORS:
			return ventilators != VENTILATORS_EDEFAULT;
		case PandemicMgmtPackage.EQUIPMENT__PP_ES:
			return ppEs != PP_ES_EDEFAULT;
		case PandemicMgmtPackage.EQUIPMENT__VACCINES:
			return vaccines != VACCINES_EDEFAULT;
		case PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE:
			return healthcentre != null;
		case PandemicMgmtPackage.EQUIPMENT__TEST_KITS:
			return testKits != TEST_KITS_EDEFAULT;
		case PandemicMgmtPackage.EQUIPMENT__AMBULANCES:
			return ambulances != AMBULANCES_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ventilators: ");
		result.append(ventilators);
		result.append(", PPEs: ");
		result.append(ppEs);
		result.append(", vaccines: ");
		result.append(vaccines);
		result.append(", testKits: ");
		result.append(testKits);
		result.append(", ambulances: ");
		result.append(ambulances);
		result.append(')');
		return result.toString();
	}

} //EquipmentImpl
