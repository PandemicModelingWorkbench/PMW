/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.ecore.EClass;

import pandemicMgmt.HStreet;
import pandemicMgmt.PandemicMgmtPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>HStreet</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HStreetImpl extends StreetImpl implements HStreet {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HStreetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.HSTREET;
	}

} //HStreetImpl
