/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import pandemicMgmt.Equipment;
import pandemicMgmt.HealthCentre;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.Staff;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Health Centre</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.HealthCentreImpl#getStaff <em>Staff</em>}</li>
 *   <li>{@link pandemicMgmt.impl.HealthCentreImpl#getEquipment <em>Equipment</em>}</li>
 *   <li>{@link pandemicMgmt.impl.HealthCentreImpl#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.impl.HealthCentreImpl#getBeds <em>Beds</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class HealthCentreImpl extends ResourcesImpl implements HealthCentre {
	/**
	 * The cached value of the '{@link #getStaff() <em>Staff</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaff()
	 * @generated
	 * @ordered
	 */
	protected Staff staff;

	/**
	 * The cached value of the '{@link #getEquipment() <em>Equipment</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEquipment()
	 * @generated
	 * @ordered
	 */
	protected Equipment equipment;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getBeds() <em>Beds</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBeds()
	 * @generated
	 * @ordered
	 */
	protected static final int BEDS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getBeds() <em>Beds</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBeds()
	 * @generated
	 * @ordered
	 */
	protected int beds = BEDS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HealthCentreImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.HEALTH_CENTRE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Staff getStaff() {
		if (staff != null && staff.eIsProxy()) {
			InternalEObject oldStaff = (InternalEObject) staff;
			staff = (Staff) eResolveProxy(oldStaff);
			if (staff != oldStaff) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PandemicMgmtPackage.HEALTH_CENTRE__STAFF,
							oldStaff, staff));
			}
		}
		return staff;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Staff basicGetStaff() {
		return staff;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStaff(Staff newStaff, NotificationChain msgs) {
		Staff oldStaff = staff;
		staff = newStaff;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.HEALTH_CENTRE__STAFF, oldStaff, newStaff);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStaff(Staff newStaff) {
		if (newStaff != staff) {
			NotificationChain msgs = null;
			if (staff != null)
				msgs = ((InternalEObject) staff).eInverseRemove(this, PandemicMgmtPackage.STAFF__HEALTHCENTRE,
						Staff.class, msgs);
			if (newStaff != null)
				msgs = ((InternalEObject) newStaff).eInverseAdd(this, PandemicMgmtPackage.STAFF__HEALTHCENTRE,
						Staff.class, msgs);
			msgs = basicSetStaff(newStaff, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.HEALTH_CENTRE__STAFF, newStaff,
					newStaff));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Equipment getEquipment() {
		if (equipment != null && equipment.eIsProxy()) {
			InternalEObject oldEquipment = (InternalEObject) equipment;
			equipment = (Equipment) eResolveProxy(oldEquipment);
			if (equipment != oldEquipment) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT, oldEquipment, equipment));
			}
		}
		return equipment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Equipment basicGetEquipment() {
		return equipment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetEquipment(Equipment newEquipment, NotificationChain msgs) {
		Equipment oldEquipment = equipment;
		equipment = newEquipment;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT, oldEquipment, newEquipment);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEquipment(Equipment newEquipment) {
		if (newEquipment != equipment) {
			NotificationChain msgs = null;
			if (equipment != null)
				msgs = ((InternalEObject) equipment).eInverseRemove(this, PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE,
						Equipment.class, msgs);
			if (newEquipment != null)
				msgs = ((InternalEObject) newEquipment).eInverseAdd(this, PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE,
						Equipment.class, msgs);
			msgs = basicSetEquipment(newEquipment, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT,
					newEquipment, newEquipment));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.HEALTH_CENTRE__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getBeds() {
		return beds;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBeds(int newBeds) {
		int oldBeds = beds;
		beds = newBeds;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.HEALTH_CENTRE__BEDS, oldBeds,
					beds));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.HEALTH_CENTRE__STAFF:
			if (staff != null)
				msgs = ((InternalEObject) staff).eInverseRemove(this, PandemicMgmtPackage.STAFF__HEALTHCENTRE,
						Staff.class, msgs);
			return basicSetStaff((Staff) otherEnd, msgs);
		case PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT:
			if (equipment != null)
				msgs = ((InternalEObject) equipment).eInverseRemove(this, PandemicMgmtPackage.EQUIPMENT__HEALTHCENTRE,
						Equipment.class, msgs);
			return basicSetEquipment((Equipment) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.HEALTH_CENTRE__STAFF:
			return basicSetStaff(null, msgs);
		case PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT:
			return basicSetEquipment(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.HEALTH_CENTRE__STAFF:
			if (resolve)
				return getStaff();
			return basicGetStaff();
		case PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT:
			if (resolve)
				return getEquipment();
			return basicGetEquipment();
		case PandemicMgmtPackage.HEALTH_CENTRE__NAME:
			return getName();
		case PandemicMgmtPackage.HEALTH_CENTRE__BEDS:
			return getBeds();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.HEALTH_CENTRE__STAFF:
			setStaff((Staff) newValue);
			return;
		case PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT:
			setEquipment((Equipment) newValue);
			return;
		case PandemicMgmtPackage.HEALTH_CENTRE__NAME:
			setName((String) newValue);
			return;
		case PandemicMgmtPackage.HEALTH_CENTRE__BEDS:
			setBeds((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.HEALTH_CENTRE__STAFF:
			setStaff((Staff) null);
			return;
		case PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT:
			setEquipment((Equipment) null);
			return;
		case PandemicMgmtPackage.HEALTH_CENTRE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PandemicMgmtPackage.HEALTH_CENTRE__BEDS:
			setBeds(BEDS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.HEALTH_CENTRE__STAFF:
			return staff != null;
		case PandemicMgmtPackage.HEALTH_CENTRE__EQUIPMENT:
			return equipment != null;
		case PandemicMgmtPackage.HEALTH_CENTRE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PandemicMgmtPackage.HEALTH_CENTRE__BEDS:
			return beds != BEDS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", beds: ");
		result.append(beds);
		result.append(')');
		return result.toString();
	}

} //HealthCentreImpl
