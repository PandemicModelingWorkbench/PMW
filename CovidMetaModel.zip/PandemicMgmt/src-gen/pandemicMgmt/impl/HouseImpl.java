/**
 */
package pandemicMgmt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import pandemicMgmt.House;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.Person;
import pandemicMgmt.Street;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>House</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.HouseImpl#getHouseID <em>House ID</em>}</li>
 *   <li>{@link pandemicMgmt.impl.HouseImpl#getPerson <em>Person</em>}</li>
 *   <li>{@link pandemicMgmt.impl.HouseImpl#getStreet <em>Street</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HouseImpl extends LocationImpl implements House {
	/**
	 * The default value of the '{@link #getHouseID() <em>House ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHouseID()
	 * @generated
	 * @ordered
	 */
	protected static final String HOUSE_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHouseID() <em>House ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHouseID()
	 * @generated
	 * @ordered
	 */
	protected String houseID = HOUSE_ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPerson() <em>Person</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerson()
	 * @generated
	 * @ordered
	 */
	protected EList<Person> person;

	/**
	 * The cached value of the '{@link #getStreet() <em>Street</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreet()
	 * @generated
	 * @ordered
	 */
	protected Street street;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HouseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.HOUSE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getHouseID() {
		return houseID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHouseID(String newHouseID) {
		String oldHouseID = houseID;
		houseID = newHouseID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.HOUSE__HOUSE_ID, oldHouseID,
					houseID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Person> getPerson() {
		if (person == null) {
			person = new EObjectWithInverseResolvingEList<Person>(Person.class, this, PandemicMgmtPackage.HOUSE__PERSON,
					PandemicMgmtPackage.PERSON__HOUSE);
		}
		return person;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Street getStreet() {
		if (street != null && street.eIsProxy()) {
			InternalEObject oldStreet = (InternalEObject) street;
			street = (Street) eResolveProxy(oldStreet);
			if (street != oldStreet) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PandemicMgmtPackage.HOUSE__STREET,
							oldStreet, street));
			}
		}
		return street;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Street basicGetStreet() {
		return street;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStreet(Street newStreet, NotificationChain msgs) {
		Street oldStreet = street;
		street = newStreet;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.HOUSE__STREET, oldStreet, newStreet);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStreet(Street newStreet) {
		if (newStreet != street) {
			NotificationChain msgs = null;
			if (street != null)
				msgs = ((InternalEObject) street).eInverseRemove(this, PandemicMgmtPackage.STREET__HOUSE, Street.class,
						msgs);
			if (newStreet != null)
				msgs = ((InternalEObject) newStreet).eInverseAdd(this, PandemicMgmtPackage.STREET__HOUSE, Street.class,
						msgs);
			msgs = basicSetStreet(newStreet, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.HOUSE__STREET, newStreet,
					newStreet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.HOUSE__PERSON:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getPerson()).basicAdd(otherEnd, msgs);
		case PandemicMgmtPackage.HOUSE__STREET:
			if (street != null)
				msgs = ((InternalEObject) street).eInverseRemove(this, PandemicMgmtPackage.STREET__HOUSE, Street.class,
						msgs);
			return basicSetStreet((Street) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.HOUSE__PERSON:
			return ((InternalEList<?>) getPerson()).basicRemove(otherEnd, msgs);
		case PandemicMgmtPackage.HOUSE__STREET:
			return basicSetStreet(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.HOUSE__HOUSE_ID:
			return getHouseID();
		case PandemicMgmtPackage.HOUSE__PERSON:
			return getPerson();
		case PandemicMgmtPackage.HOUSE__STREET:
			if (resolve)
				return getStreet();
			return basicGetStreet();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.HOUSE__HOUSE_ID:
			setHouseID((String) newValue);
			return;
		case PandemicMgmtPackage.HOUSE__PERSON:
			getPerson().clear();
			getPerson().addAll((Collection<? extends Person>) newValue);
			return;
		case PandemicMgmtPackage.HOUSE__STREET:
			setStreet((Street) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.HOUSE__HOUSE_ID:
			setHouseID(HOUSE_ID_EDEFAULT);
			return;
		case PandemicMgmtPackage.HOUSE__PERSON:
			getPerson().clear();
			return;
		case PandemicMgmtPackage.HOUSE__STREET:
			setStreet((Street) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.HOUSE__HOUSE_ID:
			return HOUSE_ID_EDEFAULT == null ? houseID != null : !HOUSE_ID_EDEFAULT.equals(houseID);
		case PandemicMgmtPackage.HOUSE__PERSON:
			return person != null && !person.isEmpty();
		case PandemicMgmtPackage.HOUSE__STREET:
			return street != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (houseID: ");
		result.append(houseID);
		result.append(')');
		return result.toString();
	}

} //HouseImpl
