/**
 */
package pandemicMgmt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import pandemicMgmt.ControlPolicy;
import pandemicMgmt.LLevel;
import pandemicMgmt.Location;
import pandemicMgmt.PandemicData;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.Resources;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Location</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getPandemicdata <em>Pandemicdata</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getCurrentTier <em>Current Tier</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getControlpolicy <em>Controlpolicy</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getResources <em>Resources</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getPopulation <em>Population</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getPopulationOver60 <em>Population Over60</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getHealthy <em>Healthy</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getInfected <em>Infected</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getRecovered <em>Recovered</em>}</li>
 *   <li>{@link pandemicMgmt.impl.LocationImpl#getLocation <em>Location</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class LocationImpl extends MinimalEObjectImpl.Container implements Location {
	/**
	 * The cached value of the '{@link #getPandemicdata() <em>Pandemicdata</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPandemicdata()
	 * @generated
	 * @ordered
	 */
	protected PandemicData pandemicdata;

	/**
	 * The default value of the '{@link #getCurrentTier() <em>Current Tier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentTier()
	 * @generated
	 * @ordered
	 */
	protected static final LLevel CURRENT_TIER_EDEFAULT = LLevel.TIER1;

	/**
	 * The cached value of the '{@link #getCurrentTier() <em>Current Tier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentTier()
	 * @generated
	 * @ordered
	 */
	protected LLevel currentTier = CURRENT_TIER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getControlpolicy() <em>Controlpolicy</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlpolicy()
	 * @generated
	 * @ordered
	 */
	protected ControlPolicy controlpolicy;

	/**
	 * The cached value of the '{@link #getResources() <em>Resources</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResources()
	 * @generated
	 * @ordered
	 */
	protected EList<Resources> resources;

	/**
	 * The default value of the '{@link #getPopulation() <em>Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulation()
	 * @generated
	 * @ordered
	 */
	protected static final int POPULATION_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPopulation() <em>Population</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulation()
	 * @generated
	 * @ordered
	 */
	protected int population = POPULATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getPopulationOver60() <em>Population Over60</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulationOver60()
	 * @generated
	 * @ordered
	 */
	protected static final int POPULATION_OVER60_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPopulationOver60() <em>Population Over60</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulationOver60()
	 * @generated
	 * @ordered
	 */
	protected int populationOver60 = POPULATION_OVER60_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getHealthy() <em>Healthy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHealthy()
	 * @generated
	 * @ordered
	 */
	protected static final int HEALTHY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getHealthy() <em>Healthy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHealthy()
	 * @generated
	 * @ordered
	 */
	protected int healthy = HEALTHY_EDEFAULT;

	/**
	 * The default value of the '{@link #getInfected() <em>Infected</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInfected()
	 * @generated
	 * @ordered
	 */
	protected static final int INFECTED_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getInfected() <em>Infected</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInfected()
	 * @generated
	 * @ordered
	 */
	protected int infected = INFECTED_EDEFAULT;

	/**
	 * The default value of the '{@link #getRecovered() <em>Recovered</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecovered()
	 * @generated
	 * @ordered
	 */
	protected static final int RECOVERED_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getRecovered() <em>Recovered</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecovered()
	 * @generated
	 * @ordered
	 */
	protected int recovered = RECOVERED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected EList<Location> location;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LocationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.LOCATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PandemicData getPandemicdata() {
		if (pandemicdata != null && pandemicdata.eIsProxy()) {
			InternalEObject oldPandemicdata = (InternalEObject) pandemicdata;
			pandemicdata = (PandemicData) eResolveProxy(oldPandemicdata);
			if (pandemicdata != oldPandemicdata) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PandemicMgmtPackage.LOCATION__PANDEMICDATA, oldPandemicdata, pandemicdata));
			}
		}
		return pandemicdata;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PandemicData basicGetPandemicdata() {
		return pandemicdata;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPandemicdata(PandemicData newPandemicdata, NotificationChain msgs) {
		PandemicData oldPandemicdata = pandemicdata;
		pandemicdata = newPandemicdata;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.LOCATION__PANDEMICDATA, oldPandemicdata, newPandemicdata);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPandemicdata(PandemicData newPandemicdata) {
		if (newPandemicdata != pandemicdata) {
			NotificationChain msgs = null;
			if (pandemicdata != null)
				msgs = ((InternalEObject) pandemicdata).eInverseRemove(this,
						PandemicMgmtPackage.PANDEMIC_DATA__LOCATION, PandemicData.class, msgs);
			if (newPandemicdata != null)
				msgs = ((InternalEObject) newPandemicdata).eInverseAdd(this,
						PandemicMgmtPackage.PANDEMIC_DATA__LOCATION, PandemicData.class, msgs);
			msgs = basicSetPandemicdata(newPandemicdata, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__PANDEMICDATA,
					newPandemicdata, newPandemicdata));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LLevel getCurrentTier() {
		return currentTier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCurrentTier(LLevel newCurrentTier) {
		LLevel oldCurrentTier = currentTier;
		currentTier = newCurrentTier == null ? CURRENT_TIER_EDEFAULT : newCurrentTier;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__CURRENT_TIER,
					oldCurrentTier, currentTier));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControlPolicy getControlpolicy() {
		if (controlpolicy != null && controlpolicy.eIsProxy()) {
			InternalEObject oldControlpolicy = (InternalEObject) controlpolicy;
			controlpolicy = (ControlPolicy) eResolveProxy(oldControlpolicy);
			if (controlpolicy != oldControlpolicy) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PandemicMgmtPackage.LOCATION__CONTROLPOLICY, oldControlpolicy, controlpolicy));
			}
		}
		return controlpolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControlPolicy basicGetControlpolicy() {
		return controlpolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetControlpolicy(ControlPolicy newControlpolicy, NotificationChain msgs) {
		ControlPolicy oldControlpolicy = controlpolicy;
		controlpolicy = newControlpolicy;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.LOCATION__CONTROLPOLICY, oldControlpolicy, newControlpolicy);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setControlpolicy(ControlPolicy newControlpolicy) {
		if (newControlpolicy != controlpolicy) {
			NotificationChain msgs = null;
			if (controlpolicy != null)
				msgs = ((InternalEObject) controlpolicy).eInverseRemove(this,
						PandemicMgmtPackage.CONTROL_POLICY__LOCATION, ControlPolicy.class, msgs);
			if (newControlpolicy != null)
				msgs = ((InternalEObject) newControlpolicy).eInverseAdd(this,
						PandemicMgmtPackage.CONTROL_POLICY__LOCATION, ControlPolicy.class, msgs);
			msgs = basicSetControlpolicy(newControlpolicy, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__CONTROLPOLICY,
					newControlpolicy, newControlpolicy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Resources> getResources() {
		if (resources == null) {
			resources = new EObjectWithInverseResolvingEList<Resources>(Resources.class, this,
					PandemicMgmtPackage.LOCATION__RESOURCES, PandemicMgmtPackage.RESOURCES__LOCATION);
		}
		return resources;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getPopulation() {
		return population;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPopulation(int newPopulation) {
		int oldPopulation = population;
		population = newPopulation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__POPULATION,
					oldPopulation, population));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getPopulationOver60() {
		return populationOver60;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPopulationOver60(int newPopulationOver60) {
		int oldPopulationOver60 = populationOver60;
		populationOver60 = newPopulationOver60;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__POPULATION_OVER60,
					oldPopulationOver60, populationOver60));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getHealthy() {
		return healthy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHealthy(int newHealthy) {
		int oldHealthy = healthy;
		healthy = newHealthy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__HEALTHY, oldHealthy,
					healthy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getInfected() {
		return infected;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInfected(int newInfected) {
		int oldInfected = infected;
		infected = newInfected;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__INFECTED, oldInfected,
					infected));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getRecovered() {
		return recovered;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRecovered(int newRecovered) {
		int oldRecovered = recovered;
		recovered = newRecovered;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.LOCATION__RECOVERED, oldRecovered,
					recovered));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Location> getLocation() {
		if (location == null) {
			location = new EObjectContainmentEList<Location>(Location.class, this,
					PandemicMgmtPackage.LOCATION__LOCATION);
		}
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.LOCATION__PANDEMICDATA:
			if (pandemicdata != null)
				msgs = ((InternalEObject) pandemicdata).eInverseRemove(this,
						PandemicMgmtPackage.PANDEMIC_DATA__LOCATION, PandemicData.class, msgs);
			return basicSetPandemicdata((PandemicData) otherEnd, msgs);
		case PandemicMgmtPackage.LOCATION__CONTROLPOLICY:
			if (controlpolicy != null)
				msgs = ((InternalEObject) controlpolicy).eInverseRemove(this,
						PandemicMgmtPackage.CONTROL_POLICY__LOCATION, ControlPolicy.class, msgs);
			return basicSetControlpolicy((ControlPolicy) otherEnd, msgs);
		case PandemicMgmtPackage.LOCATION__RESOURCES:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getResources()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.LOCATION__PANDEMICDATA:
			return basicSetPandemicdata(null, msgs);
		case PandemicMgmtPackage.LOCATION__CONTROLPOLICY:
			return basicSetControlpolicy(null, msgs);
		case PandemicMgmtPackage.LOCATION__RESOURCES:
			return ((InternalEList<?>) getResources()).basicRemove(otherEnd, msgs);
		case PandemicMgmtPackage.LOCATION__LOCATION:
			return ((InternalEList<?>) getLocation()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.LOCATION__PANDEMICDATA:
			if (resolve)
				return getPandemicdata();
			return basicGetPandemicdata();
		case PandemicMgmtPackage.LOCATION__CURRENT_TIER:
			return getCurrentTier();
		case PandemicMgmtPackage.LOCATION__CONTROLPOLICY:
			if (resolve)
				return getControlpolicy();
			return basicGetControlpolicy();
		case PandemicMgmtPackage.LOCATION__RESOURCES:
			return getResources();
		case PandemicMgmtPackage.LOCATION__POPULATION:
			return getPopulation();
		case PandemicMgmtPackage.LOCATION__POPULATION_OVER60:
			return getPopulationOver60();
		case PandemicMgmtPackage.LOCATION__NAME:
			return getName();
		case PandemicMgmtPackage.LOCATION__HEALTHY:
			return getHealthy();
		case PandemicMgmtPackage.LOCATION__INFECTED:
			return getInfected();
		case PandemicMgmtPackage.LOCATION__RECOVERED:
			return getRecovered();
		case PandemicMgmtPackage.LOCATION__LOCATION:
			return getLocation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.LOCATION__PANDEMICDATA:
			setPandemicdata((PandemicData) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__CURRENT_TIER:
			setCurrentTier((LLevel) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__CONTROLPOLICY:
			setControlpolicy((ControlPolicy) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__RESOURCES:
			getResources().clear();
			getResources().addAll((Collection<? extends Resources>) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__POPULATION:
			setPopulation((Integer) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__POPULATION_OVER60:
			setPopulationOver60((Integer) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__NAME:
			setName((String) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__HEALTHY:
			setHealthy((Integer) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__INFECTED:
			setInfected((Integer) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__RECOVERED:
			setRecovered((Integer) newValue);
			return;
		case PandemicMgmtPackage.LOCATION__LOCATION:
			getLocation().clear();
			getLocation().addAll((Collection<? extends Location>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.LOCATION__PANDEMICDATA:
			setPandemicdata((PandemicData) null);
			return;
		case PandemicMgmtPackage.LOCATION__CURRENT_TIER:
			setCurrentTier(CURRENT_TIER_EDEFAULT);
			return;
		case PandemicMgmtPackage.LOCATION__CONTROLPOLICY:
			setControlpolicy((ControlPolicy) null);
			return;
		case PandemicMgmtPackage.LOCATION__RESOURCES:
			getResources().clear();
			return;
		case PandemicMgmtPackage.LOCATION__POPULATION:
			setPopulation(POPULATION_EDEFAULT);
			return;
		case PandemicMgmtPackage.LOCATION__POPULATION_OVER60:
			setPopulationOver60(POPULATION_OVER60_EDEFAULT);
			return;
		case PandemicMgmtPackage.LOCATION__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PandemicMgmtPackage.LOCATION__HEALTHY:
			setHealthy(HEALTHY_EDEFAULT);
			return;
		case PandemicMgmtPackage.LOCATION__INFECTED:
			setInfected(INFECTED_EDEFAULT);
			return;
		case PandemicMgmtPackage.LOCATION__RECOVERED:
			setRecovered(RECOVERED_EDEFAULT);
			return;
		case PandemicMgmtPackage.LOCATION__LOCATION:
			getLocation().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.LOCATION__PANDEMICDATA:
			return pandemicdata != null;
		case PandemicMgmtPackage.LOCATION__CURRENT_TIER:
			return currentTier != CURRENT_TIER_EDEFAULT;
		case PandemicMgmtPackage.LOCATION__CONTROLPOLICY:
			return controlpolicy != null;
		case PandemicMgmtPackage.LOCATION__RESOURCES:
			return resources != null && !resources.isEmpty();
		case PandemicMgmtPackage.LOCATION__POPULATION:
			return population != POPULATION_EDEFAULT;
		case PandemicMgmtPackage.LOCATION__POPULATION_OVER60:
			return populationOver60 != POPULATION_OVER60_EDEFAULT;
		case PandemicMgmtPackage.LOCATION__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PandemicMgmtPackage.LOCATION__HEALTHY:
			return healthy != HEALTHY_EDEFAULT;
		case PandemicMgmtPackage.LOCATION__INFECTED:
			return infected != INFECTED_EDEFAULT;
		case PandemicMgmtPackage.LOCATION__RECOVERED:
			return recovered != RECOVERED_EDEFAULT;
		case PandemicMgmtPackage.LOCATION__LOCATION:
			return location != null && !location.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (currentTier: ");
		result.append(currentTier);
		result.append(", population: ");
		result.append(population);
		result.append(", populationOver60: ");
		result.append(populationOver60);
		result.append(", name: ");
		result.append(name);
		result.append(", healthy: ");
		result.append(healthy);
		result.append(", infected: ");
		result.append(infected);
		result.append(", recovered: ");
		result.append(recovered);
		result.append(')');
		return result.toString();
	}

} //LocationImpl
