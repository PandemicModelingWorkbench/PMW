/**
 */
package pandemicMgmt.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import pandemicMgmt.Location;
import pandemicMgmt.PandemicData;
import pandemicMgmt.PandemicMgmtPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pandemic Data</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.PandemicDataImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicDataImpl#getCurrentTestsCount <em>Current Tests Count</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicDataImpl#getPreviousTestsCount <em>Previous Tests Count</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicDataImpl#getCurrentPositive <em>Current Positive</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicDataImpl#getCurrentPositiveOver60 <em>Current Positive Over60</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicDataImpl#getCurrentCaseCount <em>Current Case Count</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicDataImpl#getPreviousCaseCount <em>Previous Case Count</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PandemicDataImpl extends MinimalEObjectImpl.Container implements PandemicData {
	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected Location location;

	/**
	 * The default value of the '{@link #getCurrentTestsCount() <em>Current Tests Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentTestsCount()
	 * @generated
	 * @ordered
	 */
	protected static final int CURRENT_TESTS_COUNT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCurrentTestsCount() <em>Current Tests Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentTestsCount()
	 * @generated
	 * @ordered
	 */
	protected int currentTestsCount = CURRENT_TESTS_COUNT_EDEFAULT;

	/**
	 * The default value of the '{@link #getPreviousTestsCount() <em>Previous Tests Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreviousTestsCount()
	 * @generated
	 * @ordered
	 */
	protected static final int PREVIOUS_TESTS_COUNT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPreviousTestsCount() <em>Previous Tests Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreviousTestsCount()
	 * @generated
	 * @ordered
	 */
	protected int previousTestsCount = PREVIOUS_TESTS_COUNT_EDEFAULT;

	/**
	 * The default value of the '{@link #getCurrentPositive() <em>Current Positive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentPositive()
	 * @generated
	 * @ordered
	 */
	protected static final int CURRENT_POSITIVE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCurrentPositive() <em>Current Positive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentPositive()
	 * @generated
	 * @ordered
	 */
	protected int currentPositive = CURRENT_POSITIVE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCurrentPositiveOver60() <em>Current Positive Over60</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentPositiveOver60()
	 * @generated
	 * @ordered
	 */
	protected static final int CURRENT_POSITIVE_OVER60_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCurrentPositiveOver60() <em>Current Positive Over60</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentPositiveOver60()
	 * @generated
	 * @ordered
	 */
	protected int currentPositiveOver60 = CURRENT_POSITIVE_OVER60_EDEFAULT;

	/**
	 * The default value of the '{@link #getCurrentCaseCount() <em>Current Case Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentCaseCount()
	 * @generated
	 * @ordered
	 */
	protected static final int CURRENT_CASE_COUNT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCurrentCaseCount() <em>Current Case Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentCaseCount()
	 * @generated
	 * @ordered
	 */
	protected int currentCaseCount = CURRENT_CASE_COUNT_EDEFAULT;

	/**
	 * The default value of the '{@link #getPreviousCaseCount() <em>Previous Case Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreviousCaseCount()
	 * @generated
	 * @ordered
	 */
	protected static final int PREVIOUS_CASE_COUNT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPreviousCaseCount() <em>Previous Case Count</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreviousCaseCount()
	 * @generated
	 * @ordered
	 */
	protected int previousCaseCount = PREVIOUS_CASE_COUNT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PandemicDataImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.PANDEMIC_DATA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Location getLocation() {
		if (location != null && location.eIsProxy()) {
			InternalEObject oldLocation = (InternalEObject) location;
			location = (Location) eResolveProxy(oldLocation);
			if (location != oldLocation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PandemicMgmtPackage.PANDEMIC_DATA__LOCATION, oldLocation, location));
			}
		}
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location basicGetLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLocation(Location newLocation, NotificationChain msgs) {
		Location oldLocation = location;
		location = newLocation;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.PANDEMIC_DATA__LOCATION, oldLocation, newLocation);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLocation(Location newLocation) {
		if (newLocation != location) {
			NotificationChain msgs = null;
			if (location != null)
				msgs = ((InternalEObject) location).eInverseRemove(this, PandemicMgmtPackage.LOCATION__PANDEMICDATA,
						Location.class, msgs);
			if (newLocation != null)
				msgs = ((InternalEObject) newLocation).eInverseAdd(this, PandemicMgmtPackage.LOCATION__PANDEMICDATA,
						Location.class, msgs);
			msgs = basicSetLocation(newLocation, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.PANDEMIC_DATA__LOCATION,
					newLocation, newLocation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getCurrentTestsCount() {
		return currentTestsCount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCurrentTestsCount(int newCurrentTestsCount) {
		int oldCurrentTestsCount = currentTestsCount;
		currentTestsCount = newCurrentTestsCount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_TESTS_COUNT, oldCurrentTestsCount, currentTestsCount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getPreviousTestsCount() {
		return previousTestsCount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPreviousTestsCount(int newPreviousTestsCount) {
		int oldPreviousTestsCount = previousTestsCount;
		previousTestsCount = newPreviousTestsCount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_TESTS_COUNT, oldPreviousTestsCount,
					previousTestsCount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getCurrentPositive() {
		return currentPositive;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCurrentPositive(int newCurrentPositive) {
		int oldCurrentPositive = currentPositive;
		currentPositive = newCurrentPositive;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE,
					oldCurrentPositive, currentPositive));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getCurrentPositiveOver60() {
		return currentPositiveOver60;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCurrentPositiveOver60(int newCurrentPositiveOver60) {
		int oldCurrentPositiveOver60 = currentPositiveOver60;
		currentPositiveOver60 = newCurrentPositiveOver60;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE_OVER60, oldCurrentPositiveOver60,
					currentPositiveOver60));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getCurrentCaseCount() {
		return currentCaseCount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCurrentCaseCount(int newCurrentCaseCount) {
		int oldCurrentCaseCount = currentCaseCount;
		currentCaseCount = newCurrentCaseCount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_CASE_COUNT,
					oldCurrentCaseCount, currentCaseCount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getPreviousCaseCount() {
		return previousCaseCount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPreviousCaseCount(int newPreviousCaseCount) {
		int oldPreviousCaseCount = previousCaseCount;
		previousCaseCount = newPreviousCaseCount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_CASE_COUNT, oldPreviousCaseCount, previousCaseCount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float RNaught() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_DATA__LOCATION:
			if (location != null)
				msgs = ((InternalEObject) location).eInverseRemove(this, PandemicMgmtPackage.LOCATION__PANDEMICDATA,
						Location.class, msgs);
			return basicSetLocation((Location) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_DATA__LOCATION:
			return basicSetLocation(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_DATA__LOCATION:
			if (resolve)
				return getLocation();
			return basicGetLocation();
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_TESTS_COUNT:
			return getCurrentTestsCount();
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_TESTS_COUNT:
			return getPreviousTestsCount();
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE:
			return getCurrentPositive();
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE_OVER60:
			return getCurrentPositiveOver60();
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_CASE_COUNT:
			return getCurrentCaseCount();
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_CASE_COUNT:
			return getPreviousCaseCount();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_DATA__LOCATION:
			setLocation((Location) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_TESTS_COUNT:
			setCurrentTestsCount((Integer) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_TESTS_COUNT:
			setPreviousTestsCount((Integer) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE:
			setCurrentPositive((Integer) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE_OVER60:
			setCurrentPositiveOver60((Integer) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_CASE_COUNT:
			setCurrentCaseCount((Integer) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_CASE_COUNT:
			setPreviousCaseCount((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_DATA__LOCATION:
			setLocation((Location) null);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_TESTS_COUNT:
			setCurrentTestsCount(CURRENT_TESTS_COUNT_EDEFAULT);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_TESTS_COUNT:
			setPreviousTestsCount(PREVIOUS_TESTS_COUNT_EDEFAULT);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE:
			setCurrentPositive(CURRENT_POSITIVE_EDEFAULT);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE_OVER60:
			setCurrentPositiveOver60(CURRENT_POSITIVE_OVER60_EDEFAULT);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_CASE_COUNT:
			setCurrentCaseCount(CURRENT_CASE_COUNT_EDEFAULT);
			return;
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_CASE_COUNT:
			setPreviousCaseCount(PREVIOUS_CASE_COUNT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_DATA__LOCATION:
			return location != null;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_TESTS_COUNT:
			return currentTestsCount != CURRENT_TESTS_COUNT_EDEFAULT;
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_TESTS_COUNT:
			return previousTestsCount != PREVIOUS_TESTS_COUNT_EDEFAULT;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE:
			return currentPositive != CURRENT_POSITIVE_EDEFAULT;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_POSITIVE_OVER60:
			return currentPositiveOver60 != CURRENT_POSITIVE_OVER60_EDEFAULT;
		case PandemicMgmtPackage.PANDEMIC_DATA__CURRENT_CASE_COUNT:
			return currentCaseCount != CURRENT_CASE_COUNT_EDEFAULT;
		case PandemicMgmtPackage.PANDEMIC_DATA__PREVIOUS_CASE_COUNT:
			return previousCaseCount != PREVIOUS_CASE_COUNT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PandemicMgmtPackage.PANDEMIC_DATA___RNAUGHT:
			return RNaught();
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (currentTestsCount: ");
		result.append(currentTestsCount);
		result.append(", previousTestsCount: ");
		result.append(previousTestsCount);
		result.append(", currentPositive: ");
		result.append(currentPositive);
		result.append(", currentPositiveOver60: ");
		result.append(currentPositiveOver60);
		result.append(", currentCaseCount: ");
		result.append(currentCaseCount);
		result.append(", previousCaseCount: ");
		result.append(previousCaseCount);
		result.append(')');
		return result.toString();
	}

} //PandemicDataImpl
