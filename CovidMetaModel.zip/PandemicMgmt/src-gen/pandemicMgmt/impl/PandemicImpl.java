/**
 */
package pandemicMgmt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import pandemicMgmt.ControlPolicy;
import pandemicMgmt.Location;
import pandemicMgmt.Pandemic;
import pandemicMgmt.PandemicData;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.Person;
import pandemicMgmt.Resources;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pandemic</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.PandemicImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicImpl#getPandemicdata <em>Pandemicdata</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicImpl#getResources <em>Resources</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicImpl#getName <em>Name</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicImpl#getControlpolicy <em>Controlpolicy</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicImpl#getPerson <em>Person</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PandemicImpl extends MinimalEObjectImpl.Container implements Pandemic {
	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected EList<Location> location;
	/**
	 * The cached value of the '{@link #getPandemicdata() <em>Pandemicdata</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPandemicdata()
	 * @generated
	 * @ordered
	 */
	protected EList<PandemicData> pandemicdata;
	/**
	 * The cached value of the '{@link #getResources() <em>Resources</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResources()
	 * @generated
	 * @ordered
	 */
	protected EList<Resources> resources;
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;
	/**
	 * The cached value of the '{@link #getControlpolicy() <em>Controlpolicy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlpolicy()
	 * @generated
	 * @ordered
	 */
	protected EList<ControlPolicy> controlpolicy;
	/**
	 * The cached value of the '{@link #getPerson() <em>Person</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerson()
	 * @generated
	 * @ordered
	 */
	protected EList<Person> person;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PandemicImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.PANDEMIC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Location> getLocation() {
		if (location == null) {
			location = new EObjectContainmentEList<Location>(Location.class, this,
					PandemicMgmtPackage.PANDEMIC__LOCATION);
		}
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PandemicData> getPandemicdata() {
		if (pandemicdata == null) {
			pandemicdata = new EObjectContainmentEList<PandemicData>(PandemicData.class, this,
					PandemicMgmtPackage.PANDEMIC__PANDEMICDATA);
		}
		return pandemicdata;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Resources> getResources() {
		if (resources == null) {
			resources = new EObjectContainmentEList<Resources>(Resources.class, this,
					PandemicMgmtPackage.PANDEMIC__RESOURCES);
		}
		return resources;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.PANDEMIC__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ControlPolicy> getControlpolicy() {
		if (controlpolicy == null) {
			controlpolicy = new EObjectContainmentEList<ControlPolicy>(ControlPolicy.class, this,
					PandemicMgmtPackage.PANDEMIC__CONTROLPOLICY);
		}
		return controlpolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Person> getPerson() {
		if (person == null) {
			person = new EObjectContainmentEList<Person>(Person.class, this, PandemicMgmtPackage.PANDEMIC__PERSON);
		}
		return person;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC__LOCATION:
			return ((InternalEList<?>) getLocation()).basicRemove(otherEnd, msgs);
		case PandemicMgmtPackage.PANDEMIC__PANDEMICDATA:
			return ((InternalEList<?>) getPandemicdata()).basicRemove(otherEnd, msgs);
		case PandemicMgmtPackage.PANDEMIC__RESOURCES:
			return ((InternalEList<?>) getResources()).basicRemove(otherEnd, msgs);
		case PandemicMgmtPackage.PANDEMIC__CONTROLPOLICY:
			return ((InternalEList<?>) getControlpolicy()).basicRemove(otherEnd, msgs);
		case PandemicMgmtPackage.PANDEMIC__PERSON:
			return ((InternalEList<?>) getPerson()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC__LOCATION:
			return getLocation();
		case PandemicMgmtPackage.PANDEMIC__PANDEMICDATA:
			return getPandemicdata();
		case PandemicMgmtPackage.PANDEMIC__RESOURCES:
			return getResources();
		case PandemicMgmtPackage.PANDEMIC__NAME:
			return getName();
		case PandemicMgmtPackage.PANDEMIC__CONTROLPOLICY:
			return getControlpolicy();
		case PandemicMgmtPackage.PANDEMIC__PERSON:
			return getPerson();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC__LOCATION:
			getLocation().clear();
			getLocation().addAll((Collection<? extends Location>) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC__PANDEMICDATA:
			getPandemicdata().clear();
			getPandemicdata().addAll((Collection<? extends PandemicData>) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC__RESOURCES:
			getResources().clear();
			getResources().addAll((Collection<? extends Resources>) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC__NAME:
			setName((String) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC__CONTROLPOLICY:
			getControlpolicy().clear();
			getControlpolicy().addAll((Collection<? extends ControlPolicy>) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC__PERSON:
			getPerson().clear();
			getPerson().addAll((Collection<? extends Person>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC__LOCATION:
			getLocation().clear();
			return;
		case PandemicMgmtPackage.PANDEMIC__PANDEMICDATA:
			getPandemicdata().clear();
			return;
		case PandemicMgmtPackage.PANDEMIC__RESOURCES:
			getResources().clear();
			return;
		case PandemicMgmtPackage.PANDEMIC__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PandemicMgmtPackage.PANDEMIC__CONTROLPOLICY:
			getControlpolicy().clear();
			return;
		case PandemicMgmtPackage.PANDEMIC__PERSON:
			getPerson().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC__LOCATION:
			return location != null && !location.isEmpty();
		case PandemicMgmtPackage.PANDEMIC__PANDEMICDATA:
			return pandemicdata != null && !pandemicdata.isEmpty();
		case PandemicMgmtPackage.PANDEMIC__RESOURCES:
			return resources != null && !resources.isEmpty();
		case PandemicMgmtPackage.PANDEMIC__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PandemicMgmtPackage.PANDEMIC__CONTROLPOLICY:
			return controlpolicy != null && !controlpolicy.isEmpty();
		case PandemicMgmtPackage.PANDEMIC__PERSON:
			return person != null && !person.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //PandemicImpl
