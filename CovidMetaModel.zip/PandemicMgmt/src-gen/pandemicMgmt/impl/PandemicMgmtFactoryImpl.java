/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import pandemicMgmt.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PandemicMgmtFactoryImpl extends EFactoryImpl implements PandemicMgmtFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PandemicMgmtFactory init() {
		try {
			PandemicMgmtFactory thePandemicMgmtFactory = (PandemicMgmtFactory) EPackage.Registry.INSTANCE
					.getEFactory(PandemicMgmtPackage.eNS_URI);
			if (thePandemicMgmtFactory != null) {
				return thePandemicMgmtFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PandemicMgmtFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PandemicMgmtFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case PandemicMgmtPackage.PANDEMIC:
			return createPandemic();
		case PandemicMgmtPackage.COUNTRY:
			return createCountry();
		case PandemicMgmtPackage.PANDEMIC_DATA:
			return createPandemicData();
		case PandemicMgmtPackage.TOWN:
			return createTown();
		case PandemicMgmtPackage.HOUSE:
			return createHouse();
		case PandemicMgmtPackage.PERSON:
			return createPerson();
		case PandemicMgmtPackage.CONTROL_POLICY:
			return createControlPolicy();
		case PandemicMgmtPackage.QUARENTINE_CENTRE:
			return createQuarentineCentre();
		case PandemicMgmtPackage.PRIMARY_HEALTH_UNIT:
			return createPrimaryHealthUnit();
		case PandemicMgmtPackage.SECONDARY_HEALTH_UNIT:
			return createSecondaryHealthUnit();
		case PandemicMgmtPackage.TERTIARY_HEALTH_UNIT:
			return createTertiaryHealthUnit();
		case PandemicMgmtPackage.STAFF:
			return createStaff();
		case PandemicMgmtPackage.EQUIPMENT:
			return createEquipment();
		case PandemicMgmtPackage.CITY:
			return createCity();
		case PandemicMgmtPackage.STATE:
			return createState();
		case PandemicMgmtPackage.HSTREET:
			return createHStreet();
		case PandemicMgmtPackage.VSTREET:
			return createVStreet();
		case PandemicMgmtPackage.PANDEMIC_MODEL:
			return createPandemicModel();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case PandemicMgmtPackage.LLEVEL:
			return createLLevelFromString(eDataType, initialValue);
		case PandemicMgmtPackage.GENDER:
			return createGenderFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case PandemicMgmtPackage.LLEVEL:
			return convertLLevelToString(eDataType, instanceValue);
		case PandemicMgmtPackage.GENDER:
			return convertGenderToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PandemicModel createPandemicModel() {
		PandemicModelImpl pandemicModel = new PandemicModelImpl();
		return pandemicModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Country createCountry() {
		CountryImpl country = new CountryImpl();
		return country;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PandemicData createPandemicData() {
		PandemicDataImpl pandemicData = new PandemicDataImpl();
		return pandemicData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Town createTown() {
		TownImpl town = new TownImpl();
		return town;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public House createHouse() {
		HouseImpl house = new HouseImpl();
		return house;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Person createPerson() {
		PersonImpl person = new PersonImpl();
		return person;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControlPolicy createControlPolicy() {
		ControlPolicyImpl controlPolicy = new ControlPolicyImpl();
		return controlPolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public QuarentineCentre createQuarentineCentre() {
		QuarentineCentreImpl quarentineCentre = new QuarentineCentreImpl();
		return quarentineCentre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PrimaryHealthUnit createPrimaryHealthUnit() {
		PrimaryHealthUnitImpl primaryHealthUnit = new PrimaryHealthUnitImpl();
		return primaryHealthUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecondaryHealthUnit createSecondaryHealthUnit() {
		SecondaryHealthUnitImpl secondaryHealthUnit = new SecondaryHealthUnitImpl();
		return secondaryHealthUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TertiaryHealthUnit createTertiaryHealthUnit() {
		TertiaryHealthUnitImpl tertiaryHealthUnit = new TertiaryHealthUnitImpl();
		return tertiaryHealthUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Staff createStaff() {
		StaffImpl staff = new StaffImpl();
		return staff;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Equipment createEquipment() {
		EquipmentImpl equipment = new EquipmentImpl();
		return equipment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public City createCity() {
		CityImpl city = new CityImpl();
		return city;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public State createState() {
		StateImpl state = new StateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HStreet createHStreet() {
		HStreetImpl hStreet = new HStreetImpl();
		return hStreet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VStreet createVStreet() {
		VStreetImpl vStreet = new VStreetImpl();
		return vStreet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Pandemic createPandemic() {
		PandemicImpl pandemic = new PandemicImpl();
		return pandemic;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LLevel createLLevelFromString(EDataType eDataType, String initialValue) {
		LLevel result = LLevel.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLLevelToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Gender createGenderFromString(EDataType eDataType, String initialValue) {
		Gender result = Gender.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertGenderToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PandemicMgmtPackage getPandemicMgmtPackage() {
		return (PandemicMgmtPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static PandemicMgmtPackage getPackage() {
		return PandemicMgmtPackage.eINSTANCE;
	}

} //PandemicMgmtFactoryImpl
