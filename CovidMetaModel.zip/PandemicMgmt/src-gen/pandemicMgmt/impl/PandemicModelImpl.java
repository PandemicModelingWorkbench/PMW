/**
 */
package pandemicMgmt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import pandemicMgmt.Pandemic;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.PandemicModel;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pandemic Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.PandemicModelImpl#getPandemic <em>Pandemic</em>}</li>
 *   <li>{@link pandemicMgmt.impl.PandemicModelImpl#getModelID <em>Model ID</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PandemicModelImpl extends MinimalEObjectImpl.Container implements PandemicModel {
	/**
	 * The cached value of the '{@link #getPandemic() <em>Pandemic</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPandemic()
	 * @generated
	 * @ordered
	 */
	protected EList<Pandemic> pandemic;

	/**
	 * The default value of the '{@link #getModelID() <em>Model ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelID()
	 * @generated
	 * @ordered
	 */
	protected static final String MODEL_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModelID() <em>Model ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelID()
	 * @generated
	 * @ordered
	 */
	protected String modelID = MODEL_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PandemicModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.PANDEMIC_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Pandemic> getPandemic() {
		if (pandemic == null) {
			pandemic = new EObjectContainmentEList<Pandemic>(Pandemic.class, this,
					PandemicMgmtPackage.PANDEMIC_MODEL__PANDEMIC);
		}
		return pandemic;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getModelID() {
		return modelID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setModelID(String newModelID) {
		String oldModelID = modelID;
		modelID = newModelID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.PANDEMIC_MODEL__MODEL_ID,
					oldModelID, modelID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_MODEL__PANDEMIC:
			return ((InternalEList<?>) getPandemic()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_MODEL__PANDEMIC:
			return getPandemic();
		case PandemicMgmtPackage.PANDEMIC_MODEL__MODEL_ID:
			return getModelID();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_MODEL__PANDEMIC:
			getPandemic().clear();
			getPandemic().addAll((Collection<? extends Pandemic>) newValue);
			return;
		case PandemicMgmtPackage.PANDEMIC_MODEL__MODEL_ID:
			setModelID((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_MODEL__PANDEMIC:
			getPandemic().clear();
			return;
		case PandemicMgmtPackage.PANDEMIC_MODEL__MODEL_ID:
			setModelID(MODEL_ID_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.PANDEMIC_MODEL__PANDEMIC:
			return pandemic != null && !pandemic.isEmpty();
		case PandemicMgmtPackage.PANDEMIC_MODEL__MODEL_ID:
			return MODEL_ID_EDEFAULT == null ? modelID != null : !MODEL_ID_EDEFAULT.equals(modelID);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (modelID: ");
		result.append(modelID);
		result.append(')');
		return result.toString();
	}

} //PandemicModelImpl
