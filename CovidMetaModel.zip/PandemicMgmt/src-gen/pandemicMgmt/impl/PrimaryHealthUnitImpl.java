/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.ecore.EClass;

import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.PrimaryHealthUnit;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Primary Health Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PrimaryHealthUnitImpl extends HealthCentreImpl implements PrimaryHealthUnit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PrimaryHealthUnitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.PRIMARY_HEALTH_UNIT;
	}

} //PrimaryHealthUnitImpl
