/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.ecore.EClass;

import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.QuarentineCentre;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Quarentine Centre</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class QuarentineCentreImpl extends HealthCentreImpl implements QuarentineCentre {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected QuarentineCentreImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.QUARENTINE_CENTRE;
	}

} //QuarentineCentreImpl
