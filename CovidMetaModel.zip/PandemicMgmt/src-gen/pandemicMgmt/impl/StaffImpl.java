/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import pandemicMgmt.HealthCentre;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.Staff;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Staff</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.StaffImpl#getHealthcentre <em>Healthcentre</em>}</li>
 *   <li>{@link pandemicMgmt.impl.StaffImpl#getDoctors <em>Doctors</em>}</li>
 *   <li>{@link pandemicMgmt.impl.StaffImpl#getNurses <em>Nurses</em>}</li>
 *   <li>{@link pandemicMgmt.impl.StaffImpl#getParamedics <em>Paramedics</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StaffImpl extends ResourcesImpl implements Staff {
	/**
	 * The cached value of the '{@link #getHealthcentre() <em>Healthcentre</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHealthcentre()
	 * @generated
	 * @ordered
	 */
	protected HealthCentre healthcentre;

	/**
	 * The default value of the '{@link #getDoctors() <em>Doctors</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctors()
	 * @generated
	 * @ordered
	 */
	protected static final int DOCTORS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDoctors() <em>Doctors</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctors()
	 * @generated
	 * @ordered
	 */
	protected int doctors = DOCTORS_EDEFAULT;

	/**
	 * The default value of the '{@link #getNurses() <em>Nurses</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNurses()
	 * @generated
	 * @ordered
	 */
	protected static final int NURSES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNurses() <em>Nurses</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNurses()
	 * @generated
	 * @ordered
	 */
	protected int nurses = NURSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getParamedics() <em>Paramedics</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParamedics()
	 * @generated
	 * @ordered
	 */
	protected static final int PARAMEDICS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getParamedics() <em>Paramedics</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParamedics()
	 * @generated
	 * @ordered
	 */
	protected int paramedics = PARAMEDICS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StaffImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.STAFF;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HealthCentre getHealthcentre() {
		if (healthcentre != null && healthcentre.eIsProxy()) {
			InternalEObject oldHealthcentre = (InternalEObject) healthcentre;
			healthcentre = (HealthCentre) eResolveProxy(oldHealthcentre);
			if (healthcentre != oldHealthcentre) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PandemicMgmtPackage.STAFF__HEALTHCENTRE,
							oldHealthcentre, healthcentre));
			}
		}
		return healthcentre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HealthCentre basicGetHealthcentre() {
		return healthcentre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHealthcentre(HealthCentre newHealthcentre, NotificationChain msgs) {
		HealthCentre oldHealthcentre = healthcentre;
		healthcentre = newHealthcentre;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.STAFF__HEALTHCENTRE, oldHealthcentre, newHealthcentre);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHealthcentre(HealthCentre newHealthcentre) {
		if (newHealthcentre != healthcentre) {
			NotificationChain msgs = null;
			if (healthcentre != null)
				msgs = ((InternalEObject) healthcentre).eInverseRemove(this, PandemicMgmtPackage.HEALTH_CENTRE__STAFF,
						HealthCentre.class, msgs);
			if (newHealthcentre != null)
				msgs = ((InternalEObject) newHealthcentre).eInverseAdd(this, PandemicMgmtPackage.HEALTH_CENTRE__STAFF,
						HealthCentre.class, msgs);
			msgs = basicSetHealthcentre(newHealthcentre, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STAFF__HEALTHCENTRE,
					newHealthcentre, newHealthcentre));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getDoctors() {
		return doctors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDoctors(int newDoctors) {
		int oldDoctors = doctors;
		doctors = newDoctors;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STAFF__DOCTORS, oldDoctors,
					doctors));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getNurses() {
		return nurses;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setNurses(int newNurses) {
		int oldNurses = nurses;
		nurses = newNurses;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STAFF__NURSES, oldNurses,
					nurses));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getParamedics() {
		return paramedics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setParamedics(int newParamedics) {
		int oldParamedics = paramedics;
		paramedics = newParamedics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STAFF__PARAMEDICS, oldParamedics,
					paramedics));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.STAFF__HEALTHCENTRE:
			if (healthcentre != null)
				msgs = ((InternalEObject) healthcentre).eInverseRemove(this, PandemicMgmtPackage.HEALTH_CENTRE__STAFF,
						HealthCentre.class, msgs);
			return basicSetHealthcentre((HealthCentre) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.STAFF__HEALTHCENTRE:
			return basicSetHealthcentre(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.STAFF__HEALTHCENTRE:
			if (resolve)
				return getHealthcentre();
			return basicGetHealthcentre();
		case PandemicMgmtPackage.STAFF__DOCTORS:
			return getDoctors();
		case PandemicMgmtPackage.STAFF__NURSES:
			return getNurses();
		case PandemicMgmtPackage.STAFF__PARAMEDICS:
			return getParamedics();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.STAFF__HEALTHCENTRE:
			setHealthcentre((HealthCentre) newValue);
			return;
		case PandemicMgmtPackage.STAFF__DOCTORS:
			setDoctors((Integer) newValue);
			return;
		case PandemicMgmtPackage.STAFF__NURSES:
			setNurses((Integer) newValue);
			return;
		case PandemicMgmtPackage.STAFF__PARAMEDICS:
			setParamedics((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.STAFF__HEALTHCENTRE:
			setHealthcentre((HealthCentre) null);
			return;
		case PandemicMgmtPackage.STAFF__DOCTORS:
			setDoctors(DOCTORS_EDEFAULT);
			return;
		case PandemicMgmtPackage.STAFF__NURSES:
			setNurses(NURSES_EDEFAULT);
			return;
		case PandemicMgmtPackage.STAFF__PARAMEDICS:
			setParamedics(PARAMEDICS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.STAFF__HEALTHCENTRE:
			return healthcentre != null;
		case PandemicMgmtPackage.STAFF__DOCTORS:
			return doctors != DOCTORS_EDEFAULT;
		case PandemicMgmtPackage.STAFF__NURSES:
			return nurses != NURSES_EDEFAULT;
		case PandemicMgmtPackage.STAFF__PARAMEDICS:
			return paramedics != PARAMEDICS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (doctors: ");
		result.append(doctors);
		result.append(", nurses: ");
		result.append(nurses);
		result.append(", paramedics: ");
		result.append(paramedics);
		result.append(')');
		return result.toString();
	}

} //StaffImpl
