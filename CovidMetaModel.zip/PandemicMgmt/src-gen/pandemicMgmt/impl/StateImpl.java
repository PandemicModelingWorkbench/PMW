/**
 */
package pandemicMgmt.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import pandemicMgmt.City;
import pandemicMgmt.Country;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.State;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.StateImpl#getStateCode <em>State Code</em>}</li>
 *   <li>{@link pandemicMgmt.impl.StateImpl#getCountry <em>Country</em>}</li>
 *   <li>{@link pandemicMgmt.impl.StateImpl#getCity <em>City</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StateImpl extends LocationImpl implements State {
	/**
	 * The default value of the '{@link #getStateCode() <em>State Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStateCode()
	 * @generated
	 * @ordered
	 */
	protected static final String STATE_CODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStateCode() <em>State Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStateCode()
	 * @generated
	 * @ordered
	 */
	protected String stateCode = STATE_CODE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCountry() <em>Country</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCountry()
	 * @generated
	 * @ordered
	 */
	protected Country country;

	/**
	 * The cached value of the '{@link #getCity() <em>City</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCity()
	 * @generated
	 * @ordered
	 */
	protected EList<City> city;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.STATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getStateCode() {
		return stateCode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStateCode(String newStateCode) {
		String oldStateCode = stateCode;
		stateCode = newStateCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STATE__STATE_CODE, oldStateCode,
					stateCode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Country getCountry() {
		if (country != null && country.eIsProxy()) {
			InternalEObject oldCountry = (InternalEObject) country;
			country = (Country) eResolveProxy(oldCountry);
			if (country != oldCountry) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PandemicMgmtPackage.STATE__COUNTRY,
							oldCountry, country));
			}
		}
		return country;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Country basicGetCountry() {
		return country;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCountry(Country newCountry, NotificationChain msgs) {
		Country oldCountry = country;
		country = newCountry;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.STATE__COUNTRY, oldCountry, newCountry);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCountry(Country newCountry) {
		if (newCountry != country) {
			NotificationChain msgs = null;
			if (country != null)
				msgs = ((InternalEObject) country).eInverseRemove(this, PandemicMgmtPackage.COUNTRY__STATE,
						Country.class, msgs);
			if (newCountry != null)
				msgs = ((InternalEObject) newCountry).eInverseAdd(this, PandemicMgmtPackage.COUNTRY__STATE,
						Country.class, msgs);
			msgs = basicSetCountry(newCountry, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STATE__COUNTRY, newCountry,
					newCountry));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<City> getCity() {
		if (city == null) {
			city = new EObjectWithInverseResolvingEList<City>(City.class, this, PandemicMgmtPackage.STATE__CITY,
					PandemicMgmtPackage.CITY__STATE);
		}
		return city;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.STATE__COUNTRY:
			if (country != null)
				msgs = ((InternalEObject) country).eInverseRemove(this, PandemicMgmtPackage.COUNTRY__STATE,
						Country.class, msgs);
			return basicSetCountry((Country) otherEnd, msgs);
		case PandemicMgmtPackage.STATE__CITY:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getCity()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.STATE__COUNTRY:
			return basicSetCountry(null, msgs);
		case PandemicMgmtPackage.STATE__CITY:
			return ((InternalEList<?>) getCity()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.STATE__STATE_CODE:
			return getStateCode();
		case PandemicMgmtPackage.STATE__COUNTRY:
			if (resolve)
				return getCountry();
			return basicGetCountry();
		case PandemicMgmtPackage.STATE__CITY:
			return getCity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.STATE__STATE_CODE:
			setStateCode((String) newValue);
			return;
		case PandemicMgmtPackage.STATE__COUNTRY:
			setCountry((Country) newValue);
			return;
		case PandemicMgmtPackage.STATE__CITY:
			getCity().clear();
			getCity().addAll((Collection<? extends City>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.STATE__STATE_CODE:
			setStateCode(STATE_CODE_EDEFAULT);
			return;
		case PandemicMgmtPackage.STATE__COUNTRY:
			setCountry((Country) null);
			return;
		case PandemicMgmtPackage.STATE__CITY:
			getCity().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.STATE__STATE_CODE:
			return STATE_CODE_EDEFAULT == null ? stateCode != null : !STATE_CODE_EDEFAULT.equals(stateCode);
		case PandemicMgmtPackage.STATE__COUNTRY:
			return country != null;
		case PandemicMgmtPackage.STATE__CITY:
			return city != null && !city.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (stateCode: ");
		result.append(stateCode);
		result.append(')');
		return result.toString();
	}

} //StateImpl
