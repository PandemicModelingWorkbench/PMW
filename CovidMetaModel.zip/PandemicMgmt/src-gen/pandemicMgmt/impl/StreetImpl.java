/**
 */
package pandemicMgmt.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import pandemicMgmt.House;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.Street;
import pandemicMgmt.Town;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Street</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.StreetImpl#getStreetID <em>Street ID</em>}</li>
 *   <li>{@link pandemicMgmt.impl.StreetImpl#getTown <em>Town</em>}</li>
 *   <li>{@link pandemicMgmt.impl.StreetImpl#getHouse <em>House</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class StreetImpl extends LocationImpl implements Street {
	/**
	 * The default value of the '{@link #getStreetID() <em>Street ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreetID()
	 * @generated
	 * @ordered
	 */
	protected static final String STREET_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStreetID() <em>Street ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreetID()
	 * @generated
	 * @ordered
	 */
	protected String streetID = STREET_ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTown() <em>Town</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTown()
	 * @generated
	 * @ordered
	 */
	protected Town town;

	/**
	 * The cached value of the '{@link #getHouse() <em>House</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHouse()
	 * @generated
	 * @ordered
	 */
	protected EList<House> house;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StreetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.STREET;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getStreetID() {
		return streetID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStreetID(String newStreetID) {
		String oldStreetID = streetID;
		streetID = newStreetID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STREET__STREET_ID, oldStreetID,
					streetID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Town getTown() {
		if (town != null && town.eIsProxy()) {
			InternalEObject oldTown = (InternalEObject) town;
			town = (Town) eResolveProxy(oldTown);
			if (town != oldTown) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PandemicMgmtPackage.STREET__TOWN, oldTown,
							town));
			}
		}
		return town;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Town basicGetTown() {
		return town;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTown(Town newTown, NotificationChain msgs) {
		Town oldTown = town;
		town = newTown;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.STREET__TOWN, oldTown, newTown);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTown(Town newTown) {
		if (newTown != town) {
			NotificationChain msgs = null;
			if (town != null)
				msgs = ((InternalEObject) town).eInverseRemove(this, PandemicMgmtPackage.TOWN__STREET, Town.class,
						msgs);
			if (newTown != null)
				msgs = ((InternalEObject) newTown).eInverseAdd(this, PandemicMgmtPackage.TOWN__STREET, Town.class,
						msgs);
			msgs = basicSetTown(newTown, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.STREET__TOWN, newTown, newTown));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<House> getHouse() {
		if (house == null) {
			house = new EObjectWithInverseResolvingEList<House>(House.class, this, PandemicMgmtPackage.STREET__HOUSE,
					PandemicMgmtPackage.HOUSE__STREET);
		}
		return house;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.STREET__TOWN:
			if (town != null)
				msgs = ((InternalEObject) town).eInverseRemove(this, PandemicMgmtPackage.TOWN__STREET, Town.class,
						msgs);
			return basicSetTown((Town) otherEnd, msgs);
		case PandemicMgmtPackage.STREET__HOUSE:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getHouse()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.STREET__TOWN:
			return basicSetTown(null, msgs);
		case PandemicMgmtPackage.STREET__HOUSE:
			return ((InternalEList<?>) getHouse()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.STREET__STREET_ID:
			return getStreetID();
		case PandemicMgmtPackage.STREET__TOWN:
			if (resolve)
				return getTown();
			return basicGetTown();
		case PandemicMgmtPackage.STREET__HOUSE:
			return getHouse();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.STREET__STREET_ID:
			setStreetID((String) newValue);
			return;
		case PandemicMgmtPackage.STREET__TOWN:
			setTown((Town) newValue);
			return;
		case PandemicMgmtPackage.STREET__HOUSE:
			getHouse().clear();
			getHouse().addAll((Collection<? extends House>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.STREET__STREET_ID:
			setStreetID(STREET_ID_EDEFAULT);
			return;
		case PandemicMgmtPackage.STREET__TOWN:
			setTown((Town) null);
			return;
		case PandemicMgmtPackage.STREET__HOUSE:
			getHouse().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.STREET__STREET_ID:
			return STREET_ID_EDEFAULT == null ? streetID != null : !STREET_ID_EDEFAULT.equals(streetID);
		case PandemicMgmtPackage.STREET__TOWN:
			return town != null;
		case PandemicMgmtPackage.STREET__HOUSE:
			return house != null && !house.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (streetID: ");
		result.append(streetID);
		result.append(')');
		return result.toString();
	}

} //StreetImpl
