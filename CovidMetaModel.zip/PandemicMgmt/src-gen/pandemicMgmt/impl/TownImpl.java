/**
 */
package pandemicMgmt.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import pandemicMgmt.City;
import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.Street;
import pandemicMgmt.Town;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Town</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pandemicMgmt.impl.TownImpl#getTownID <em>Town ID</em>}</li>
 *   <li>{@link pandemicMgmt.impl.TownImpl#getCity <em>City</em>}</li>
 *   <li>{@link pandemicMgmt.impl.TownImpl#getStreet <em>Street</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TownImpl extends LocationImpl implements Town {
	/**
	 * The default value of the '{@link #getTownID() <em>Town ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTownID()
	 * @generated
	 * @ordered
	 */
	protected static final String TOWN_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTownID() <em>Town ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTownID()
	 * @generated
	 * @ordered
	 */
	protected String townID = TOWN_ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCity() <em>City</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCity()
	 * @generated
	 * @ordered
	 */
	protected City city;

	/**
	 * The cached value of the '{@link #getStreet() <em>Street</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreet()
	 * @generated
	 * @ordered
	 */
	protected EList<Street> street;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TownImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.TOWN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getTownID() {
		return townID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTownID(String newTownID) {
		String oldTownID = townID;
		townID = newTownID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.TOWN__TOWN_ID, oldTownID,
					townID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public City getCity() {
		if (city != null && city.eIsProxy()) {
			InternalEObject oldCity = (InternalEObject) city;
			city = (City) eResolveProxy(oldCity);
			if (city != oldCity) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PandemicMgmtPackage.TOWN__CITY, oldCity,
							city));
			}
		}
		return city;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public City basicGetCity() {
		return city;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCity(City newCity, NotificationChain msgs) {
		City oldCity = city;
		city = newCity;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PandemicMgmtPackage.TOWN__CITY, oldCity, newCity);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCity(City newCity) {
		if (newCity != city) {
			NotificationChain msgs = null;
			if (city != null)
				msgs = ((InternalEObject) city).eInverseRemove(this, PandemicMgmtPackage.CITY__TOWN, City.class, msgs);
			if (newCity != null)
				msgs = ((InternalEObject) newCity).eInverseAdd(this, PandemicMgmtPackage.CITY__TOWN, City.class, msgs);
			msgs = basicSetCity(newCity, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PandemicMgmtPackage.TOWN__CITY, newCity, newCity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Street> getStreet() {
		if (street == null) {
			street = new EObjectWithInverseResolvingEList<Street>(Street.class, this, PandemicMgmtPackage.TOWN__STREET,
					PandemicMgmtPackage.STREET__TOWN);
		}
		return street;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.TOWN__CITY:
			if (city != null)
				msgs = ((InternalEObject) city).eInverseRemove(this, PandemicMgmtPackage.CITY__TOWN, City.class, msgs);
			return basicSetCity((City) otherEnd, msgs);
		case PandemicMgmtPackage.TOWN__STREET:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getStreet()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PandemicMgmtPackage.TOWN__CITY:
			return basicSetCity(null, msgs);
		case PandemicMgmtPackage.TOWN__STREET:
			return ((InternalEList<?>) getStreet()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PandemicMgmtPackage.TOWN__TOWN_ID:
			return getTownID();
		case PandemicMgmtPackage.TOWN__CITY:
			if (resolve)
				return getCity();
			return basicGetCity();
		case PandemicMgmtPackage.TOWN__STREET:
			return getStreet();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PandemicMgmtPackage.TOWN__TOWN_ID:
			setTownID((String) newValue);
			return;
		case PandemicMgmtPackage.TOWN__CITY:
			setCity((City) newValue);
			return;
		case PandemicMgmtPackage.TOWN__STREET:
			getStreet().clear();
			getStreet().addAll((Collection<? extends Street>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.TOWN__TOWN_ID:
			setTownID(TOWN_ID_EDEFAULT);
			return;
		case PandemicMgmtPackage.TOWN__CITY:
			setCity((City) null);
			return;
		case PandemicMgmtPackage.TOWN__STREET:
			getStreet().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PandemicMgmtPackage.TOWN__TOWN_ID:
			return TOWN_ID_EDEFAULT == null ? townID != null : !TOWN_ID_EDEFAULT.equals(townID);
		case PandemicMgmtPackage.TOWN__CITY:
			return city != null;
		case PandemicMgmtPackage.TOWN__STREET:
			return street != null && !street.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (townID: ");
		result.append(townID);
		result.append(')');
		return result.toString();
	}

} //TownImpl
