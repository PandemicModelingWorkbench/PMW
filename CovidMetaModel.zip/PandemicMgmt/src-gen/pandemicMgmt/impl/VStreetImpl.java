/**
 */
package pandemicMgmt.impl;

import org.eclipse.emf.ecore.EClass;

import pandemicMgmt.PandemicMgmtPackage;
import pandemicMgmt.VStreet;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>VStreet</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class VStreetImpl extends StreetImpl implements VStreet {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VStreetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PandemicMgmtPackage.Literals.VSTREET;
	}

} //VStreetImpl
