/**
 */
package pandemicMgmt.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import pandemicMgmt.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see pandemicMgmt.PandemicMgmtPackage
 * @generated
 */
public class PandemicMgmtAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PandemicMgmtPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PandemicMgmtAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = PandemicMgmtPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PandemicMgmtSwitch<Adapter> modelSwitch = new PandemicMgmtSwitch<Adapter>() {
		@Override
		public Adapter casePandemic(Pandemic object) {
			return createPandemicAdapter();
		}

		@Override
		public Adapter caseLocation(Location object) {
			return createLocationAdapter();
		}

		@Override
		public Adapter caseCountry(Country object) {
			return createCountryAdapter();
		}

		@Override
		public Adapter casePandemicData(PandemicData object) {
			return createPandemicDataAdapter();
		}

		@Override
		public Adapter caseResources(Resources object) {
			return createResourcesAdapter();
		}

		@Override
		public Adapter caseTown(Town object) {
			return createTownAdapter();
		}

		@Override
		public Adapter caseStreet(Street object) {
			return createStreetAdapter();
		}

		@Override
		public Adapter caseHouse(House object) {
			return createHouseAdapter();
		}

		@Override
		public Adapter casePerson(Person object) {
			return createPersonAdapter();
		}

		@Override
		public Adapter caseControlPolicy(ControlPolicy object) {
			return createControlPolicyAdapter();
		}

		@Override
		public Adapter caseHealthCentre(HealthCentre object) {
			return createHealthCentreAdapter();
		}

		@Override
		public Adapter caseQuarentineCentre(QuarentineCentre object) {
			return createQuarentineCentreAdapter();
		}

		@Override
		public Adapter casePrimaryHealthUnit(PrimaryHealthUnit object) {
			return createPrimaryHealthUnitAdapter();
		}

		@Override
		public Adapter caseSecondaryHealthUnit(SecondaryHealthUnit object) {
			return createSecondaryHealthUnitAdapter();
		}

		@Override
		public Adapter caseTertiaryHealthUnit(TertiaryHealthUnit object) {
			return createTertiaryHealthUnitAdapter();
		}

		@Override
		public Adapter caseStaff(Staff object) {
			return createStaffAdapter();
		}

		@Override
		public Adapter caseEquipment(Equipment object) {
			return createEquipmentAdapter();
		}

		@Override
		public Adapter caseCity(City object) {
			return createCityAdapter();
		}

		@Override
		public Adapter caseState(State object) {
			return createStateAdapter();
		}

		@Override
		public Adapter caseHStreet(HStreet object) {
			return createHStreetAdapter();
		}

		@Override
		public Adapter caseVStreet(VStreet object) {
			return createVStreetAdapter();
		}

		@Override
		public Adapter casePandemicModel(PandemicModel object) {
			return createPandemicModelAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.PandemicModel <em>Pandemic Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.PandemicModel
	 * @generated
	 */
	public Adapter createPandemicModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Location <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Location
	 * @generated
	 */
	public Adapter createLocationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Country <em>Country</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Country
	 * @generated
	 */
	public Adapter createCountryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.PandemicData <em>Pandemic Data</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.PandemicData
	 * @generated
	 */
	public Adapter createPandemicDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Resources <em>Resources</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Resources
	 * @generated
	 */
	public Adapter createResourcesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Town <em>Town</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Town
	 * @generated
	 */
	public Adapter createTownAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Street <em>Street</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Street
	 * @generated
	 */
	public Adapter createStreetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.House <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.House
	 * @generated
	 */
	public Adapter createHouseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Person <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Person
	 * @generated
	 */
	public Adapter createPersonAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.ControlPolicy <em>Control Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.ControlPolicy
	 * @generated
	 */
	public Adapter createControlPolicyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.HealthCentre <em>Health Centre</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.HealthCentre
	 * @generated
	 */
	public Adapter createHealthCentreAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.QuarentineCentre <em>Quarentine Centre</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.QuarentineCentre
	 * @generated
	 */
	public Adapter createQuarentineCentreAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.PrimaryHealthUnit <em>Primary Health Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.PrimaryHealthUnit
	 * @generated
	 */
	public Adapter createPrimaryHealthUnitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.SecondaryHealthUnit <em>Secondary Health Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.SecondaryHealthUnit
	 * @generated
	 */
	public Adapter createSecondaryHealthUnitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.TertiaryHealthUnit <em>Tertiary Health Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.TertiaryHealthUnit
	 * @generated
	 */
	public Adapter createTertiaryHealthUnitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Staff <em>Staff</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Staff
	 * @generated
	 */
	public Adapter createStaffAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Equipment <em>Equipment</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Equipment
	 * @generated
	 */
	public Adapter createEquipmentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.City <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.City
	 * @generated
	 */
	public Adapter createCityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.State <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.State
	 * @generated
	 */
	public Adapter createStateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.HStreet <em>HStreet</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.HStreet
	 * @generated
	 */
	public Adapter createHStreetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.VStreet <em>VStreet</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.VStreet
	 * @generated
	 */
	public Adapter createVStreetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link pandemicMgmt.Pandemic <em>Pandemic</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see pandemicMgmt.Pandemic
	 * @generated
	 */
	public Adapter createPandemicAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //PandemicMgmtAdapterFactory
