/**
 */
package pandemicMgmt.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import pandemicMgmt.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see pandemicMgmt.PandemicMgmtPackage
 * @generated
 */
public class PandemicMgmtSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PandemicMgmtPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PandemicMgmtSwitch() {
		if (modelPackage == null) {
			modelPackage = PandemicMgmtPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case PandemicMgmtPackage.PANDEMIC: {
			Pandemic pandemic = (Pandemic) theEObject;
			T result = casePandemic(pandemic);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.LOCATION: {
			Location location = (Location) theEObject;
			T result = caseLocation(location);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.COUNTRY: {
			Country country = (Country) theEObject;
			T result = caseCountry(country);
			if (result == null)
				result = caseLocation(country);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.PANDEMIC_DATA: {
			PandemicData pandemicData = (PandemicData) theEObject;
			T result = casePandemicData(pandemicData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.RESOURCES: {
			Resources resources = (Resources) theEObject;
			T result = caseResources(resources);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.TOWN: {
			Town town = (Town) theEObject;
			T result = caseTown(town);
			if (result == null)
				result = caseLocation(town);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.STREET: {
			Street street = (Street) theEObject;
			T result = caseStreet(street);
			if (result == null)
				result = caseLocation(street);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.HOUSE: {
			House house = (House) theEObject;
			T result = caseHouse(house);
			if (result == null)
				result = caseLocation(house);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.PERSON: {
			Person person = (Person) theEObject;
			T result = casePerson(person);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.CONTROL_POLICY: {
			ControlPolicy controlPolicy = (ControlPolicy) theEObject;
			T result = caseControlPolicy(controlPolicy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.HEALTH_CENTRE: {
			HealthCentre healthCentre = (HealthCentre) theEObject;
			T result = caseHealthCentre(healthCentre);
			if (result == null)
				result = caseResources(healthCentre);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.QUARENTINE_CENTRE: {
			QuarentineCentre quarentineCentre = (QuarentineCentre) theEObject;
			T result = caseQuarentineCentre(quarentineCentre);
			if (result == null)
				result = caseHealthCentre(quarentineCentre);
			if (result == null)
				result = caseResources(quarentineCentre);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.PRIMARY_HEALTH_UNIT: {
			PrimaryHealthUnit primaryHealthUnit = (PrimaryHealthUnit) theEObject;
			T result = casePrimaryHealthUnit(primaryHealthUnit);
			if (result == null)
				result = caseHealthCentre(primaryHealthUnit);
			if (result == null)
				result = caseResources(primaryHealthUnit);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.SECONDARY_HEALTH_UNIT: {
			SecondaryHealthUnit secondaryHealthUnit = (SecondaryHealthUnit) theEObject;
			T result = caseSecondaryHealthUnit(secondaryHealthUnit);
			if (result == null)
				result = caseHealthCentre(secondaryHealthUnit);
			if (result == null)
				result = caseResources(secondaryHealthUnit);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.TERTIARY_HEALTH_UNIT: {
			TertiaryHealthUnit tertiaryHealthUnit = (TertiaryHealthUnit) theEObject;
			T result = caseTertiaryHealthUnit(tertiaryHealthUnit);
			if (result == null)
				result = caseHealthCentre(tertiaryHealthUnit);
			if (result == null)
				result = caseResources(tertiaryHealthUnit);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.STAFF: {
			Staff staff = (Staff) theEObject;
			T result = caseStaff(staff);
			if (result == null)
				result = caseResources(staff);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.EQUIPMENT: {
			Equipment equipment = (Equipment) theEObject;
			T result = caseEquipment(equipment);
			if (result == null)
				result = caseResources(equipment);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.CITY: {
			City city = (City) theEObject;
			T result = caseCity(city);
			if (result == null)
				result = caseLocation(city);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.STATE: {
			State state = (State) theEObject;
			T result = caseState(state);
			if (result == null)
				result = caseLocation(state);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.HSTREET: {
			HStreet hStreet = (HStreet) theEObject;
			T result = caseHStreet(hStreet);
			if (result == null)
				result = caseStreet(hStreet);
			if (result == null)
				result = caseLocation(hStreet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.VSTREET: {
			VStreet vStreet = (VStreet) theEObject;
			T result = caseVStreet(vStreet);
			if (result == null)
				result = caseStreet(vStreet);
			if (result == null)
				result = caseLocation(vStreet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case PandemicMgmtPackage.PANDEMIC_MODEL: {
			PandemicModel pandemicModel = (PandemicModel) theEObject;
			T result = casePandemicModel(pandemicModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pandemic Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pandemic Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePandemicModel(PandemicModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Location</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLocation(Location object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Country</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Country</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCountry(Country object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pandemic Data</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pandemic Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePandemicData(PandemicData object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Resources</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Resources</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseResources(Resources object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Town</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Town</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTown(Town object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Street</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Street</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStreet(Street object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>House</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>House</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHouse(House object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Person</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Person</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePerson(Person object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Control Policy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Control Policy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseControlPolicy(ControlPolicy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Health Centre</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Health Centre</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHealthCentre(HealthCentre object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Quarentine Centre</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Quarentine Centre</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseQuarentineCentre(QuarentineCentre object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Primary Health Unit</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Primary Health Unit</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePrimaryHealthUnit(PrimaryHealthUnit object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Secondary Health Unit</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Secondary Health Unit</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSecondaryHealthUnit(SecondaryHealthUnit object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tertiary Health Unit</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tertiary Health Unit</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTertiaryHealthUnit(TertiaryHealthUnit object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Staff</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Staff</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStaff(Staff object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Equipment</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Equipment</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEquipment(Equipment object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>City</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>City</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCity(City object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>State</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>State</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseState(State object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>HStreet</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>HStreet</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHStreet(HStreet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>VStreet</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>VStreet</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVStreet(VStreet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pandemic</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pandemic</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePandemic(Pandemic object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //PandemicMgmtSwitch
