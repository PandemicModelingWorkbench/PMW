/**
 */
package pandemicMgmt.util;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import pandemicMgmt.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see pandemicMgmt.PandemicMgmtPackage
 * @generated
 */
public class PandemicMgmtValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final PandemicMgmtValidator INSTANCE = new PandemicMgmtValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "pandemicMgmt";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PandemicMgmtValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
		return PandemicMgmtPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		switch (classifierID) {
		case PandemicMgmtPackage.PANDEMIC:
			return validatePandemic((Pandemic) value, diagnostics, context);
		case PandemicMgmtPackage.LOCATION:
			return validateLocation((Location) value, diagnostics, context);
		case PandemicMgmtPackage.COUNTRY:
			return validateCountry((Country) value, diagnostics, context);
		case PandemicMgmtPackage.PANDEMIC_DATA:
			return validatePandemicData((PandemicData) value, diagnostics, context);
		case PandemicMgmtPackage.RESOURCES:
			return validateResources((Resources) value, diagnostics, context);
		case PandemicMgmtPackage.TOWN:
			return validateTown((Town) value, diagnostics, context);
		case PandemicMgmtPackage.STREET:
			return validateStreet((Street) value, diagnostics, context);
		case PandemicMgmtPackage.HOUSE:
			return validateHouse((House) value, diagnostics, context);
		case PandemicMgmtPackage.PERSON:
			return validatePerson((Person) value, diagnostics, context);
		case PandemicMgmtPackage.CONTROL_POLICY:
			return validateControlPolicy((ControlPolicy) value, diagnostics, context);
		case PandemicMgmtPackage.HEALTH_CENTRE:
			return validateHealthCentre((HealthCentre) value, diagnostics, context);
		case PandemicMgmtPackage.QUARENTINE_CENTRE:
			return validateQuarentineCentre((QuarentineCentre) value, diagnostics, context);
		case PandemicMgmtPackage.PRIMARY_HEALTH_UNIT:
			return validatePrimaryHealthUnit((PrimaryHealthUnit) value, diagnostics, context);
		case PandemicMgmtPackage.SECONDARY_HEALTH_UNIT:
			return validateSecondaryHealthUnit((SecondaryHealthUnit) value, diagnostics, context);
		case PandemicMgmtPackage.TERTIARY_HEALTH_UNIT:
			return validateTertiaryHealthUnit((TertiaryHealthUnit) value, diagnostics, context);
		case PandemicMgmtPackage.STAFF:
			return validateStaff((Staff) value, diagnostics, context);
		case PandemicMgmtPackage.EQUIPMENT:
			return validateEquipment((Equipment) value, diagnostics, context);
		case PandemicMgmtPackage.CITY:
			return validateCity((City) value, diagnostics, context);
		case PandemicMgmtPackage.STATE:
			return validateState((State) value, diagnostics, context);
		case PandemicMgmtPackage.HSTREET:
			return validateHStreet((HStreet) value, diagnostics, context);
		case PandemicMgmtPackage.VSTREET:
			return validateVStreet((VStreet) value, diagnostics, context);
		case PandemicMgmtPackage.PANDEMIC_MODEL:
			return validatePandemicModel((PandemicModel) value, diagnostics, context);
		case PandemicMgmtPackage.LLEVEL:
			return validateLLevel((LLevel) value, diagnostics, context);
		case PandemicMgmtPackage.GENDER:
			return validateGender((Gender) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePandemicModel(PandemicModel pandemicModel, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(pandemicModel, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLocation(Location location, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(location, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(location, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(location, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the policyTierCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String LOCATION__POLICY_TIER_CHECK__EEXPRESSION = "\n"
			+ "\t\tself.currentTier = self.controlpolicy.setTier";

	/**
	 * Validates the policyTierCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLocation_policyTierCheck(Location location, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(PandemicMgmtPackage.Literals.LOCATION, location, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "policyTierCheck",
				LOCATION__POLICY_TIER_CHECK__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the caseRateCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String LOCATION__CASE_RATE_CHECK__EEXPRESSION = "\n"
			+ "\t\t(self.pandemicdata.previousCaseCount)/(self.pandemicdata.currentCaseCount) <= self.controlpolicy.caseRate";

	/**
	 * Validates the caseRateCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLocation_caseRateCheck(Location location, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(PandemicMgmtPackage.Literals.LOCATION, location, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "caseRateCheck",
				LOCATION__CASE_RATE_CHECK__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the testingRateCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String LOCATION__TESTING_RATE_CHECK__EEXPRESSION = "\n"
			+ "\t\t(self.pandemicdata.previousTestsCount)/(self.pandemicdata.currentTestsCount) <= self.controlpolicy.caseDetectionRate";

	/**
	 * Validates the testingRateCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLocation_testingRateCheck(Location location, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(PandemicMgmtPackage.Literals.LOCATION, location, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "testingRateCheck",
				LOCATION__TESTING_RATE_CHECK__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the positivityRateCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String LOCATION__POSITIVITY_RATE_CHECK__EEXPRESSION = "\n"
			+ "\t\tself.pandemicdata.currentPositive <= self.controlpolicy.positivityRate";

	/**
	 * Validates the positivityRateCheck constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLocation_positivityRateCheck(Location location, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(PandemicMgmtPackage.Literals.LOCATION, location, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "positivityRateCheck",
				LOCATION__POSITIVITY_RATE_CHECK__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCountry(Country country, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(country, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(country, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(country, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePandemicData(PandemicData pandemicData, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(pandemicData, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateResources(Resources resources, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(resources, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTown(Town town, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(town, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(town, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(town, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStreet(Street street, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(street, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(street, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(street, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHouse(House house, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(house, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(house, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(house, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePerson(Person person, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(person, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateControlPolicy(ControlPolicy controlPolicy, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(controlPolicy, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHealthCentre(HealthCentre healthCentre, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(healthCentre, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateQuarentineCentre(QuarentineCentre quarentineCentre, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(quarentineCentre, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePrimaryHealthUnit(PrimaryHealthUnit primaryHealthUnit, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(primaryHealthUnit, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSecondaryHealthUnit(SecondaryHealthUnit secondaryHealthUnit, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(secondaryHealthUnit, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTertiaryHealthUnit(TertiaryHealthUnit tertiaryHealthUnit, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(tertiaryHealthUnit, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStaff(Staff staff, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(staff, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(staff, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateStaff_doctorCheck(staff, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the doctorCheck constraint of '<em>Staff</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String STAFF__DOCTOR_CHECK__EEXPRESSION = "\n"
			+ "\t\t\tself.location.controlpolicy.doctorsPerPatient >= self.doctors";

	/**
	 * Validates the doctorCheck constraint of '<em>Staff</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStaff_doctorCheck(Staff staff, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate(PandemicMgmtPackage.Literals.STAFF, staff, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "doctorCheck", STAFF__DOCTOR_CHECK__EEXPRESSION,
				Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEquipment(Equipment equipment, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(equipment, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(equipment, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateEquipment_ventilatorsCheck(equipment, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the ventilatorsCheck constraint of '<em>Equipment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String EQUIPMENT__VENTILATORS_CHECK__EEXPRESSION = "\n"
			+ "\t\tself.location.controlpolicy.ventsPerPopulation >= self.ventilators";

	/**
	 * Validates the ventilatorsCheck constraint of '<em>Equipment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEquipment_ventilatorsCheck(Equipment equipment, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(PandemicMgmtPackage.Literals.EQUIPMENT, equipment, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "ventilatorsCheck",
				EQUIPMENT__VENTILATORS_CHECK__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCity(City city, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(city, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(city, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(city, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateState(State state, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(state, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(state, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(state, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHStreet(HStreet hStreet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(hStreet, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(hStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(hStreet, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVStreet(VStreet vStreet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(vStreet, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_policyTierCheck(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_caseRateCheck(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_testingRateCheck(vStreet, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateLocation_positivityRateCheck(vStreet, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePandemic(Pandemic pandemic, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(pandemic, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLLevel(LLevel lLevel, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGender(Gender gender, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //PandemicMgmtValidator
