package JEModule;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
//import java.util.Iterator;


import javax.swing.JOptionPane;

//import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


public class JavaExcelModule {

	 public static void main(String[] args) throws IOException  {
	//     exportExcel();
	//String arg =	 importExcel(1,6);
	    }
	 
	// public void exportExcel(String[] data) throws IOException{
	 public void exportExcel(String r0c1, String r0c2, String r0c3, String r0c4, String r0c5, String r0c6, String r0c7) throws IOException{
		 
	       String excelFilePath = "D:/a1.xlsx";
	         
	        try {
	            FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
	            Workbook workbook = WorkbookFactory.create(inputStream);
	 
	            Sheet sheet = workbook.getSheetAt(0);
	 
	          int rowCount = sheet.getLastRowNum();
		          int columnCount = 0;
	
	              Row row = sheet.createRow(++rowCount);
	 
	                 
	                Cell cell1 = row.createCell(columnCount++);
	                cell1.setCellValue((String) r0c1);
	                Cell cell2 = row.createCell(columnCount++);
	                cell2.setCellValue((String) r0c2);
	                Cell cell3 = row.createCell(columnCount++);
	                cell3.setCellValue((String) r0c3);
	                Cell cell4 = row.createCell(columnCount++);
	                cell4.setCellValue((String) r0c4);
	                Cell cell5 = row.createCell(columnCount++);
	                cell5.setCellValue((String) r0c5);
	                Cell cell6 = row.createCell(columnCount++);
	                cell6.setCellValue((String) r0c6);
	                Cell cell7 = row.createCell(columnCount++);
	                cell7.setCellValue((String) r0c7);
	 
	 
	            inputStream.close();
	 
	            FileOutputStream outputStream = new FileOutputStream("D:/a1.xlsx");
	            workbook.write(outputStream);
	            workbook.close();
	            outputStream.close();
	            JOptionPane.showMessageDialog(null, r0c4);
	             
	        } catch (IOException | EncryptedDocumentException ex) {
	            ex.printStackTrace();
	        }
	    }
	 
	//	 JOptionPane.showMessageDialog(null, data);
	        
	 
	 public String importExcel(int RowID, int columnID) throws IOException{
		
		 			String returnString = null;
		 			String excelFilePath = "D:/a1.xlsx";
		         FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		          
		         Workbook workbook = new XSSFWorkbook(inputStream);
		         Sheet firstSheet = workbook.getSheetAt(0);
		         Row row = firstSheet.getRow(RowID);
		         Cell cell = row.getCell(columnID);
		         
		                 switch (cell.getCellType()) {
		                     case STRING:
		                    	 returnString = cell.getStringCellValue();
		                         System.out.print(cell.getStringCellValue());
		                         break;
		                     case BOOLEAN:
		                    	 returnString = cell.getStringCellValue().toString();
		                         System.out.print(cell.getBooleanCellValue());
		                         break;
		                     case NUMERIC:
		                    	// returnString = cell.getNumericCellValue().toString();
		                         System.out.print(cell.getNumericCellValue());
		                         break;
						default:
							break;
		                 }
		                         
		          
		         workbook.close();
		         inputStream.close();
				return returnString;
		     }
	 public String rCount() throws IOException{
	
			String excelFilePath = "D:/a1.xlsx";
      FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
       
      Workbook workbook = new XSSFWorkbook(inputStream);
      Sheet firstSheet = workbook.getSheetAt(0);
      int recordCount = firstSheet.getLastRowNum();
        
       
      workbook.close();
      inputStream.close();
		return Integer.toString(recordCount);
		 
	 }
}

