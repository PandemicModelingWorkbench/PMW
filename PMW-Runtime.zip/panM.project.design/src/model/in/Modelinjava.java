package model.in;
import java.io.IOException;

import JEModule.JavaExcelModule;

public class Modelinjava {

	public String callJEM(String rowID, String columnID) throws IOException {
		JavaExcelModule jem = new JavaExcelModule();
	return jem.importExcel(Integer.parseInt(rowID), Integer.parseInt(columnID));
}
}
