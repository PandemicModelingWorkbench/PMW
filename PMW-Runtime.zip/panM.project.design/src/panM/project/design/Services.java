package panM.project.design;


import java.io.File;

import java.io.IOException;
import java.util.Collections;

import javax.swing.JOptionPane;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import JEModule.JavaExcelModule;
import model.to.text.main.Generate;
import text.to.model.main.Generateload;


//import model.to.text.main.Generate;

//import model.to.text.main.Generate;
//import text.to.model.main.Generate;
//import text.to.model.main.*;
//import JEModule.JavaExcelModule;

import pandemicMgmt.*;
//import model.to.text.main.*;


/**
 * The services class used by VSM.
 */
public class Services {
   
public static void main( String[] args) throws IOException  {
//saveDataP(null, "A");
//loadDataP(null);
//saveDataA(null,"A");
//loadDataA(null,"A");
}
	    		      
public EObject loadDataP(EObject self, String arg) throws IOException{
	JOptionPane.showMessageDialog(null, "Inside loadDataP Function");
	    // In this function we create our M1 model and populate it with values from Excel 		
	JavaExcelModule j = new JavaExcelModule();
	
	    			PandemicMgmtFactory factory = PandemicMgmtFactory.eINSTANCE;
	    			PandemicModel m = factory.createPandemicModel();
	    			m.setModelID("110");
	    			
	    			Pandemic p = factory.createPandemic();
	    			p.setName("Sample Pandemic");
	    			
	    			m.getPandemic().add(p);
	    				    	
	    			JOptionPane.showMessageDialog(null, m.toString());
	    			
	    			Country c = factory.createCountry();
	    			c.setName(j.importExcel(1, 0));
	    			p.getLocation().add(c);
	    			    			
	    			  ResourceSet resourceSet = new ResourceSetImpl();
	    			  // Register the default resource factory -- only needed for stand-alone!
	    			  resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
	    			    Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());

	    			  // Get the URI of the model file.
	    			URI fileURI = URI.createFileURI(new File("D:/MS20/COVID-PANDEMIC-RESEARCH-PAPER 2021/16Oct21Complete/PanM/GeneratedModels/sampleGeneratedModel.pandemicMgmt").getAbsolutePath());
	    	
	      			  Resource resource = resourceSet.createResource(fileURI);
	    			  // Add the library objects to the contents.
	    			  resource.getContents().add(m);		  
	    			  // Save the contents of the resource to the file system.
	    			  try
	    			  {
	    			    resource.save(Collections.EMPTY_MAP);
	    			  }
	    			  catch (IOException e) {}
	    				JOptionPane.showMessageDialog(null, "loadDataP Exiting");
						return self;
	    		}
	    			    		
	    		      
public void saveDataP(EObject self, String arg) throws IOException{
	JOptionPane.showMessageDialog(null, "Inside SaveDataP Function");
	// In this function we load our M1 model and save its values to Excel
	
	JavaExcelModule jem = new JavaExcelModule();
	JOptionPane.showMessageDialog(null, "CP-1");
	ResourceSet  resource_set = new ResourceSetImpl();
	resource_set.getResourceFactoryRegistry().getExtensionToFactoryMap().put("pandemicMgmt", new XMIResourceFactoryImpl());
PandemicMgmtPackage.eINSTANCE.eClass();

try
{
  File myFile = new  File("D:/MS20/COVID-PANDEMIC-RESEARCH-PAPER 2021/16Oct21Complete/panM.project.design/models/Influenza.pandemicMgmt");
String myFilePath = myFile.getAbsolutePath();	 
Resource loadedm = resource_set.getResource(URI.createFileURI(myFilePath), true);

PandemicModel pa = (PandemicModel) loadedm.getContents().get(0);
JOptionPane.showMessageDialog(null, pa.getModelID()); // gives pandemic modeID
Pandemic p = pa.getPandemic().get(0);
JOptionPane.showMessageDialog(null, p.getName()); // gives pandemic name
Country c1 = (Country) p.getLocation().get(0) ;
Country c2 = (Country) p.getLocation().get(1) ;
String r0c0 = c1.getName();
String r0c1 = c1.getCurrentTier().toString();
String r0c2 = Integer.toString(c1.getPopulation());
String r0c3 = Integer.toString(c1.getPopulationOver60());
String r0c4 = Integer.toString(c1.getHealthy());
String r0c5 = Integer.toString(c1.getInfected());
String r0c6 = c1.getControlpolicy().getName();

jem.exportExcel(r0c0, r0c1, r0c2, r0c3, r0c4, r0c5, r0c6);

String r1c0 = c2.getName();
String r1c1 = c2.getCurrentTier().toString();
String r1c2 = Integer.toString(c2.getPopulation());
String r1c3 = Integer.toString(c2.getPopulationOver60());
String r1c4 = Integer.toString(c2.getHealthy());
String r1c5 = Integer.toString(c2.getInfected());
String r1c6 = c2.getControlpolicy().getName();
jem.exportExcel(r1c0, r1c1, r1c2, r1c3, r1c4, r1c5, r1c6);
}
catch (IOException e) {}
JOptionPane.showMessageDialog(null, "SaveDataP Exiting");
}


public String saveDataA(EObject self,String arg){
	JOptionPane.showMessageDialog(null, "Inside saveDataA Function");
	URI uri = URI.createFileURI("D:/MS20/MyPandemicMgmt.pandemicMgmt");
	
//  File outputDir = new File("C:/Users/Aon/runtime-10Oct21/model.to.text/tasks"); 
	 File outputDir = new File("D:/");
	
	 try {
			Generate genM = new Generate(uri, outputDir, Collections.emptyList());
			 JOptionPane.showMessageDialog(null, "exec till here");
			genM.doGenerate(null);	 
			JOptionPane.showMessageDialog(null, "Data Saved Successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Exception Raised");
	e.printStackTrace();
		}
	
	return "aon";
}

public String loadDataA(EObject self, String A) throws IOException{
	JOptionPane.showMessageDialog(null, "Inside loadDataA Function");


	URI uri = URI.createFileURI("D:/MS20/COVID-PANDEMIC-RESEARCH-PAPER 2021/16Oct21Complete/text.to.model/tasks/generatedModel.pandemicMgmt");
	File outputDir = new File("D:/");

	try {
		Generateload genral = new Generateload(uri, outputDir, Collections.emptyList());
		   genral.doGenerate(null);
	}
	catch (IOException e) {

			JOptionPane.showMessageDialog(null, "exception raised");
			e.printStackTrace();
	}

		JOptionPane.showMessageDialog(null, "exiting loadDataA Function");
return A;
}	

/////////////////////////////////////
//////////////////////////////////////
////////////////////////////////////////
////////////////////////////////////////////
public String checkStatus(EObject self, String A) throws IOException{
	//JavaExcelModule jem = new JavaExcelModule();
//	A = jem.importExcel(0, 0);
	return "Data Successfully saved";
		
}
public String pandemicName(EObject self, String A) throws IOException{
	JavaExcelModule jem = new JavaExcelModule();
	return jem.importExcel(1,0);
		
}
public String locationCount(Country country){
//	List<Location> locs= ((Pandemic) pandemic).getLocation();
	//return locs.get(0).getName();
	return country.toString();		
}

public void trialsave(EObject pm) throws IOException{
	//JavaExcelModule j = new JavaExcelModule();
Pandemic p = ((PandemicModel) pm).getPandemic().get(0);

JOptionPane.showMessageDialog(null, p.toString());			
}

}



