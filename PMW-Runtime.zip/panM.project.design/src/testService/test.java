package testService;
//import org.eclipse.emf.ecore.EObject;

//import panM.project.design.Services;

public class test {
	//EObject e;

	
}
